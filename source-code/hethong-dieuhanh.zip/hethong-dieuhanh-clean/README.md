# Hệ thống thông tin quản trị vận hành và điều phối công việc

Đây là source code demo của hệ thống web hỗ trợ quản lý công văn đi, công văn đến, phân công nhiệm vụ, theo dõi tiến độ công việc, quản lý ý kiến kiến nghị, hội nghị/cuộc họp và báo cáo thống kê.

Dự án được thực hiện trong quá trình Thực hành nghề nghiệp ngành Hệ thống Thông tin Quản lý.

## Công nghệ sử dụng

- Python Flask
- Microsoft SQL Server
- HTML/CSS
- JavaScript
- Bootstrap Icons
- PyODBC

## Chức năng chính

- Đăng nhập, đăng xuất
- Đổi mật khẩu, quên mật khẩu
- Quản lý tài khoản người dùng
- Phân quyền theo vai trò
- Quản lý công văn đi
- Quản lý công văn đến
- Phân công nhiệm vụ
- Cập nhật tiến độ công việc
- Quản lý ý kiến, kiến nghị
- Quản lý hội nghị, cuộc họp
- Báo cáo thống kê
- Sao lưu và khôi phục dữ liệu

## Cấu trúc thư mục

```text
hethong-dieuhanh/
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
├── static/
│   ├── css/
│   ├── images/
│   ├── js/
│   └── uploads/
└── templates/
```

## Cách chạy local

### 1. Tạo môi trường ảo

```bash
python -m venv venv
```

Windows:

```bash
venv\\Scripts\\activate
```

macOS/Linux:

```bash
source venv/bin/activate
```

### 2. Cài thư viện

```bash
pip install -r requirements.txt
```

### 3. Tạo file cấu hình môi trường

Sao chép file mẫu:

```bash
copy .env.example .env
```

Sau đó chỉnh các biến kết nối SQL Server trong file `.env` theo máy local.

### 4. Tạo database demo

Chạy file SQL demo trong thư mục `database/` của repository dự án, ví dụ:

```text
database/database_sample.sql
```

### 5. Chạy ứng dụng

```bash
python app.py
```

Mở trình duyệt tại:

```text
http://127.0.0.1:5000
```

## Ghi chú bảo mật

Source code công khai đã được làm sạch trước khi đưa lên GitHub:

- Không chứa mật khẩu thật.
- Không chứa chuỗi kết nối Azure/SQL Server thật.
- Không chứa file upload thật của cơ quan.
- Không chứa thư mục `venv`, `.vscode`, `__pycache__`.
- Không chứa dữ liệu nội bộ trong thư mục `static/uploads`.

Các thông tin cấu hình thật phải được đặt trong file `.env` local hoặc biến môi trường trên server và không được commit lên GitHub.
