(function () {
    function getStaffName(item) {
        const textNode = item.querySelector("span");
        if (!textNode) {
            return item.textContent.replace(/\s+/g, " ").trim();
        }

        const clone = textNode.cloneNode(true);
        clone.querySelectorAll("small").forEach(node => node.remove());
        return clone.textContent.replace(/\s+/g, " ").trim();
    }

    function closePicker(picker) {
        const toggle = picker.querySelector(".staff-picker-toggle");
        picker.classList.remove("is-open");
        if (toggle) {
            toggle.setAttribute("aria-expanded", "false");
        }
    }

    function updatePickerLabel(picker) {
        const label = picker.querySelector(".staff-picker-label");
        const selectedItems = Array.from(picker.querySelectorAll(".checkbox-item"))
            .filter(item => {
                const input = item.querySelector('input[type="checkbox"]');
                return input && input.checked;
            });

        if (!label) {
            return;
        }

        if (selectedItems.length === 0) {
            label.textContent = picker.dataset.placeholder || "Ch\u1ecdn c\u00e1n b\u1ed9";
            return;
        }

        if (selectedItems.length === 1) {
            label.textContent = getStaffName(selectedItems[0]);
            return;
        }

        label.textContent = `${selectedItems.length} c\u00e1n b\u1ed9 \u0111\u00e3 ch\u1ecdn`;
    }

    function initStaffPicker(picker) {
        const toggle = picker.querySelector(".staff-picker-toggle");
        if (!toggle) {
            return;
        }

        toggle.addEventListener("click", function () {
            const willOpen = !picker.classList.contains("is-open");
            document.querySelectorAll("[data-staff-picker].is-open").forEach(openPicker => {
                if (openPicker !== picker) {
                    closePicker(openPicker);
                }
            });
            picker.classList.toggle("is-open", willOpen);
            toggle.setAttribute("aria-expanded", willOpen ? "true" : "false");
        });

        picker.querySelectorAll('input[type="checkbox"]').forEach(input => {
            input.addEventListener("change", function () {
                updatePickerLabel(picker);
            });
        });

        updatePickerLabel(picker);
    }

    document.addEventListener("DOMContentLoaded", function () {
        document.querySelectorAll("[data-staff-picker]").forEach(initStaffPicker);
    });

    document.addEventListener("click", function (event) {
        if (event.target.closest("[data-staff-picker]")) {
            return;
        }

        document.querySelectorAll("[data-staff-picker].is-open").forEach(closePicker);
    });

    document.addEventListener("keydown", function (event) {
        if (event.key !== "Escape") {
            return;
        }

        document.querySelectorAll("[data-staff-picker].is-open").forEach(closePicker);
    });
})();
