(function () {
    function escapeHtml(value) {
        return String(value || "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    function extensionFromName(name) {
        const parts = String(name || "").split(".");
        return parts.length > 1 ? parts.pop().toLowerCase() : "";
    }

    function message(icon, text, extraHtml) {
        return `
            <div class="preview-message">
                <i class="bi ${icon}"></i>
                <p>${text}</p>
                ${extraHtml || ""}
            </div>
        `;
    }

    function renderDocx(previewBox, getArrayBuffer, fileName) {
        previewBox.innerHTML = message(
            "bi-file-earmark-word",
            "Đang tạo bản xem trước file Word..."
        );

        if (!window.mammoth) {
            previewBox.innerHTML = message(
                "bi-file-earmark-text",
                "Không tải được thư viện xem trước Word. Bạn vẫn có thể mở hoặc tải file này."
            );
            return;
        }

        getArrayBuffer()
            .then(function (arrayBuffer) {
                return window.mammoth.convertToHtml({ arrayBuffer: arrayBuffer });
            })
            .then(function (result) {
                const html = (result.value || "").trim();
                const title = escapeHtml(fileName);

                if (!html) {
                    previewBox.innerHTML = message(
                        "bi-file-earmark-text",
                        "File Word này không có nội dung văn bản để xem trước.",
                        `<b>${title}</b>`
                    );
                    return;
                }

                previewBox.innerHTML = `
                    <div class="document-preview-title">
                        <i class="bi bi-file-earmark-word"></i>
                        <b>${title}</b>
                    </div>
                    <div class="docx-preview-content">${html}</div>
                `;
            })
            .catch(function () {
                previewBox.innerHTML = message(
                    "bi-file-earmark-text",
                    "Không thể tạo bản xem trước cho file Word này. Bạn vẫn có thể mở hoặc tải file."
                );
            });
    }

    function renderFile(previewBox, file) {
        const ext = extensionFromName(file.name);
        const fileUrl = URL.createObjectURL(file);
        const fileName = escapeHtml(file.name);

        if (file.type === "application/pdf" || ext === "pdf") {
            previewBox.innerHTML = `<iframe src="${fileUrl}" width="100%" height="520px"></iframe>`;
            return;
        }

        if (file.type.startsWith("image/") || ["png", "jpg", "jpeg"].includes(ext)) {
            previewBox.innerHTML = `<img src="${fileUrl}" class="preview-image">`;
            return;
        }

        if (ext === "docx") {
            renderDocx(previewBox, function () {
                return file.arrayBuffer();
            }, file.name);
            return;
        }

        if (ext === "doc") {
            previewBox.innerHTML = message(
                "bi-file-earmark-word",
                "File .doc là định dạng Word cũ nên trình duyệt không xem trước trực tiếp được. Bạn vẫn có thể lưu file này.",
                `<b>${fileName}</b>`
            );
            return;
        }

        previewBox.innerHTML = message(
            "bi-file-earmark-spreadsheet",
            "File Excel không xem trực tiếp được trên trình duyệt. Bạn vẫn có thể lưu file này.",
            `<b>${fileName}</b>`
        );
    }

    function fileKey(file) {
        return [
            file.name,
            file.size,
            file.lastModified
        ].join("|");
    }

    function syncInputFiles(input, selectedFiles) {
        if (typeof DataTransfer === "undefined") {
            return;
        }

        const dataTransfer = new DataTransfer();
        selectedFiles.forEach(function (file) {
            dataTransfer.items.add(file);
        });
        input.files = dataTransfer.files;
    }

    function createSelectedFilesList(input) {
        const listId = `${input.id || input.name}-selected-files`;
        let list = document.getElementById(listId);

        if (list) {
            return list;
        }

        list = document.createElement("div");
        list.id = listId;
        list.className = "selected-files-list";
        list.hidden = true;
        input.insertAdjacentElement("afterend", list);
        return list;
    }

    function renderSelectedFilesList(list, selectedFiles) {
        if (!list) {
            return;
        }

        if (!selectedFiles.length) {
            list.innerHTML = "";
            list.hidden = true;
            return;
        }

        list.hidden = false;
        list.innerHTML = `
            <div class="selected-files-title">
                <i class="bi bi-paperclip"></i>
                <span>Đã chọn ${selectedFiles.length} tệp để lưu</span>
            </div>
            ${selectedFiles.map(function (file) {
                const key = escapeHtml(fileKey(file));
                const sizeKb = Math.max(1, Math.round(file.size / 1024));
                return `
                    <div class="selected-file-item">
                        <span>${escapeHtml(file.name)} <small>${sizeKb} KB</small></span>
                        <button type="button" class="btn-remove-selected-file" data-file-key="${key}">
                            Bỏ
                        </button>
                    </div>
                `;
            }).join("")}
        `;
    }

    function attachFileInput(options) {
        const input = document.getElementById(options.inputId);
        const previewBox = document.getElementById(options.previewId);

        if (!input || !previewBox) {
            return;
        }

        const initialPreviewHTML = previewBox.innerHTML;
        const emptyMessage = options.emptyMessage || "Chọn file PDF, Word hoặc hình ảnh để xem trước tại đây.";
        const selectedFilesList = createSelectedFilesList(input);
        let selectedFiles = Array.from(input.files || []);

        function updateSelectedFiles(nextFiles, previewFile) {
            const existingKeys = new Set(selectedFiles.map(fileKey));

            nextFiles.forEach(function (file) {
                const key = fileKey(file);
                if (!existingKeys.has(key)) {
                    selectedFiles.push(file);
                    existingKeys.add(key);
                }
            });

            syncInputFiles(input, selectedFiles);
            renderSelectedFilesList(selectedFilesList, selectedFiles);

            const fileToPreview = previewFile || selectedFiles[0];
            if (fileToPreview) {
                renderFile(previewBox, fileToPreview);
                return;
            }

            previewBox.innerHTML = initialPreviewHTML || `<p>${emptyMessage}</p>`;
            renderExistingDocxPreviews(previewBox);
        }

        selectedFilesList.addEventListener("click", function (event) {
            const button = event.target.closest(".btn-remove-selected-file");
            if (!button) {
                return;
            }

            const keyToRemove = button.getAttribute("data-file-key");
            selectedFiles = selectedFiles.filter(function (file) {
                return fileKey(file) !== keyToRemove;
            });

            updateSelectedFiles([], selectedFiles[0]);
        });

        input.addEventListener("change", function () {
            const pickedFiles = Array.from(this.files || []);

            if (!pickedFiles.length && !selectedFiles.length) {
                previewBox.innerHTML = initialPreviewHTML || `<p>${emptyMessage}</p>`;
                renderExistingDocxPreviews(previewBox);
                return;
            }

            updateSelectedFiles(pickedFiles, pickedFiles[pickedFiles.length - 1]);
        });
    }

    function renderExistingDocxPreviews(root) {
        const scope = root || document;
        const previews = scope.querySelectorAll("[data-docx-preview-url]");

        previews.forEach(function (previewBox) {
            const url = previewBox.getAttribute("data-docx-preview-url");
            const name = previewBox.getAttribute("data-docx-preview-name") || "Tệp Word";

            if (!url) {
                return;
            }

            renderDocx(previewBox, function () {
                return fetch(url).then(function (response) {
                    if (!response.ok) {
                        throw new Error("Cannot fetch document");
                    }
                    return response.arrayBuffer();
                });
            }, name);
        });
    }

    window.DocumentPreview = {
        attachFileInput: attachFileInput,
        renderExistingDocxPreviews: renderExistingDocxPreviews
    };
})();
