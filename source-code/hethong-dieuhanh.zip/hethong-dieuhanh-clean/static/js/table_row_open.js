(function () {
    const interactiveSelector = [
        "a",
        "button",
        "input",
        "select",
        "textarea",
        "label",
        "summary",
        "[role='button']",
        "[contenteditable='true']"
    ].join(",");

    const blockedUrlParts = [
        "javascript:",
        "mailto:",
        "tel:",
        "/xoa/",
        "/khoa/",
        "/logout"
    ];

    function isSafeRowLink(link) {
        if (!link) return false;

        const href = (link.getAttribute("href") || "").trim();
        if (!href || href === "#" || href.startsWith("#")) return false;

        const normalizedHref = href.toLowerCase();
        return !blockedUrlParts.some(part => normalizedHref.includes(part));
    }

    function getViewLink(row) {
        if (!row) return null;

        if (row.dataset && row.dataset.viewUrl) {
            return { href: row.dataset.viewUrl, target: "" };
        }

        const explicitViewLink = row.querySelector("a.btn-action.view[href]");
        if (isSafeRowLink(explicitViewLink)) return explicitViewLink;

        const allSafeLinks = Array.from(row.querySelectorAll("a[href]"))
            .filter(isSafeRowLink);

        const detailLink = allSafeLinks
            .find(link => link.getAttribute("href").includes("/xem/"));
        if (detailLink) return detailLink;

        const labeledViewLink = allSafeLinks.find(function (link) {
            const label = [
                link.getAttribute("aria-label") || "",
                link.getAttribute("title") || "",
                link.textContent || ""
            ].join(" ").toLowerCase();

            return label.includes("xem");
        });
        if (labeledViewLink) return labeledViewLink;

        const editLink = allSafeLinks
            .find(link => link.getAttribute("href").includes("/sua/"));
        if (editLink) return editLink;

        return allSafeLinks[0] || null;
    }

    function isInteractiveTarget(target) {
        return Boolean(target && target.closest(interactiveSelector));
    }

    function openRow(row) {
        const link = getViewLink(row);
        if (!link) return;

        if (link.target === "_blank") {
            window.open(link.href, "_blank", "noopener");
        } else {
            window.location.href = link.href;
        }
    }

    document.addEventListener("dblclick", function (event) {
        if (isInteractiveTarget(event.target)) return;

        const row = event.target.closest("tbody tr");
        if (!row) return;

        openRow(row);
    });

    document.addEventListener("DOMContentLoaded", function () {
        document.querySelectorAll("tbody tr").forEach(function (row) {
            if (getViewLink(row)) {
                row.classList.add("row-openable");
                row.style.cursor = row.style.cursor || "pointer";
                row.title = row.title || "Nhấp đúp để xem chi tiết";
            }
        });
    });
})();
