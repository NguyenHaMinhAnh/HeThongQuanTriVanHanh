# Ghi chú phiên bản public

Phiên bản này được chuẩn bị để đưa lên GitHub Portfolio. Một số nội dung đã được loại bỏ hoặc thay thế để đảm bảo an toàn:

- Xóa thư mục môi trường ảo `venv/`.
- Xóa thư mục `.vscode/`, `.agents/`, `.git/`, `__pycache__/`.
- Xóa toàn bộ file upload trong `static/uploads/`, chỉ giữ thư mục rỗng kèm `.gitkeep`.
- Thay `SECRET_KEY` hard-code bằng biến môi trường.
- Thay thông tin SQL Server/Azure hard-code bằng biến môi trường.
- Thay thông tin hỗ trợ cá nhân trên màn hình đăng nhập bằng dữ liệu demo.
- Thêm `.env.example` để hướng dẫn cấu hình local.
- Thêm `.gitignore` để tránh commit file nhạy cảm.

Trước khi public, vẫn nên kiểm tra lại ảnh giao diện và tài liệu đính kèm để bảo đảm không lộ dữ liệu thật.
