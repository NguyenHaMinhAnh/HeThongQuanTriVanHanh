from flask import Flask, render_template, request, redirect, url_for, session, flash, send_from_directory, send_file
import pyodbc
from datetime import datetime, date, time as datetime_time
from decimal import Decimal
from io import BytesIO
import base64
import json
import os
import shutil
import sys
import uuid
import unicodedata
import zipfile
from urllib.parse import urlencode
from werkzeug.utils import secure_filename
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-secret-key-change-me")
app.config["TEMPLATES_AUTO_RELOAD"] = True
app.jinja_env.auto_reload = True

ALLOWED_EXTENSIONS = {"pdf", "doc", "docx", "xls", "xlsx", "png", "jpg", "jpeg"}
BACKUP_FORMAT_VERSION = "hethong-dieuhanh-backup-v1"
UPLOADS_FOLDER = os.path.join(app.root_path, "static", "uploads")


@app.route("/favicon.ico")
def favicon():
    return send_from_directory(
        os.path.join(app.root_path, "static", "images"),
        "BuaLiem.png",
        mimetype="image/png"
    )



# =========================
# KẾT NỐI SQL SERVER
# =========================
def dang_chay_tren_azure():
    return bool(os.environ.get("WEBSITE_SITE_NAME") or os.environ.get("WEBSITE_INSTANCE_ID"))


def get_connection():
    """Create a SQL Server connection using environment variables.

    Public/GitHub version: no real server name, username, password,
    or Azure connection string is hard-coded in the source code.
    Copy `.env.example` to `.env` locally or set variables on the server.
    """
    driver = os.environ.get("DB_DRIVER", "ODBC Driver 17 for SQL Server")
    server = os.environ.get("DB_SERVER", r"localhost\SQLEXPRESS")
    database = os.environ.get("DB_NAME", "HeThongDieuHanh_Demo")
    username = os.environ.get("DB_USER", "")
    password = os.environ.get("DB_PASSWORD", "")
    encrypt = os.environ.get("DB_ENCRYPT", "no")
    trust_cert = os.environ.get("DB_TRUST_SERVER_CERTIFICATE", "yes")
    timeout = os.environ.get("DB_CONNECTION_TIMEOUT", "30")

    conn_parts = [
        f"DRIVER={{{driver}}}",
        f"SERVER={server}",
        f"DATABASE={database}",
        f"Encrypt={encrypt}",
        f"TrustServerCertificate={trust_cert}",
        f"Connection Timeout={timeout}",
    ]

    if username and password:
        conn_parts.extend([f"UID={username}", f"PWD={password}"])
    else:
        conn_parts.append("Trusted_Connection=yes")

    conn_str = ";".join(conn_parts) + ";"
    return pyodbc.connect(conn_str)


# =========================
# HÀM CHUNG
# =========================
def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def log_error_safe(*parts):
    message = " ".join(str(part) for part in parts)
    stream = getattr(sys, "stderr", None)

    if stream and hasattr(stream, "buffer"):
        encoding = stream.encoding or "utf-8"
        stream.buffer.write((message + "\n").encode(encoding, errors="backslashreplace"))
        stream.flush()
        return

    # Fallback for environments without a binary stderr buffer.
    try:
        print(message)
    except Exception:
        pass


PASSWORD_FIRST_LOGIN_COLUMN = "DoiMatKhauLanDau"
PASSWORD_POLICY_MESSAGE = "Mật khẩu mới phải có ít nhất 8 ký tự, bao gồm chữ in hoa, số và ký tự đặc biệt."
_password_first_login_column_ready = None


def mat_khau_dat_yeu_cau(password):
    password = str(password or "")
    return (
        len(password) >= 8
        and any(ch.isupper() for ch in password)
        and any(ch.isdigit() for ch in password)
        and any((not ch.isalnum()) and (not ch.isspace()) for ch in password)
    )


def dam_bao_cot_doi_mat_khau_lan_dau():
    global _password_first_login_column_ready

    if _password_first_login_column_ready is not None:
        return _password_first_login_column_ready

    conn = None
    cursor = None
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(f"SELECT COL_LENGTH('TAIKHOAN', '{PASSWORD_FIRST_LOGIN_COLUMN}')")
        column_exists = cursor.fetchone()[0] is not None

        if not column_exists:
            cursor.execute(f"""
                ALTER TABLE TAIKHOAN
                ADD {PASSWORD_FIRST_LOGIN_COLUMN} BIT NOT NULL
                    CONSTRAINT DF_TAIKHOAN_{PASSWORD_FIRST_LOGIN_COLUMN} DEFAULT (0) WITH VALUES
            """)
            conn.commit()

        _password_first_login_column_ready = True
        return True
    except Exception as e:
        if conn:
            try:
                conn.rollback()
            except Exception:
                pass
        log_error_safe("Loi dam bao cot doi mat khau lan dau:", e)
        _password_first_login_column_ready = False
        return False
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


def tao_ma_tep(cursor=None):
    conn = None
    cursor_cua_ham = cursor

    if cursor_cua_ham is None:
        conn = get_connection()
        cursor_cua_ham = conn.cursor()

    cursor_cua_ham.execute("""
        SELECT MaTep
        FROM TepDinhKem
        WHERE MaTep LIKE 'TEP%'
    """)

    rows = cursor_cua_ham.fetchall()

    max_num = 0
    for row in rows:
        ma = str(row.MaTep).strip()
        so = ma.replace("TEP", "")
        if so.isdigit():
            max_num = max(max_num, int(so))

    if conn:
        cursor_cua_ham.close()
        conn.close()

    return f"TEP{max_num + 1:03d}"


def count_all(table_name):
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
        result = cursor.fetchone()[0]
        cursor.close()
        conn.close()
        return result
    except Exception as e:
        log_error_safe("Loi count_all:", e)
        return 0


def count_by_status(table_name, status_column, status_value):
    try:
        conn = get_connection()
        cursor = conn.cursor()

        query = f"""
            SELECT COUNT(*) 
            FROM {table_name}
            WHERE LTRIM(RTRIM({status_column})) = ?
        """

        cursor.execute(query, status_value)
        result = cursor.fetchone()[0]

        cursor.close()
        conn.close()
        return result

    except Exception as e:
        log_error_safe(
            f"Loi count_by_status {table_name}.{status_column} = {status_value}:",
            e,
        )
        return 0


def quote_sql_identifier(identifier):
    return f"[{str(identifier).replace(']', ']]')}]"


def quote_table_name(schema_name, table_name):
    return f"{quote_sql_identifier(schema_name)}.{quote_sql_identifier(table_name)}"


def lay_danh_sach_bang_sao_luu(cursor):
    cursor.execute("""
        SELECT s.name AS SchemaName, t.name AS TableName
        FROM sys.tables t
        JOIN sys.schemas s ON t.schema_id = s.schema_id
        WHERE t.is_ms_shipped = 0
        ORDER BY s.name, t.name
    """)
    return [{"schema": row[0], "name": row[1]} for row in cursor.fetchall()]


def lay_cot_bang_sao_luu(cursor, schema_name, table_name):
    cursor.execute("""
        SELECT
            c.name,
            TYPE_NAME(c.user_type_id),
            c.column_id,
            COLUMNPROPERTY(c.object_id, c.name, 'IsIdentity'),
            c.is_computed
        FROM sys.columns c
        WHERE c.object_id = OBJECT_ID(?)
        ORDER BY c.column_id
    """, quote_table_name(schema_name, table_name))

    columns = []
    for row in cursor.fetchall():
        data_type = str(row[1] or "").lower()
        if bool(row[4]) or data_type in {"timestamp", "rowversion"}:
            continue

        columns.append({
            "name": row[0],
            "type": row[1],
            "ordinal": int(row[2] or 0),
            "is_identity": bool(row[3]),
        })

    return columns


def serialize_backup_value(value):
    if value is None:
        return None
    if isinstance(value, datetime):
        return {"__type": "datetime", "value": value.isoformat()}
    if isinstance(value, date):
        return {"__type": "date", "value": value.isoformat()}
    if isinstance(value, datetime_time):
        return {"__type": "time", "value": value.isoformat()}
    if isinstance(value, Decimal):
        return {"__type": "decimal", "value": str(value)}
    if isinstance(value, uuid.UUID):
        return {"__type": "uuid", "value": str(value)}
    if isinstance(value, (bytes, bytearray, memoryview)):
        return {
            "__type": "bytes",
            "value": base64.b64encode(bytes(value)).decode("ascii"),
        }

    if isinstance(value, (str, int, float, bool)):
        return value

    return str(value)


def deserialize_backup_value(value):
    if not isinstance(value, dict) or "__type" not in value:
        return value

    value_type = value.get("__type")
    raw_value = value.get("value")

    if raw_value is None:
        return None
    if value_type == "datetime":
        return datetime.fromisoformat(raw_value)
    if value_type == "date":
        return date.fromisoformat(raw_value)
    if value_type == "time":
        return datetime_time.fromisoformat(raw_value)
    if value_type == "decimal":
        return Decimal(str(raw_value))
    if value_type == "uuid":
        return str(raw_value)
    if value_type == "bytes":
        return pyodbc.Binary(base64.b64decode(raw_value))

    return raw_value


def tao_du_lieu_sao_luu():
    conn = None
    cursor = None
    try:
        conn = get_connection()
        cursor = conn.cursor()
        backup_data = {
            "format": BACKUP_FORMAT_VERSION,
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "created_by": session.get("username", ""),
            "tables": [],
        }

        for table in lay_danh_sach_bang_sao_luu(cursor):
            columns = lay_cot_bang_sao_luu(cursor, table["schema"], table["name"])
            if not columns:
                continue

            table_sql = quote_table_name(table["schema"], table["name"])
            column_sql = ", ".join(quote_sql_identifier(column["name"]) for column in columns)
            cursor.execute(f"SELECT {column_sql} FROM {table_sql}")

            rows = []
            for row in cursor.fetchall():
                rows.append([
                    serialize_backup_value(row[index])
                    for index in range(len(columns))
                ])

            backup_data["tables"].append({
                "schema": table["schema"],
                "name": table["name"],
                "columns": columns,
                "rows": rows,
            })

        return backup_data
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


def them_uploads_vao_goi_sao_luu(zip_file):
    if not os.path.isdir(UPLOADS_FOLDER):
        return

    for folder, subfolders, filenames in os.walk(UPLOADS_FOLDER):
        subfolders.sort()
        for filename in sorted(filenames):
            file_path = os.path.join(folder, filename)
            if not os.path.isfile(file_path):
                continue

            relative_path = os.path.relpath(file_path, UPLOADS_FOLDER).replace(os.sep, "/")
            zip_file.write(file_path, f"uploads/{relative_path}")


def tao_goi_sao_luu():
    backup_data = tao_du_lieu_sao_luu()
    backup_buffer = BytesIO()

    with zipfile.ZipFile(backup_buffer, "w", zipfile.ZIP_DEFLATED) as zip_file:
        zip_file.writestr(
            "backup.json",
            json.dumps(backup_data, ensure_ascii=False, indent=2),
        )
        them_uploads_vao_goi_sao_luu(zip_file)

    backup_buffer.seek(0)
    return backup_buffer


def lay_cau_truc_bang_hien_tai(cursor):
    table_map = {}
    for table in lay_danh_sach_bang_sao_luu(cursor):
        columns = lay_cot_bang_sao_luu(cursor, table["schema"], table["name"])
        table_map[(table["schema"].lower(), table["name"].lower())] = {
            "schema": table["schema"],
            "name": table["name"],
            "columns": columns,
            "columns_by_name": {column["name"].lower(): column for column in columns},
            "identity_columns": {
                column["name"].lower()
                for column in columns
                if column.get("is_identity")
            },
        }

    return table_map


def chuan_bi_bang_khoi_phuc(backup_tables, current_tables):
    restore_tables = []

    for table_data in backup_tables:
        schema_name = str(table_data.get("schema") or "dbo")
        table_name = str(table_data.get("name") or "")
        table_key = (schema_name.lower(), table_name.lower())
        current_table = current_tables.get(table_key)
        if not current_table:
            continue

        backup_columns = table_data.get("columns") or []
        backup_column_names = [
            str(column.get("name") if isinstance(column, dict) else column)
            for column in backup_columns
            if column
        ]

        restore_columns = []
        restore_indexes = []
        for index, column_name in enumerate(backup_column_names):
            current_column = current_table["columns_by_name"].get(column_name.lower())
            if not current_column:
                continue
            restore_columns.append(current_column["name"])
            restore_indexes.append(index)

        if not restore_columns:
            continue

        restore_tables.append({
            "table_sql": quote_table_name(current_table["schema"], current_table["name"]),
            "columns": restore_columns,
            "indexes": restore_indexes,
            "rows": table_data.get("rows") or [],
            "identity_columns": current_table["identity_columns"],
        })

    return restore_tables


def khoi_phuc_du_lieu_bang(backup_data):
    if backup_data.get("format") != BACKUP_FORMAT_VERSION:
        raise ValueError("Dinh dang sao luu khong hop le.")

    backup_tables = backup_data.get("tables")
    if not isinstance(backup_tables, list):
        raise ValueError("Goi sao luu khong co du lieu bang.")

    conn = None
    cursor = None
    restored_rows = 0

    try:
        conn = get_connection()
        cursor = conn.cursor()
        current_tables = lay_cau_truc_bang_hien_tai(cursor)
        restore_tables = chuan_bi_bang_khoi_phuc(backup_tables, current_tables)

        for table in restore_tables:
            cursor.execute(f"ALTER TABLE {table['table_sql']} NOCHECK CONSTRAINT ALL")

        for table in reversed(restore_tables):
            cursor.execute(f"DELETE FROM {table['table_sql']}")

        for table in restore_tables:
            column_sql = ", ".join(quote_sql_identifier(column) for column in table["columns"])
            placeholders = ", ".join("?" for _ in table["columns"])
            insert_sql = f"INSERT INTO {table['table_sql']} ({column_sql}) VALUES ({placeholders})"
            has_identity_value = any(
                column.lower() in table["identity_columns"]
                for column in table["columns"]
            )
            value_rows = [
                tuple(
                    deserialize_backup_value(row[index]) if index < len(row) else None
                    for index in table["indexes"]
                )
                for row in table["rows"]
                if isinstance(row, list)
            ]

            if not value_rows:
                continue

            if has_identity_value:
                cursor.execute(f"SET IDENTITY_INSERT {table['table_sql']} ON")

            try:
                cursor.executemany(insert_sql, value_rows)
            finally:
                if has_identity_value:
                    cursor.execute(f"SET IDENTITY_INSERT {table['table_sql']} OFF")

            restored_rows += len(value_rows)

        for table in restore_tables:
            cursor.execute(f"ALTER TABLE {table['table_sql']} WITH CHECK CHECK CONSTRAINT ALL")

        conn.commit()
        return {
            "table_count": len(restore_tables),
            "row_count": restored_rows,
        }
    except Exception:
        if conn:
            conn.rollback()
        raise
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


def duong_dan_upload_khoi_phuc_an_toan(member_name):
    member_name = str(member_name or "").replace("\\", "/")
    if not member_name.startswith("uploads/") or member_name.endswith("/"):
        return None

    relative_path = os.path.normpath(member_name[len("uploads/"):])
    if relative_path.startswith("..") or os.path.isabs(relative_path):
        return None

    uploads_root = os.path.abspath(UPLOADS_FOLDER)
    target_path = os.path.abspath(os.path.join(uploads_root, relative_path))
    if os.path.commonpath([uploads_root, target_path]) != uploads_root:
        return None

    return target_path


def khoi_phuc_uploads_tu_zip(zip_file):
    restored_files = 0
    os.makedirs(UPLOADS_FOLDER, exist_ok=True)

    for member in zip_file.infolist():
        target_path = duong_dan_upload_khoi_phuc_an_toan(member.filename)
        if not target_path:
            continue

        os.makedirs(os.path.dirname(target_path), exist_ok=True)
        with zip_file.open(member) as source, open(target_path, "wb") as target:
            shutil.copyfileobj(source, target)
        restored_files += 1

    return restored_files


def khoi_phuc_tu_goi_sao_luu(file_storage):
    raw_data = file_storage.read()
    if not raw_data:
        raise ValueError("Chua chon tep sao luu.")

    backup_buffer = BytesIO(raw_data)
    if not zipfile.is_zipfile(backup_buffer):
        raise ValueError("Tep sao luu phai la dinh dang ZIP.")

    backup_buffer.seek(0)
    with zipfile.ZipFile(backup_buffer) as zip_file:
        if "backup.json" not in zip_file.namelist():
            raise ValueError("Goi sao luu thieu backup.json.")

        backup_data = json.loads(zip_file.read("backup.json").decode("utf-8"))
        result = khoi_phuc_du_lieu_bang(backup_data)
        result["file_count"] = khoi_phuc_uploads_tu_zip(zip_file)
        return result

def chuyen_datetime_local(value):
    if not value:
        return None

    value = value.strip()

    try:
        # Dạng hiển thị trong form: 20/06/2026 08:00
        return datetime.strptime(value, "%d/%m/%Y %H:%M")
    except:
        pass

    try:
        # Dạng chỉ có ngày: 20/06/2026
        return datetime.strptime(value, "%d/%m/%Y")
    except:
        pass

    try:
        # Dạng từ input datetime-local: 2026-06-20T08:00
        return datetime.strptime(value, "%Y-%m-%dT%H:%M")
    except:
        pass

    try:
        # Dạng có giây: 2026-06-20T08:00:00
        return datetime.strptime(value, "%Y-%m-%dT%H:%M:%S")
    except:
        pass

    try:
        # Dạng SQL thường: 2026-06-20 08:00
        return datetime.strptime(value, "%Y-%m-%d %H:%M")
    except:
        pass

    return None


def kiem_tra_thoi_gian_cuoc_hop(thoi_gian_bat_dau_raw, thoi_gian_ket_thuc_raw):
    bat_dau_raw = (thoi_gian_bat_dau_raw or "").strip()
    ket_thuc_raw = (thoi_gian_ket_thuc_raw or "").strip()
    bat_dau = chuyen_datetime_local(bat_dau_raw)
    ket_thuc = chuyen_datetime_local(ket_thuc_raw)

    if bat_dau_raw and not bat_dau:
        return None, None, "Thời gian bắt đầu không đúng định dạng dd/mm/yyyy HH:mm."

    if ket_thuc_raw and not ket_thuc:
        return None, None, "Thời gian kết thúc không đúng định dạng dd/mm/yyyy HH:mm."

    if ket_thuc and not bat_dau:
        return None, None, "Vui lòng nhập thời gian bắt đầu trước khi nhập thời gian kết thúc."

    if bat_dau and ket_thuc and ket_thuc <= bat_dau:
        return None, None, "Thời gian kết thúc phải sau thời gian bắt đầu."

    return bat_dau, ket_thuc, None


# =========================
# UTILITY HÀM ĐỊNH DẠNG NGÀY
# =========================
def parse_date_ddmmyyyy(date_string):
    """
    Chuyển đổi chuỗi ngày từ định dạng dd/mm/yyyy sang datetime object
    """
    if not date_string or not isinstance(date_string, str):
        return None
    
    try:
        date_string = date_string.strip()
        return datetime.strptime(date_string, "%d/%m/%Y")
    except:
        try:
            # Thử định dạng yyyy-mm-dd (từ type="date" cũ)
            return datetime.strptime(date_string, "%Y-%m-%d")
        except:
            return None


def format_date_ddmmyyyy(date_obj):
    """
    Định dạng datetime object sang chuỗi dd/mm/yyyy
    """
    if not date_obj:
        return ""
    
    if isinstance(date_obj, str):
        try:
            date_obj = datetime.strptime(date_obj, "%Y-%m-%d")
        except:
            return date_obj
    
    try:
        return date_obj.strftime("%d/%m/%Y")
    except:
        return str(date_obj)


def get_date_value_for_input(date_obj):
    """
    Lấy giá trị ngày cho input field (định dạng dd/mm/yyyy)
    """
    if not date_obj:
        return ""
    
    if isinstance(date_obj, str):
        try:
            date_obj = datetime.strptime(date_obj, "%Y-%m-%d")
        except:
            return date_obj
    
    try:
        return date_obj.strftime("%d/%m/%Y")
    except:
        return str(date_obj)


# =========================
# PHÂN QUYỀN THEO CHỨC NĂNG
# =========================
PUBLIC_ENDPOINTS = {
    "login",
    "logout",
    "forgot_password",
    "mobile_app",
    "quen_mat_khau",
    "favicon",
    "static",
}

AUTH_ONLY_ENDPOINTS = {
    "thong_tin_tai_khoan",
    "doi_mat_khau",
    "change_password",
    "ho_tro_nguoi_dung",
}

PASSWORD_CHANGE_ALLOWED_ENDPOINTS = {
    "doi_mat_khau",
    "change_password",
    "ho_tro_nguoi_dung",
    "logout",
    "static",
}

ROLE_PERMISSIONS = {
    "Quản trị viên": {"*"},
    "Lãnh đạo": {
        "dashboard.view",
        "account.change_password",
        "cong_van_di.view",
        "cong_van_di.approve",
        "cong_van_den.view",
        "cong_van_den.update_status",
        "phan_cong.view",
        "phan_cong.manage",
        "phan_cong.update_progress",
        "kien_nghi.view",
        "kien_nghi.process",
        "cuoc_hop.view",
        "cuoc_hop.manage",
        "bao_cao.view",
        "bao_cao.manage",
    },
    "Văn thư": {
        "dashboard.view",
        "account.change_password",
        "cong_van_di.view",
        "cong_van_di.manage",
        "cong_van_di.publish",
        "cong_van_den.view",
        "cong_van_den.manage",
        "cong_van_den.update_status",
        "phan_cong.view",
        "kien_nghi.view",
        "kien_nghi.manage",
        "kien_nghi.process",
        "cuoc_hop.view",
        "cuoc_hop.manage",
        "bao_cao.view",
        "bao_cao.manage",
    },
    "Chuyên viên": {
        "dashboard.view",
        "account.change_password",
        "cong_van_di.view",
        "cong_van_den.view",
        "phan_cong.view",
        "phan_cong.update_progress",
        "kien_nghi.view",
        "kien_nghi.process",
        "cuoc_hop.view",
        "bao_cao.view",
    },
}

ENDPOINT_PERMISSIONS = {
    "dashboard": "dashboard.view",
    "tim_kiem": "dashboard.view",
    "doi_mat_khau": "account.change_password",
    "change_password": "account.change_password",
    "sao_luu_du_lieu": "system.backup_restore",
    "khoi_phuc_du_lieu": "system.backup_restore",

    "nguoi_dung": "nguoi_dung.manage",
    "them_nguoi_dung": "nguoi_dung.manage",
    "sua_nguoi_dung": "nguoi_dung.manage",
    "khoa_nguoi_dung": "nguoi_dung.manage",

    "cong_van_den": "cong_van_den.view",
    "xem_cong_van_den": "cong_van_den.view",
    "them_cong_van_den": "cong_van_den.manage",
    "sua_cong_van_den": "cong_van_den.manage",
    "xoa_cong_van_den": "cong_van_den.manage",
    "xoa_tep_cong_van_den": "cong_van_den.manage",
    "cap_nhat_trang_thai_cong_van_den": "cong_van_den.update_status",

    "cong_van_di": "cong_van_di.view",
    "xem_cong_van_di": "cong_van_di.view",
    "them_cong_van_di": "cong_van_di.manage",
    "sua_cong_van_di": "cong_van_di.manage",
    "xoa_cong_van_di": "cong_van_di.manage",
    "xoa_tep_cong_van_di": "cong_van_di.manage",
    "duyet_cong_van_di": "cong_van_di.approve",
    "yeu_cau_sua_cong_van_di": "cong_van_di.approve",
    "phat_hanh_cong_van_di": "cong_van_di.publish",

    "phan_cong": "phan_cong.view",
    "xem_nhiem_vu": "phan_cong.view",
    "them_nhiem_vu": "phan_cong.manage",
    "sua_nhiem_vu": "phan_cong.manage",
    "xoa_nhiem_vu": "phan_cong.manage",
    "them_tien_do_nhiem_vu": "phan_cong.update_progress",
    "cap_nhat_trang_thai_nhiem_vu": "phan_cong.update_progress",

    "kien_nghi": "kien_nghi.view",
    "xem_kien_nghi": "kien_nghi.view",
    "them_kien_nghi": "kien_nghi.manage",
    "sua_kien_nghi": "kien_nghi.manage",
    "xoa_kien_nghi": "kien_nghi.manage",
    "xu_ly_kien_nghi": "kien_nghi.process",
    "cap_nhat_trang_thai_kien_nghi": "kien_nghi.process",

    "cuoc_hop": "cuoc_hop.view",
    "xem_cuoc_hop": "cuoc_hop.view",
    "them_cuoc_hop": "cuoc_hop.manage",
    "sua_cuoc_hop": "cuoc_hop.manage",
    "xoa_cuoc_hop": "cuoc_hop.manage",

    "bao_cao": "bao_cao.view",
    "bao_cao_cong_van_di": "bao_cao.view",
    "bao_cao_cong_van_den": "bao_cao.view",
    "bao_cao_nhiem_vu": "bao_cao.view",
    "bao_cao_kien_nghi": "bao_cao.view",
    "bao_cao_cuoc_hop": "bao_cao.view",
    "xem_bao_cao": "bao_cao.view",
    "them_bao_cao": "bao_cao.manage",
    "sua_bao_cao": "bao_cao.manage",
    "xoa_bao_cao": "bao_cao.manage",
}

NAV_PERMISSIONS = {
    "dashboard": "dashboard.view",
    "nguoi_dung": "nguoi_dung.manage",
    "cong_van_di": "cong_van_di.view",
    "cong_van_den": "cong_van_den.view",
    "phan_cong": "phan_cong.view",
    "kien_nghi": "kien_nghi.view",
    "cuoc_hop": "cuoc_hop.view",
    "bao_cao": "bao_cao.view",
}

PERMISSION_LABELS = {
    "dashboard.view": "Dashboard",
    "account.change_password": "Đổi mật khẩu",
    "system.backup_restore": "Sao lưu và khôi phục dữ liệu",
    "nguoi_dung.manage": "Quản lý người dùng",
    "cong_van_den.view": "Xem công văn đến",
    "cong_van_den.manage": "Tạo/sửa/xóa công văn đến",
    "cong_van_den.update_status": "Cập nhật trạng thái công văn đến",
    "cong_van_di.view": "Xem công văn đi",
    "cong_van_di.manage": "Tạo/sửa/xóa công văn đi",
    "cong_van_di.approve": "Duyệt công văn đi",
    "cong_van_di.publish": "Phát hành công văn đi",
    "phan_cong.view": "Xem phân công công việc",
    "phan_cong.manage": "Phân công công việc",
    "phan_cong.update_progress": "Cập nhật tiến độ nhiệm vụ",
    "kien_nghi.view": "Xem ý kiến, kiến nghị",
    "kien_nghi.manage": "Tạo/sửa/xóa ý kiến, kiến nghị",
    "kien_nghi.process": "Xử lý ý kiến, kiến nghị",
    "cuoc_hop.view": "Xem hội nghị, cuộc họp",
    "cuoc_hop.manage": "Tạo/sửa/xóa hội nghị, cuộc họp",
    "bao_cao.view": "Xem báo cáo - thống kê",
    "bao_cao.manage": "Lập/cập nhật báo cáo",
}


def bo_dau_tieng_viet(value):
    text = str(value or "").strip().lower().replace("đ", "d")
    text = unicodedata.normalize("NFD", text)
    return "".join(ch for ch in text if unicodedata.category(ch) != "Mn")


def chuan_hoa_vai_tro(vai_tro):
    normalized = bo_dau_tieng_viet(vai_tro)
    role_map = {
        "quan tri vien": "Quản trị viên",
        "admin": "Quản trị viên",
        "administrator": "Quản trị viên",
        "lanh dao": "Lãnh đạo",
        "van thu": "Văn thư",
        "chuyen vien": "Chuyên viên",
        "nguoi dung": "Chuyên viên",
    }
    return role_map.get(normalized, str(vai_tro or "").strip())


def quyen_cua_vai_tro(vai_tro):
    return ROLE_PERMISSIONS.get(chuan_hoa_vai_tro(vai_tro), set())


def vai_tro_co_quyen(vai_tro, permission):
    if not permission:
        return True
    permissions = quyen_cua_vai_tro(vai_tro)
    return "*" in permissions or permission in permissions


def current_user_can(permission):
    return vai_tro_co_quyen(session.get("vai_tro"), permission)


def current_user_can_any(*permissions):
    return any(current_user_can(permission) for permission in permissions)


def can_access_nav(module_key):
    return current_user_can(NAV_PERMISSIONS.get(module_key))


def permission_label(permission):
    return PERMISSION_LABELS.get(permission, permission or "chức năng này")


@app.context_processor
def inject_permission_helpers():
    return {
        "can": current_user_can,
        "can_any": current_user_can_any,
        "can_nav": can_access_nav,
    }


@app.before_request
def kiem_tra_phan_quyen():
    endpoint = request.endpoint

    if not endpoint or endpoint in PUBLIC_ENDPOINTS:
        return None

    if "username" not in session:
        return redirect(url_for("login"))

    if session.get("bat_buoc_doi_mat_khau") and endpoint not in PASSWORD_CHANGE_ALLOWED_ENDPOINTS:
        flash("Tài khoản đăng nhập lần đầu, vui lòng đổi mật khẩu trước khi sử dụng hệ thống.")
        return redirect(url_for("doi_mat_khau"))

    if endpoint in AUTH_ONLY_ENDPOINTS:
        return None

    required_permission = ENDPOINT_PERMISSIONS.get(endpoint)
    if required_permission and not current_user_can(required_permission):
        flash(f"Bạn không có quyền truy cập chức năng: {permission_label(required_permission)}.")

        if request.method == "GET":
            return render_template(
                "403.html",
                ho_ten=session.get("ho_ten", "Người dùng"),
                vai_tro=session.get("vai_tro", "Người dùng"),
                permission=permission_label(required_permission)
            ), 403

        return redirect(request.referrer or url_for("dashboard"))

    return None
# =========================
# ĐĂNG NHẬP
# =========================
@app.route("/", methods=["GET", "POST"])
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        co_cot_doi_mat_khau_lan_dau = dam_bao_cot_doi_mat_khau_lan_dau()
        cot_doi_mat_khau_lan_dau = (
            f"tk.{PASSWORD_FIRST_LOGIN_COLUMN}"
            if co_cot_doi_mat_khau_lan_dau
            else f"CAST(0 AS BIT) AS {PASSWORD_FIRST_LOGIN_COLUMN}"
        )

        conn = None
        cursor = None
        try:
            conn = get_connection()
            cursor = conn.cursor()

            query = f"""
                SELECT 
                    tk.MaTaiKhoan,
                    tk.TenDangNhap,
                    tk.MatKhau,
                    tk.TrangThai,
                    {cot_doi_mat_khau_lan_dau},
                    cb.MaCanBo,
                    cb.HoTen,
                    vt.MaVaiTro,
                    vt.TenVaiTro
                FROM TaiKhoan tk
                JOIN CanBo cb ON tk.MaCanBo = cb.MaCanBo
                JOIN VaiTro vt ON tk.MaVaiTro = vt.MaVaiTro
                WHERE tk.TenDangNhap = ?
            """

            cursor.execute(query, username)
            user = cursor.fetchone()
        except Exception as e:
            log_error_safe("Loi ket noi co so du lieu khi dang nhap:", e)
            flash("Không thể kết nối cơ sở dữ liệu. Vui lòng kiểm tra cấu hình SQL Server trên Azure.")
            return render_template(
                "login.html",
                show_logout_popup=False
            ), 503
        finally:
            if cursor:
                cursor.close()
            if conn:
                conn.close()

        if user:
            trang_thai = str(user.TrangThai).strip()

            if user.MatKhau == password and trang_thai in ["1", "Hoạt động", "Hoat dong"]:
                session["ma_tai_khoan"] = user.MaTaiKhoan
                session["username"] = user.TenDangNhap
                session["ma_can_bo"] = user.MaCanBo
                session["ho_ten"] = user.HoTen
                session["ma_vai_tro"] = user.MaVaiTro
                session["vai_tro"] = user.TenVaiTro
                session["bat_buoc_doi_mat_khau"] = bool(getattr(user, PASSWORD_FIRST_LOGIN_COLUMN, 0))
                if session["bat_buoc_doi_mat_khau"]:
                    flash("Tài khoản đăng nhập lần đầu, vui lòng đổi mật khẩu trước khi sử dụng hệ thống.")
                    return redirect(url_for("doi_mat_khau"))
                session["show_welcome_popup"] = True
                return redirect(url_for("dashboard"))

        flash("Tên tài khoản hoặc mật khẩu không đúng!")

    return render_template(
        "login.html",
        show_logout_popup=session.pop("show_logout_popup", False)
    )


# =========================
# DASHBOARD
# =========================
@app.route("/dashboard")
def dashboard():
    if "username" not in session:
        return redirect(url_for("login"))

    return render_template(
        "dashboard.html",
        show_welcome_popup=session.pop("show_welcome_popup", False),
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng"),

        vbdi_cho_trinh_duyet=count_by_status("VanBanDi", "TrangThai", "Chờ duyệt"),
        vbdi_cho_cap_so=count_by_status("VanBanDi", "TrangThai", "Đã phát hành"),
        vbdi_cho_xu_ly=0,
        vbdi_dang_xu_ly=0,
        vbdi_da_phe_duyet=count_by_status("VanBanDi", "TrangThai", "Đã duyệt"),
        vbdi_tat_ca=count_all("VanBanDi"),
        vbdi_tu_choi_trinh=count_by_status("VanBanDi", "TrangThai", "Yêu cầu chỉnh sửa"),
        vbdi_tu_choi_ky=0,

        vbden_cho_tiep_nhan=count_by_status("VanBanDen", "TrangThaiXuLy", "Chờ tiếp nhận"),
        vbden_cho_xu_ly=count_by_status("VanBanDen", "TrangThaiXuLy", "Đã tiếp nhận"),
        vbden_sap_den_han=0,
        vbden_qua_han=count_by_status("VanBanDen", "TrangThaiXuLy", "Quá hạn"),
        vbden_de_nghi_tra_lai=0,
        vbden_dang_xu_ly=count_by_status("VanBanDen", "TrangThaiXuLy", "Đang xử lý"),
        vbden_da_hoan_thanh=count_by_status("VanBanDen", "TrangThaiXuLy", "Hoàn thành"),
        vbden_nhan_de_biet=0,

        phieu_trinh_cho_xu_ly=count_by_status("NhiemVu", "TrangThai", "Chưa xử lý"),
        phieu_trinh_dang_xu_ly=count_by_status("NhiemVu", "TrangThai", "Đang xử lý"),
        phieu_trinh_da_phe_duyet=count_by_status("NhiemVu", "TrangThai", "Hoàn thành"),
        phieu_trinh_tat_ca=count_all("NhiemVu")
    )


@app.route("/sao-luu-du-lieu")
def sao_luu_du_lieu():
    try:
        backup_file = tao_goi_sao_luu()
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        return send_file(
            backup_file,
            mimetype="application/zip",
            as_attachment=True,
            download_name=f"sao-luu-du-lieu-{timestamp}.zip",
        )
    except Exception as e:
        log_error_safe("Loi sao luu du lieu:", e)
        flash("Không thể tạo bản sao lưu dữ liệu. Vui lòng kiểm tra kết nối cơ sở dữ liệu.")
        return redirect(request.referrer or url_for("dashboard"))


@app.route("/khoi-phuc-du-lieu", methods=["POST"])
def khoi_phuc_du_lieu():
    backup_file = request.files.get("backup_file")
    confirmed = request.form.get("confirm_restore") == "yes"

    if not backup_file or not backup_file.filename:
        flash("Vui lòng chọn file sao lưu để khôi phục.")
        return redirect(request.referrer or url_for("dashboard"))

    if not confirmed:
        flash("Vui lòng xác nhận ghi đè dữ liệu hiện tại trước khi khôi phục.")
        return redirect(request.referrer or url_for("dashboard"))

    if not backup_file.filename.lower().endswith(".zip"):
        flash("File khôi phục phải là bản sao lưu định dạng .zip.")
        return redirect(request.referrer or url_for("dashboard"))

    try:
        result = khoi_phuc_tu_goi_sao_luu(backup_file)
        flash(
            "Khôi phục dữ liệu thành công: "
            f"{result['table_count']} bảng, "
            f"{result['row_count']} dòng dữ liệu, "
            f"{result['file_count']} tệp đính kèm."
        )
    except Exception as e:
        log_error_safe("Loi khoi phuc du lieu:", e)
        flash("Không thể khôi phục dữ liệu từ file đã chọn. Vui lòng kiểm tra lại bản sao lưu.")

    return redirect(request.referrer or url_for("dashboard"))


@app.route("/tim-kiem")
def tim_kiem():
    if "username" not in session:
        return redirect(url_for("login"))

    keyword = request.args.get("keyword", "").strip()
    sections = []
    total_results = 0

    def text(value):
        return "" if value is None else str(value)

    if keyword:
        kw = f"%{keyword}%"
        conn = get_connection()
        cursor = conn.cursor()

        def add_section(title, icon, permission, list_url, query, params, mapper):
            nonlocal total_results

            if not current_user_can(permission):
                return

            cursor.execute(query, *params)
            items = [mapper(row) for row in cursor.fetchall()]

            if items:
                total_results += len(items)
                sections.append({
                    "title": title,
                    "icon": icon,
                    "items": items,
                    "list_url": list_url,
                })

        add_section(
            "Người dùng",
            "bi-people",
            "nguoi_dung.manage",
            url_for("nguoi_dung", keyword=keyword),
            """
                SELECT TOP 8
                    tk.MaTaiKhoan AS Ma,
                    tk.TenDangNhap AS TieuDe,
                    cb.HoTen AS MoTa,
                    vt.TenVaiTro AS PhuDe,
                    tk.TrangThai AS TrangThai
                FROM TaiKhoan tk
                LEFT JOIN CanBo cb ON tk.MaCanBo = cb.MaCanBo
                LEFT JOIN VaiTro vt ON tk.MaVaiTro = vt.MaVaiTro
                WHERE (
                    tk.MaTaiKhoan LIKE ?
                    OR tk.TenDangNhap LIKE ?
                    OR CAST(tk.MaCanBo AS NVARCHAR(50)) LIKE ?
                    OR cb.HoTen LIKE ?
                    OR cb.Email LIKE ?
                    OR CAST(cb.SoDienThoai AS NVARCHAR(50)) LIKE ?
                    OR vt.TenVaiTro LIKE ?
                    OR CAST(tk.TrangThai AS NVARCHAR(50)) LIKE ?
                )
                ORDER BY tk.MaTaiKhoan DESC
            """,
            [kw] * 8,
            lambda row: {
                "title": text(row.TieuDe or row.Ma),
                "subtitle": text(row.MoTa or "Chưa gắn cán bộ"),
                "meta": text(row.PhuDe or row.TrangThai),
                "url": url_for("sua_nguoi_dung", ma_tai_khoan=row.Ma),
            },
        )

        add_section(
            "Công văn đến",
            "bi-inbox",
            "cong_van_den.view",
            url_for("cong_van_den", keyword=keyword),
            """
                SELECT TOP 8
                    vb.MaVanBanDen AS Ma,
                    vb.SoKyHieu AS TieuDe,
                    vb.TrichYeu AS MoTa,
                    vb.CoQuanGui AS PhuDe,
                    vb.TrangThaiXuLy AS TrangThai
                FROM VanBanDen vb
                LEFT JOIN LoaiVanBan lvb ON vb.MaLoaiVanBan = lvb.MaLoaiVanBan
                LEFT JOIN LinhVuc lv ON vb.MaLinhVuc = lv.MaLinhVuc
                LEFT JOIN CanBo cb ON vb.MaNguoiTiepNhan = cb.MaCanBo
                WHERE (
                    vb.MaVanBanDen LIKE ?
                    OR CAST(vb.NgayBanHanh AS NVARCHAR(30)) LIKE ?
                    OR CAST(vb.NgayNhan AS NVARCHAR(30)) LIKE ?
                    OR vb.SoKyHieu LIKE ?
                    OR vb.CoQuanGui LIKE ?
                    OR vb.TrichYeu LIKE ?
                    OR lvb.TenLoaiVanBan LIKE ?
                    OR lv.TenLinhVuc LIKE ?
                    OR cb.HoTen LIKE ?
                    OR vb.TrangThaiXuLy LIKE ?
                    OR vb.GhiChu LIKE ?
                )
                ORDER BY vb.NgayNhan DESC, vb.MaVanBanDen DESC
            """,
            [kw] * 11,
            lambda row: {
                "title": text(row.TieuDe or row.Ma),
                "subtitle": text(row.MoTa),
                "meta": text(row.PhuDe or row.TrangThai),
                "url": url_for("xem_cong_van_den", ma_van_ban_den=row.Ma),
            },
        )

        add_section(
            "Công văn đi",
            "bi-box-arrow-up-right",
            "cong_van_di.view",
            url_for("cong_van_di", keyword=keyword),
            """
                SELECT TOP 8
                    vb.MaVanBanDi AS Ma,
                    vb.SoKyHieu AS TieuDe,
                    vb.TrichYeu AS MoTa,
                    vb.NoiNhan AS PhuDe,
                    vb.TrangThai AS TrangThai
                FROM VanBanDi vb
                LEFT JOIN LoaiVanBan lvb ON vb.MaLoaiVanBan = lvb.MaLoaiVanBan
                LEFT JOIN LinhVuc lv ON vb.MaLinhVuc = lv.MaLinhVuc
                LEFT JOIN CanBo cb1 ON vb.MaNguoiSoan = cb1.MaCanBo
                LEFT JOIN CanBo cb2 ON vb.MaNguoiKy = cb2.MaCanBo
                WHERE (
                    vb.MaVanBanDi LIKE ?
                    OR CAST(vb.NgayBanHanh AS NVARCHAR(30)) LIKE ?
                    OR vb.SoKyHieu LIKE ?
                    OR vb.TrichYeu LIKE ?
                    OR vb.NoiNhan LIKE ?
                    OR lvb.TenLoaiVanBan LIKE ?
                    OR lv.TenLinhVuc LIKE ?
                    OR cb1.HoTen LIKE ?
                    OR cb2.HoTen LIKE ?
                    OR vb.TrangThai LIKE ?
                    OR vb.GhiChu LIKE ?
                )
                ORDER BY vb.NgayBanHanh DESC, vb.MaVanBanDi DESC
            """,
            [kw] * 11,
            lambda row: {
                "title": text(row.TieuDe or row.Ma),
                "subtitle": text(row.MoTa),
                "meta": text(row.PhuDe or row.TrangThai),
                "url": url_for("xem_cong_van_di", ma_van_ban_di=row.Ma),
            },
        )

        add_section(
            "Phân công công việc",
            "bi-journal-check",
            "phan_cong.view",
            url_for("phan_cong", keyword=keyword),
            """
                SELECT TOP 8
                    nv.MaNhiemVu AS Ma,
                    nv.TenNhiemVu AS TieuDe,
                    nv.NoiDung AS MoTa,
                    cb.HoTen AS PhuDe,
                    nv.TrangThai AS TrangThai
                FROM NhiemVu nv
                LEFT JOIN LinhVuc lv ON nv.MaLinhVuc = lv.MaLinhVuc
                LEFT JOIN CanBo cb ON nv.MaNguoiGiao = cb.MaCanBo
                WHERE (
                    nv.MaNhiemVu LIKE ?
                    OR nv.TenNhiemVu LIKE ?
                    OR nv.NoiDung LIKE ?
                    OR lv.TenLinhVuc LIKE ?
                    OR cb.HoTen LIKE ?
                    OR nv.MucDoUuTien LIKE ?
                    OR nv.TrangThai LIKE ?
                    OR nv.GhiChu LIKE ?
                    OR nv.KetQua LIKE ?
                    OR EXISTS (
                        SELECT 1
                        FROM PhanCongNhiemVu pc3
                        JOIN CanBo cb3 ON pc3.MaCanBo = cb3.MaCanBo
                        WHERE pc3.MaNhiemVu = nv.MaNhiemVu
                          AND cb3.HoTen LIKE ?
                    )
                )
                ORDER BY nv.NgayGiao DESC, nv.MaNhiemVu DESC
            """,
            [kw] * 10,
            lambda row: {
                "title": text(row.TieuDe or row.Ma),
                "subtitle": text(row.MoTa),
                "meta": text(row.PhuDe or row.TrangThai),
                "url": url_for("xem_nhiem_vu", ma_nhiem_vu=row.Ma),
            },
        )

        add_section(
            "Ý kiến, kiến nghị",
            "bi-chat-left-text",
            "kien_nghi.view",
            url_for("kien_nghi", keyword=keyword),
            """
                SELECT TOP 8
                    yk.MaKienNghi AS Ma,
                    yk.NguoiKienNghi AS TieuDe,
                    yk.NoiDungKienNghi AS MoTa,
                    kp.TenKhuPho AS PhuDe,
                    yk.TrangThai AS TrangThai
                FROM YKienKienNghi yk
                LEFT JOIN KhuPho kp ON yk.MaKhuPho = kp.MaKhuPho
                LEFT JOIN LinhVuc lv ON yk.MaLinhVuc = lv.MaLinhVuc
                WHERE (
                    yk.MaKienNghi LIKE ?
                    OR yk.NoiDungKienNghi LIKE ?
                    OR yk.NguoiKienNghi LIKE ?
                    OR kp.TenKhuPho LIKE ?
                    OR lv.TenLinhVuc LIKE ?
                    OR yk.TrangThai LIKE ?
                    OR yk.GhiChu LIKE ?
                    OR EXISTS (
                        SELECT 1
                        FROM XuLyKienNghi xl3
                        JOIN CanBo cb3 ON xl3.MaCanBo = cb3.MaCanBo
                        WHERE xl3.MaKienNghi = yk.MaKienNghi
                          AND cb3.HoTen LIKE ?
                    )
                )
                ORDER BY yk.NgayTiepNhan DESC, yk.MaKienNghi DESC
            """,
            [kw] * 8,
            lambda row: {
                "title": text(row.TieuDe or row.Ma),
                "subtitle": text(row.MoTa),
                "meta": text(row.PhuDe or row.TrangThai),
                "url": url_for("xem_kien_nghi", ma_kien_nghi=row.Ma),
            },
        )

        add_section(
            "Hội nghị, cuộc họp",
            "bi-calendar-event",
            "cuoc_hop.view",
            url_for("cuoc_hop", keyword=keyword),
            """
                SELECT TOP 8
                    ch.MaCuocHop AS Ma,
                    ch.TenCuocHop AS TieuDe,
                    ch.NoiDung AS MoTa,
                    ch.DiaDiem AS PhuDe,
                    cb.HoTen AS TrangThai
                FROM HOINGHICUOCHOP ch
                LEFT JOIN CANBO cb ON ch.MaNguoiChuTri = cb.MaCanBo
                WHERE (
                    ch.MaCuocHop LIKE ?
                    OR ch.TenCuocHop LIKE ?
                    OR ch.NoiDung LIKE ?
                    OR ch.DiaDiem LIKE ?
                    OR cb.HoTen LIKE ?
                    OR ch.GhiChu LIKE ?
                    OR EXISTS (
                        SELECT 1
                        FROM THANHPHANTHAMDU tp3
                        JOIN CANBO cb3 ON tp3.MaCanBo = cb3.MaCanBo
                        LEFT JOIN BOPHAN bp3 ON cb3.MaBoPhan = bp3.MaBoPhan
                        WHERE tp3.MaCuocHop = ch.MaCuocHop
                          AND bp3.TenBoPhan LIKE ?
                    )
                )
                ORDER BY ch.MaCuocHop DESC
            """,
            [kw] * 7,
            lambda row: {
                "title": text(row.TieuDe or row.Ma),
                "subtitle": text(row.MoTa),
                "meta": text(row.PhuDe or row.TrangThai),
                "url": url_for("xem_cuoc_hop", ma_cuoc_hop=row.Ma),
            },
        )

        add_section(
            "Báo cáo",
            "bi-bar-chart",
            "bao_cao.view",
            url_for("bao_cao", keyword=keyword),
            """
                SELECT TOP 8
                    bc.MaBaoCao AS Ma,
                    bc.TenBaoCao AS TieuDe,
                    bc.NoiDungBaoCao AS MoTa,
                    bc.LoaiBaoCao AS PhuDe,
                    cb.HoTen AS TrangThai
                FROM BAOCAO bc
                LEFT JOIN LINHVUC lv ON bc.MaLinhVuc = lv.MaLinhVuc
                LEFT JOIN CANBO cb ON bc.MaNguoiLap = cb.MaCanBo
                WHERE (
                    bc.MaBaoCao LIKE ?
                    OR bc.TenBaoCao LIKE ?
                    OR bc.LoaiBaoCao LIKE ?
                    OR bc.NoiDungBaoCao LIKE ?
                    OR cb.HoTen LIKE ?
                    OR lv.TenLinhVuc LIKE ?
                    OR bc.GhiChu LIKE ?
                    OR bc.TepBaoCao LIKE ?
                )
                ORDER BY bc.NgayLap DESC, bc.MaBaoCao DESC
            """,
            [kw] * 8,
            lambda row: {
                "title": text(row.TieuDe or row.Ma),
                "subtitle": text(row.MoTa),
                "meta": text(row.PhuDe or row.TrangThai),
                "url": url_for("xem_bao_cao", ma_bao_cao=row.Ma),
            },
        )

        cursor.close()
        conn.close()

    return render_template(
        "tim_kiem.html",
        keyword=keyword,
        sections=sections,
        total_results=total_results,
        ho_ten=session.get("ho_ten", "Nguoi dung"),
        vai_tro=session.get("vai_tro", "Nguoi dung")
    )


# =========================
# QUẢN LÝ NGƯỜI DÙNG
# =========================
def tao_ma_tai_khoan():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT MaTaiKhoan 
        FROM TaiKhoan
        WHERE MaTaiKhoan LIKE 'TK%'
    """)

    rows = cursor.fetchall()

    max_num = 0
    for row in rows:
        ma = str(row.MaTaiKhoan).strip()
        so = ma.replace("TK", "")
        if so.isdigit():
            max_num = max(max_num, int(so))

    cursor.close()
    conn.close()

    return f"TK{max_num + 1:03d}"


@app.route("/nguoi-dung")
def nguoi_dung():
    if "username" not in session:
        return redirect(url_for("login"))

    keyword = request.args.get("keyword", "").strip()

    conn = get_connection()
    cursor = conn.cursor()

    query = """
        SELECT 
            tk.MaTaiKhoan,
            tk.TenDangNhap,
            tk.TrangThai,
            cb.HoTen,
            cb.Email,
            cb.SoDienThoai,
            vt.TenVaiTro
        FROM TaiKhoan tk
        LEFT JOIN CanBo cb ON tk.MaCanBo = cb.MaCanBo
        LEFT JOIN VaiTro vt ON tk.MaVaiTro = vt.MaVaiTro
    """

    params = []
    if keyword:
        query += """
            WHERE (
                tk.MaTaiKhoan LIKE ?
                OR tk.TenDangNhap LIKE ?
                OR CAST(tk.MaCanBo AS NVARCHAR(50)) LIKE ?
                OR cb.HoTen LIKE ?
                OR cb.Email LIKE ?
                OR CAST(cb.SoDienThoai AS NVARCHAR(50)) LIKE ?
                OR vt.TenVaiTro LIKE ?
                OR CAST(tk.TrangThai AS NVARCHAR(50)) LIKE ?
            )
        """
        kw = f"%{keyword}%"
        params.extend([kw, kw, kw, kw, kw, kw, kw, kw])

    query += " ORDER BY tk.MaTaiKhoan DESC"

    if params:
        cursor.execute(query, *params)
    else:
        cursor.execute(query)
    users = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template(
        "nguoi_dung.html",
        users=users,
        keyword=keyword,
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )




@app.route("/nguoi-dung/khoa/<ma_tai_khoan>")
def khoa_nguoi_dung(ma_tai_khoan):
    if "username" not in session:
        return redirect(url_for("login"))

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT TrangThai FROM TaiKhoan WHERE MaTaiKhoan = ?", ma_tai_khoan)
    user = cursor.fetchone()

    if user:
        trang_thai_hien_tai = str(user.TrangThai).strip()

        if trang_thai_hien_tai in ["1", "Hoạt động", "Hoat dong"]:
            trang_thai_moi = "Khóa"
        else:
            trang_thai_moi = "Hoạt động"

        cursor.execute("""
            UPDATE TaiKhoan
            SET TrangThai = ?
            WHERE MaTaiKhoan = ?
        """, trang_thai_moi, ma_tai_khoan)

        conn.commit()

    cursor.close()
    conn.close()

    keyword = request.args.get("keyword", "").strip()
    if keyword:
        return redirect(url_for("nguoi_dung", keyword=keyword))

    return redirect(url_for("nguoi_dung"))


# =========================
# QUẢN LÝ CÔNG VĂN ĐẾN
# =========================
def tao_ma_van_ban_den():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT MaVanBanDen
        FROM VanBanDen
        WHERE MaVanBanDen LIKE 'VBDEN%'
    """)

    rows = cursor.fetchall()

    max_num = 0
    for row in rows:
        ma = str(row.MaVanBanDen).strip()
        so = ma.replace("VBDEN", "")
        if so.isdigit():
            max_num = max(max_num, int(so))

    cursor.close()
    conn.close()

    return f"VBDEN{max_num + 1:03d}"


def tao_so_ky_hieu_cong_van_den():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT SoKyHieu
        FROM VanBanDen
        WHERE SoKyHieu LIKE '%/CV-DEN'
           OR SoKyHieu LIKE '%/CV-DEN'
    """)

    rows = cursor.fetchall()

    max_num = 0

    for row in rows:
        so_ky_hieu = str(row.SoKyHieu).strip()

        try:
            phan_so = so_ky_hieu.split("/")[0].strip()

            if phan_so.isdigit():
                max_num = max(max_num, int(phan_so))
        except:
            pass

    cursor.close()
    conn.close()

    so_moi = max_num + 1

    return f"{so_moi}/CV-DEN"


def lay_du_lieu_form_cong_van_den():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT MaLoaiVanBan, TenLoaiVanBan 
        FROM LoaiVanBan 
        ORDER BY TenLoaiVanBan
    """)
    loai_van_ban_list = cursor.fetchall()

    cursor.execute("""
        SELECT MaLinhVuc, TenLinhVuc 
        FROM LinhVuc 
        ORDER BY TenLinhVuc
    """)
    linh_vuc_list = cursor.fetchall()

    # MaNguoiTiepNhan trong CSDL sẽ dùng để lưu LÃNH ĐẠO XỬ LÝ
    cursor.execute("""
        SELECT cb.MaCanBo, cb.HoTen
        FROM CanBo cb
        LEFT JOIN TaiKhoan tk ON cb.MaCanBo = tk.MaCanBo
        LEFT JOIN VaiTro vt ON tk.MaVaiTro = vt.MaVaiTro
        WHERE vt.TenVaiTro IN (N'Lãnh đạo', N'Quản trị viên')
        ORDER BY cb.HoTen
    """)
    lanh_dao_list = cursor.fetchall()

    cursor.close()
    conn.close()

    return {
        "loai_van_ban_list": loai_van_ban_list,
        "linh_vuc_list": linh_vuc_list,
        "lanh_dao_list": lanh_dao_list
    }


def luu_file_dinh_kem(files, ma_doi_tuong, folder, folder_db, doi_tuong_lien_ket, ghi_chu):
    valid_files = [
        file for file in (files or [])
        if file and file.filename and allowed_file(file.filename)
    ]

    if not valid_files:
        return

    os.makedirs(folder, exist_ok=True)

    conn = get_connection()
    cursor = conn.cursor()
    duong_dan_da_luu = []

    try:
        ma_tep_bat_dau = tao_ma_tep(cursor)
        so_tep_tiep_theo = int(str(ma_tep_bat_dau).replace("TEP", ""))

        for file in valid_files:
            ext = file.filename.rsplit(".", 1)[1].lower()
            ten_goc = secure_filename(file.filename) or f"tep.{ext}"

            ten_luu = f"{uuid.uuid4().hex}_{ten_goc}"
            duong_dan_luu = os.path.join(folder, ten_luu)
            file.save(duong_dan_luu)
            duong_dan_da_luu.append(duong_dan_luu)

            ma_tep = f"TEP{so_tep_tiep_theo:03d}"
            so_tep_tiep_theo += 1
            duong_dan_db = f"{folder_db}/{ten_luu}"

            cursor.execute("""
                INSERT INTO TepDinhKem
                (
                    MaTep, TenTep, DuongDanTep, LoaiTep,
                    DoiTuongLienKet, MaDoiTuong, MaNguoiTaiLen,
                    NgayTaiLen, GhiChu
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, GETDATE(), ?)
            """,
                ma_tep,
                file.filename,
                duong_dan_db,
                ext,
                doi_tuong_lien_ket,
                ma_doi_tuong,
                session.get("ma_tai_khoan"),
                ghi_chu
            )

        conn.commit()
    except Exception:
        conn.rollback()
        for duong_dan_luu in duong_dan_da_luu:
            if os.path.exists(duong_dan_luu):
                os.remove(duong_dan_luu)
        raise
    finally:
        cursor.close()
        conn.close()


def luu_file_cong_van_den(files, ma_van_ban_den):
    luu_file_dinh_kem(
        files,
        ma_van_ban_den,
        "static/uploads/cong_van_den",
        "uploads/cong_van_den",
        "VanBanDen",
        "Tệp đính kèm công văn đến"
    )


def lay_file_cong_van_den(ma_van_ban_den):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT MaTep, TenTep, DuongDanTep, LoaiTep, NgayTaiLen
        FROM TepDinhKem
        WHERE DoiTuongLienKet = 'VanBanDen'
          AND MaDoiTuong = ?
        ORDER BY NgayTaiLen DESC
    """, ma_van_ban_den)

    tep_list = cursor.fetchall()

    cursor.close()
    conn.close()

    return tep_list


@app.route("/cong-van-den")
def cong_van_den():
    if "username" not in session:
        return redirect(url_for("login"))

    keyword = request.args.get("keyword", "").strip()
    trang_thai = request.args.get("trang_thai", "").strip()

    conn = get_connection()
    cursor = conn.cursor()

    query = """
        SELECT 
            vb.MaVanBanDen,
            vb.SoKyHieu,
            vb.NgayBanHanh,
            vb.NgayNhan,
            lvb.TenLoaiVanBan,
            lv.TenLinhVuc,
            vb.CoQuanGui,
            vb.TrichYeu,
            vb.ThoiHanXuLy,
            cb.HoTen AS LanhDaoXuLy,
            vb.TrangThaiXuLy,
            vb.GhiChu
        FROM VanBanDen vb
        LEFT JOIN LoaiVanBan lvb ON vb.MaLoaiVanBan = lvb.MaLoaiVanBan
        LEFT JOIN LinhVuc lv ON vb.MaLinhVuc = lv.MaLinhVuc
        LEFT JOIN CanBo cb ON vb.MaNguoiTiepNhan = cb.MaCanBo
        WHERE 1 = 1
    """

    params = []

    if keyword:
        query += """
            AND (
                vb.MaVanBanDen LIKE ?
                OR CAST(vb.NgayBanHanh AS NVARCHAR(30)) LIKE ?
                OR CAST(vb.NgayNhan AS NVARCHAR(30)) LIKE ?
                OR vb.SoKyHieu LIKE ?
                OR vb.CoQuanGui LIKE ?
                OR vb.TrichYeu LIKE ?
                OR lvb.TenLoaiVanBan LIKE ?
                OR lv.TenLinhVuc LIKE ?
                OR cb.HoTen LIKE ?
                OR vb.TrangThaiXuLy LIKE ?
                OR vb.GhiChu LIKE ?
            )
        """
        kw = f"%{keyword}%"
        params.extend([kw, kw, kw, kw, kw, kw, kw, kw, kw, kw, kw])

    if trang_thai:
        query += " AND LTRIM(RTRIM(vb.TrangThaiXuLy)) = ?"
        params.append(trang_thai)

    query += " ORDER BY vb.NgayNhan DESC, vb.MaVanBanDen DESC"

    cursor.execute(query, *params)
    van_ban_den_list = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template(
        "cong_van_den.html",
        van_ban_den_list=van_ban_den_list,
        keyword=keyword,
        trang_thai=trang_thai,
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/cong-van-den/them", methods=["GET", "POST"])
def them_cong_van_den():
    if "username" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        so_ky_hieu = request.form.get("so_ky_hieu")
        ngay_ban_hanh = parse_date_ddmmyyyy(request.form.get("ngay_ban_hanh"))
        ngay_nhan = parse_date_ddmmyyyy(request.form.get("ngay_nhan"))
        ma_loai_van_ban = request.form.get("ma_loai_van_ban")
        ma_linh_vuc = request.form.get("ma_linh_vuc")
        co_quan_gui = request.form.get("co_quan_gui")
        trich_yeu = request.form.get("trich_yeu")
        thoi_han_xu_ly = parse_date_ddmmyyyy(request.form.get("thoi_han_xu_ly"))
        ma_nguoi_tiep_nhan = request.form.get("ma_nguoi_tiep_nhan")
        trang_thai_xu_ly = request.form.get("trang_thai_xu_ly")
        ghi_chu = request.form.get("ghi_chu")

        try:
            ma_van_ban_den = tao_ma_van_ban_den()

            conn = get_connection()
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO VanBanDen
                (
                    MaVanBanDen, SoKyHieu, NgayBanHanh, NgayNhan,
                    MaLoaiVanBan, MaLinhVuc, CoQuanGui, TrichYeu,
                    ThoiHanXuLy, MaNguoiTiepNhan, TrangThaiXuLy, GhiChu
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
                ma_van_ban_den, so_ky_hieu, ngay_ban_hanh, ngay_nhan,
                ma_loai_van_ban, ma_linh_vuc, co_quan_gui, trich_yeu,
                thoi_han_xu_ly, ma_nguoi_tiep_nhan, trang_thai_xu_ly, ghi_chu
            )

            conn.commit()
            cursor.close()
            conn.close()

            files = request.files.getlist("tep_dinh_kem")
            luu_file_cong_van_den(files, ma_van_ban_den)

            flash("Tiếp nhận công văn đến thành công!")
            return redirect(url_for("cong_van_den"))

        except Exception as e:
            print("Lỗi tiếp nhận công văn đến:", e)
            flash("Lỗi khi tiếp nhận công văn đến. Kiểm tra dữ liệu nhập hoặc file đính kèm.")

    data = lay_du_lieu_form_cong_van_den()
    so_ky_hieu_tu_dong = tao_so_ky_hieu_cong_van_den()

    return render_template(
        "cong_van_den_form.html",
        action="them",
        van_ban=None,
        tep_list=[],
        so_ky_hieu_tu_dong=so_ky_hieu_tu_dong,
        **data,
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/cong-van-den/sua/<ma_van_ban_den>", methods=["GET", "POST"])
def sua_cong_van_den(ma_van_ban_den):
    if "username" not in session:
        return redirect(url_for("login"))

    conn = get_connection()
    cursor = conn.cursor()

    if request.method == "POST":
        so_ky_hieu = request.form.get("so_ky_hieu")
        ngay_ban_hanh = parse_date_ddmmyyyy(request.form.get("ngay_ban_hanh"))
        ngay_nhan = parse_date_ddmmyyyy(request.form.get("ngay_nhan"))
        ma_loai_van_ban = request.form.get("ma_loai_van_ban")
        ma_linh_vuc = request.form.get("ma_linh_vuc")
        co_quan_gui = request.form.get("co_quan_gui")
        trich_yeu = request.form.get("trich_yeu")
        thoi_han_xu_ly = parse_date_ddmmyyyy(request.form.get("thoi_han_xu_ly"))
        ma_nguoi_tiep_nhan = request.form.get("ma_nguoi_tiep_nhan")
        trang_thai_xu_ly = request.form.get("trang_thai_xu_ly")
        ghi_chu = request.form.get("ghi_chu")

        try:
            cursor.execute("""
                UPDATE VanBanDen
                SET 
                    SoKyHieu = ?,
                    NgayBanHanh = ?,
                    NgayNhan = ?,
                    MaLoaiVanBan = ?,
                    MaLinhVuc = ?,
                    CoQuanGui = ?,
                    TrichYeu = ?,
                    ThoiHanXuLy = ?,
                    MaNguoiTiepNhan = ?,
                    TrangThaiXuLy = ?,
                    GhiChu = ?
                WHERE MaVanBanDen = ?
            """,
                so_ky_hieu, ngay_ban_hanh, ngay_nhan,
                ma_loai_van_ban, ma_linh_vuc, co_quan_gui, trich_yeu,
                thoi_han_xu_ly, ma_nguoi_tiep_nhan,
                trang_thai_xu_ly, ghi_chu, ma_van_ban_den
            )

            conn.commit()
            cursor.close()
            conn.close()

            files = request.files.getlist("tep_dinh_kem")
            luu_file_cong_van_den(files, ma_van_ban_den)

            flash("Cập nhật công văn đến thành công!")
            return redirect(url_for("cong_van_den"))

        except Exception as e:
            conn.rollback()
            print("Lỗi sửa công văn đến:", e)
            flash("Lỗi khi cập nhật công văn đến.")

    cursor.execute("""
        SELECT 
            MaVanBanDen, SoKyHieu, NgayBanHanh, NgayNhan,
            MaLoaiVanBan, MaLinhVuc, CoQuanGui, TrichYeu,
            ThoiHanXuLy, MaNguoiTiepNhan,
            TrangThaiXuLy, GhiChu
        FROM VanBanDen
        WHERE MaVanBanDen = ?
    """, ma_van_ban_den)

    van_ban = cursor.fetchone()

    cursor.close()
    conn.close()

    if not van_ban:
        flash("Không tìm thấy công văn đến cần sửa.")
        return redirect(url_for("cong_van_den"))

    data = lay_du_lieu_form_cong_van_den()
    tep_list = lay_file_cong_van_den(ma_van_ban_den)

    return render_template(
        "cong_van_den_form.html",
        action="sua",
        van_ban=van_ban,
        tep_list=tep_list,
        **data,
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/cong-van-den/xem/<ma_van_ban_den>")
def xem_cong_van_den(ma_van_ban_den):
    if "username" not in session:
        return redirect(url_for("login"))

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT 
            vb.MaVanBanDen,
            vb.SoKyHieu,
            vb.NgayBanHanh,
            vb.NgayNhan,
            lvb.TenLoaiVanBan,
            lv.TenLinhVuc,
            vb.CoQuanGui,
            vb.TrichYeu,
            vb.ThoiHanXuLy,
            cb.HoTen AS LanhDaoXuLy,
            vb.TrangThaiXuLy,
            vb.GhiChu
        FROM VanBanDen vb
        LEFT JOIN LoaiVanBan lvb ON vb.MaLoaiVanBan = lvb.MaLoaiVanBan
        LEFT JOIN LinhVuc lv ON vb.MaLinhVuc = lv.MaLinhVuc
        LEFT JOIN CanBo cb ON vb.MaNguoiTiepNhan = cb.MaCanBo
        WHERE vb.MaVanBanDen = ?
    """, ma_van_ban_den)

    van_ban = cursor.fetchone()

    cursor.close()
    conn.close()

    if not van_ban:
        flash("Không tìm thấy công văn đến.")
        return redirect(url_for("cong_van_den"))

    tep_list = lay_file_cong_van_den(ma_van_ban_den)

    return render_template(
        "cong_van_den_chi_tiet.html",
        van_ban=van_ban,
        tep_list=tep_list,
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/cong-van-den/cap-nhat-trang-thai/<ma_van_ban_den>/<trang_thai>", methods=["POST"])
def cap_nhat_trang_thai_cong_van_den(ma_van_ban_den, trang_thai):
    if "username" not in session:
        return redirect(url_for("login"))

    trang_thai_map = {
        "da-tiep-nhan": "Đã tiếp nhận",
        "dang-xu-ly": "Đang xử lý",
        "hoan-thanh": "Hoàn thành",
        "qua-han": "Quá hạn"
    }

    trang_thai_moi = trang_thai_map.get(trang_thai, "Đã tiếp nhận")

    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE VanBanDen
            SET TrangThaiXuLy = ?
            WHERE MaVanBanDen = ?
        """, trang_thai_moi, ma_van_ban_den)

        conn.commit()
        cursor.close()
        conn.close()

        flash("Cập nhật trạng thái công văn đến thành công!")

    except Exception as e:
        print("Lỗi cập nhật trạng thái công văn đến:", e)
        flash("Không thể cập nhật trạng thái công văn đến.")

    return redirect(url_for("cong_van_den"))


@app.route("/cong-van-den/xoa/<ma_van_ban_den>", methods=["POST"])
def xoa_cong_van_den(ma_van_ban_den):
    if "username" not in session:
        return redirect(url_for("login"))

    try:
        tep_list = lay_file_cong_van_den(ma_van_ban_den)

        for tep in tep_list:
            duong_dan_file = os.path.join("static", str(tep.DuongDanTep).replace("/", os.sep))
            if os.path.exists(duong_dan_file):
                os.remove(duong_dan_file)

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            DELETE FROM TepDinhKem
            WHERE DoiTuongLienKet = 'VanBanDen'
              AND MaDoiTuong = ?
        """, ma_van_ban_den)

        cursor.execute("""
            DELETE FROM VanBanDen
            WHERE MaVanBanDen = ?
        """, ma_van_ban_den)

        conn.commit()
        cursor.close()
        conn.close()

        flash("Xóa công văn đến thành công!")

    except Exception as e:
        print("Lỗi xóa công văn đến:", e)
        flash("Không thể xóa công văn đến. Có thể dữ liệu đang liên kết với bảng khác.")

    return redirect(url_for("cong_van_den"))


@app.route("/cong-van-den/xoa-tep/<ma_tep>/<ma_van_ban_den>", methods=["POST"])
def xoa_tep_cong_van_den(ma_tep, ma_van_ban_den):
    if "username" not in session:
        return redirect(url_for("login"))

    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT DuongDanTep
            FROM TepDinhKem
            WHERE MaTep = ?
        """, ma_tep)

        tep = cursor.fetchone()

        if tep:
            duong_dan_file = os.path.join("static", str(tep.DuongDanTep).replace("/", os.sep))

            if os.path.exists(duong_dan_file):
                os.remove(duong_dan_file)

            cursor.execute("""
                DELETE FROM TepDinhKem
                WHERE MaTep = ?
            """, ma_tep)

            conn.commit()
            flash("Xóa tệp đính kèm thành công!")

        cursor.close()
        conn.close()

    except Exception as e:
        print("Lỗi xóa tệp công văn đến:", e)
        flash("Không thể xóa tệp đính kèm.")

    return redirect(url_for("sua_cong_van_den", ma_van_ban_den=ma_van_ban_den))


# =========================
# ROUTE TẠM CHO CÁC CHỨC NĂNG KHÁC
# =========================

@app.route("/change-password")
def change_password():
    return redirect(url_for("doi_mat_khau"))


@app.route("/forgot-password")
def forgot_password():
    return "Chức năng quên mật khẩu đang được phát triển."

@app.route("/mobile-app")
def mobile_app():
    return render_template("mobile_app.html")

@app.route("/logout")
def logout():
    session.clear()
    session["show_logout_popup"] = True
    return redirect(url_for("login"))

# =========================
# QUẢN LÝ HỘI NGHỊ, CUỘC HỌP
# Hiển thị thành phần tham dự theo BỘ PHẬN
# =========================

def tao_ma_cuoc_hop():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT MaCuocHop
        FROM HOINGHICUOCHOP
        WHERE MaCuocHop IS NOT NULL
    """)

    rows = cursor.fetchall()

    max_num = 0

    for row in rows:
        ma = str(row.MaCuocHop).strip().upper()

        if ma.startswith("CH"):
            phan_so = ma.replace("CH", "").strip()

            if phan_so.isdigit():
                max_num = max(max_num, int(phan_so))

    cursor.close()
    conn.close()

    return f"CH{max_num + 1:03d}"


def lay_so_thu_tu_cuoc_hop(ma_cuoc_hop):
    ma = str(ma_cuoc_hop or "").strip().upper()
    phan_so = ma[2:] if ma.startswith("CH") else ma
    digits = "".join(ch for ch in phan_so if ch.isdigit())
    return int(digits) if digits else -1


def lay_du_lieu_form_cuoc_hop():
    conn = get_connection()
    cursor = conn.cursor()

    # Chủ trì: chỉ lấy lãnh đạo hoặc quản trị viên
    cursor.execute("""
        SELECT cb.MaCanBo, cb.HoTen, vt.TenVaiTro
        FROM CANBO cb
        LEFT JOIN TAIKHOAN tk ON cb.MaCanBo = tk.MaCanBo
        LEFT JOIN VAITRO vt ON tk.MaVaiTro = vt.MaVaiTro
        WHERE vt.TenVaiTro IN (N'Lãnh đạo', N'Quản trị viên')
        ORDER BY cb.HoTen
    """)
    chu_tri_list = cursor.fetchall()

    # Thành phần tham dự: chọn theo bộ phận
    cursor.execute("""
        SELECT MaBoPhan, TenBoPhan
        FROM BOPHAN
        ORDER BY TenBoPhan
    """)
    bo_phan_list = [
        bp for bp in cursor.fetchall()
        if bo_dau_tieng_viet(bp.TenBoPhan) != "quan tri he thong"
    ]

    cursor.close()
    conn.close()

    return {
        "chu_tri_list": chu_tri_list,
        "bo_phan_list": bo_phan_list
    }


@app.route("/cuoc-hop")
def cuoc_hop():
    if "username" not in session:
        return redirect(url_for("login"))

    keyword = request.args.get("keyword", "").strip()

    conn = get_connection()
    cursor = conn.cursor()

    query = """
        SELECT
            ch.MaCuocHop,
            ch.TenCuocHop,
            ch.NoiDung,
            ch.ThoiGianBatDau,
            ch.ThoiGianKetThuc,
            ch.DiaDiem,
            cb.HoTen AS NguoiChuTri,
            ch.GhiChu,

            -- Hiển thị thành phần tham dự theo BỘ PHẬN, không hiển thị từng người
            STUFF((
                SELECT DISTINCT ', ' + bp2.TenBoPhan
                FROM THANHPHANTHAMDU tp2
                JOIN CANBO cb2 ON tp2.MaCanBo = cb2.MaCanBo
                LEFT JOIN BOPHAN bp2 ON cb2.MaBoPhan = bp2.MaBoPhan
                WHERE tp2.MaCuocHop = ch.MaCuocHop
                  AND bp2.TenBoPhan IS NOT NULL
                FOR XML PATH(''), TYPE
            ).value('.', 'NVARCHAR(MAX)'), 1, 2, '') AS BoPhanThamDu

        FROM HOINGHICUOCHOP ch
        LEFT JOIN CANBO cb ON ch.MaNguoiChuTri = cb.MaCanBo
        WHERE 1 = 1
    """

    params = []

    if keyword:
        query += """
            AND (
                ch.MaCuocHop LIKE ?
                OR ch.TenCuocHop LIKE ?
                OR ch.NoiDung LIKE ?
                OR ch.DiaDiem LIKE ?
                OR cb.HoTen LIKE ?
                OR ch.GhiChu LIKE ?
                OR EXISTS (
                    SELECT 1
                    FROM THANHPHANTHAMDU tp3
                    JOIN CANBO cb3 ON tp3.MaCanBo = cb3.MaCanBo
                    LEFT JOIN BOPHAN bp3 ON cb3.MaBoPhan = bp3.MaBoPhan
                    WHERE tp3.MaCuocHop = ch.MaCuocHop
                      AND bp3.TenBoPhan LIKE ?
                )
            )
        """
        kw = f"%{keyword}%"
        params.extend([kw, kw, kw, kw, kw, kw, kw])

    query += " ORDER BY ch.MaCuocHop DESC"

    cursor.execute(query, *params)
    cuoc_hop_list = sorted(
        cursor.fetchall(),
        key=lambda row: (lay_so_thu_tu_cuoc_hop(row.MaCuocHop), str(row.MaCuocHop or "")),
        reverse=True
    )

    cursor.close()
    conn.close()

    return render_template(
        "cuoc_hop.html",
        cuoc_hop_list=cuoc_hop_list,
        keyword=keyword,
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/cuoc-hop/them", methods=["GET", "POST"])
def them_cuoc_hop():
    if "username" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        ten_cuoc_hop = request.form.get("ten_cuoc_hop")
        noi_dung = request.form.get("noi_dung")
        thoi_gian_bat_dau, thoi_gian_ket_thuc, loi_thoi_gian = kiem_tra_thoi_gian_cuoc_hop(
            request.form.get("thoi_gian_bat_dau"),
            request.form.get("thoi_gian_ket_thuc")
        )
        dia_diem = request.form.get("dia_diem")
        ma_nguoi_chu_tri = request.form.get("ma_nguoi_chu_tri")
        ghi_chu = request.form.get("ghi_chu")

        # Chọn bộ phận, không chọn từng người
        danh_sach_bo_phan = request.form.getlist("ma_bo_phan_list")
        conn = None

        if loi_thoi_gian:
            flash(loi_thoi_gian)
            data = lay_du_lieu_form_cuoc_hop()
            return render_template(
                "cuoc_hop_form.html",
                action="them",
                cuoc_hop_item=None,
                bo_phan_da_chon=danh_sach_bo_phan,
                **data,
                ho_ten=session.get("ho_ten", "NgÆ°á»i dĂ¹ng"),
                vai_tro=session.get("vai_tro", "NgÆ°á»i dĂ¹ng")
            )

        try:
            ma_cuoc_hop = tao_ma_cuoc_hop()

            conn = get_connection()
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO HOINGHICUOCHOP
                (
                    MaCuocHop, TenCuocHop, ThoiGianBatDau,
                    ThoiGianKetThuc, DiaDiem, NoiDung,
                    MaNguoiChuTri, GhiChu
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
                ma_cuoc_hop, ten_cuoc_hop, thoi_gian_bat_dau,
                thoi_gian_ket_thuc, dia_diem, noi_dung,
                ma_nguoi_chu_tri, ghi_chu
            )

            # Tự thêm toàn bộ cán bộ thuộc bộ phận được chọn vào THANHPHANTHAMDU
            for ma_bo_phan in danh_sach_bo_phan:
                cursor.execute("""
                    SELECT MaCanBo
                    FROM CANBO
                    WHERE MaBoPhan = ?
                      AND (TrangThai IN (N'Hoạt động', '1') OR TrangThai IS NULL)
                """, ma_bo_phan)

                can_bo_thuoc_bo_phan = cursor.fetchall()

                for cb in can_bo_thuoc_bo_phan:
                    cursor.execute("""
                        IF NOT EXISTS (
                            SELECT 1
                            FROM THANHPHANTHAMDU
                            WHERE MaCuocHop = ? AND MaCanBo = ?
                        )
                        BEGIN
                            INSERT INTO THANHPHANTHAMDU
                            (
                                MaCuocHop, MaCanBo, VaiTroThamDu,
                                TrangThaiThamDu, GhiChu
                            )
                            VALUES (?, ?, ?, ?, ?)
                        END
                    """,
                        ma_cuoc_hop, cb.MaCanBo,
                        ma_cuoc_hop, cb.MaCanBo,
                        "Thành viên tham dự",
                        "Chưa xác nhận",
                        "Tham dự theo bộ phận được chọn"
                    )

            conn.commit()
            cursor.close()
            conn.close()

            flash("Tạo hội nghị, cuộc họp thành công!")
            return redirect(url_for("cuoc_hop"))

        except Exception as e:
            if conn:
                conn.rollback()

            print("===== LỖI KHI TẠO CUỘC HỌP =====")
            print(e)
            print("================================")

            flash(f"Lỗi khi tạo cuộc họp: {e}")

    data = lay_du_lieu_form_cuoc_hop()

    return render_template(
        "cuoc_hop_form.html",
        action="them",
        cuoc_hop_item=None,
        bo_phan_da_chon=[],
        **data,
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/cuoc-hop/sua/<ma_cuoc_hop>", methods=["GET", "POST"])
def sua_cuoc_hop(ma_cuoc_hop):
    if "username" not in session:
        return redirect(url_for("login"))

    conn = get_connection()
    cursor = conn.cursor()

    if request.method == "POST":
        ten_cuoc_hop = request.form.get("ten_cuoc_hop")
        noi_dung = request.form.get("noi_dung")
        thoi_gian_bat_dau, thoi_gian_ket_thuc, loi_thoi_gian = kiem_tra_thoi_gian_cuoc_hop(
            request.form.get("thoi_gian_bat_dau"),
            request.form.get("thoi_gian_ket_thuc")
        )
        dia_diem = request.form.get("dia_diem")
        ma_nguoi_chu_tri = request.form.get("ma_nguoi_chu_tri")
        ghi_chu = request.form.get("ghi_chu")

        # Chọn bộ phận, không chọn từng người
        danh_sach_bo_phan = request.form.getlist("ma_bo_phan_list")

        if loi_thoi_gian:
            flash(loi_thoi_gian)
            return redirect(url_for("sua_cuoc_hop", ma_cuoc_hop=ma_cuoc_hop))

        try:
            cursor.execute("""
                UPDATE HOINGHICUOCHOP
                SET
                    TenCuocHop = ?,
                    ThoiGianBatDau = ?,
                    ThoiGianKetThuc = ?,
                    DiaDiem = ?,
                    NoiDung = ?,
                    MaNguoiChuTri = ?,
                    GhiChu = ?
                WHERE MaCuocHop = ?
            """,
                ten_cuoc_hop, thoi_gian_bat_dau,
                thoi_gian_ket_thuc, dia_diem,
                noi_dung, ma_nguoi_chu_tri, ghi_chu,
                ma_cuoc_hop
            )

            # Xóa thành phần cũ
            cursor.execute("""
                DELETE FROM THANHPHANTHAMDU
                WHERE MaCuocHop = ?
            """, ma_cuoc_hop)

            # Thêm lại theo bộ phận mới
            for ma_bo_phan in danh_sach_bo_phan:
                cursor.execute("""
                    SELECT MaCanBo
                    FROM CANBO
                    WHERE MaBoPhan = ?
                      AND (TrangThai IN (N'Hoạt động', '1') OR TrangThai IS NULL)
                """, ma_bo_phan)

                can_bo_thuoc_bo_phan = cursor.fetchall()

                for cb in can_bo_thuoc_bo_phan:
                    cursor.execute("""
                        IF NOT EXISTS (
                            SELECT 1
                            FROM THANHPHANTHAMDU
                            WHERE MaCuocHop = ? AND MaCanBo = ?
                        )
                        BEGIN
                            INSERT INTO THANHPHANTHAMDU
                            (
                                MaCuocHop, MaCanBo, VaiTroThamDu,
                                TrangThaiThamDu, GhiChu
                            )
                            VALUES (?, ?, ?, ?, ?)
                        END
                    """,
                        ma_cuoc_hop, cb.MaCanBo,
                        ma_cuoc_hop, cb.MaCanBo,
                        "Thành viên tham dự",
                        "Chưa xác nhận",
                        "Cập nhật tham dự theo bộ phận"
                    )

            conn.commit()
            cursor.close()
            conn.close()

            flash("Cập nhật cuộc họp thành công!")
            return redirect(url_for("cuoc_hop"))

        except Exception as e:
            conn.rollback()
            print("Lỗi sửa cuộc họp:", e)
            flash("Lỗi khi cập nhật cuộc họp.")

    cursor.execute("""
        SELECT
            MaCuocHop, TenCuocHop, ThoiGianBatDau,
            ThoiGianKetThuc, DiaDiem, NoiDung,
            MaNguoiChuTri, GhiChu
        FROM HOINGHICUOCHOP
        WHERE MaCuocHop = ?
    """, ma_cuoc_hop)

    cuoc_hop_item = cursor.fetchone()

    # Lấy bộ phận đã chọn từ danh sách cán bộ tham dự
    cursor.execute("""
        SELECT DISTINCT cb.MaBoPhan
        FROM THANHPHANTHAMDU tp
        JOIN CANBO cb ON tp.MaCanBo = cb.MaCanBo
        WHERE tp.MaCuocHop = ?
          AND cb.MaBoPhan IS NOT NULL
    """, ma_cuoc_hop)

    bo_phan_da_chon = [str(row.MaBoPhan).strip() for row in cursor.fetchall()]

    cursor.close()
    conn.close()

    if not cuoc_hop_item:
        flash("Không tìm thấy cuộc họp cần sửa.")
        return redirect(url_for("cuoc_hop"))

    data = lay_du_lieu_form_cuoc_hop()

    return render_template(
        "cuoc_hop_form.html",
        action="sua",
        cuoc_hop_item=cuoc_hop_item,
        bo_phan_da_chon=bo_phan_da_chon,
        **data,
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )

@app.route("/cuoc-hop/xem/<ma_cuoc_hop>")
def xem_cuoc_hop(ma_cuoc_hop):
    if "username" not in session:
        return redirect(url_for("login"))

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT
            ch.MaCuocHop,
            ch.TenCuocHop,
            ch.NoiDung,
            ch.ThoiGianBatDau,
            ch.ThoiGianKetThuc,
            ch.DiaDiem,
            cb.HoTen AS NguoiChuTri,
            ch.GhiChu
        FROM HOINGHICUOCHOP ch
        LEFT JOIN CANBO cb ON ch.MaNguoiChuTri = cb.MaCanBo
        WHERE ch.MaCuocHop = ?
    """, ma_cuoc_hop)

    cuoc_hop_item = cursor.fetchone()

    if not cuoc_hop_item:
        cursor.close()
        conn.close()
        flash("Không tìm thấy cuộc họp.")
        return redirect(url_for("cuoc_hop"))

    # Lấy bộ phận + danh sách cán bộ thuộc bộ phận đó
    cursor.execute("""
        SELECT DISTINCT
            bp.MaBoPhan,
            bp.TenBoPhan,
            cb.MaCanBo,
            cb.HoTen,
            vt.TenVaiTro
        FROM THANHPHANTHAMDU tp
        JOIN CANBO cb ON tp.MaCanBo = cb.MaCanBo
        LEFT JOIN BOPHAN bp ON cb.MaBoPhan = bp.MaBoPhan
        LEFT JOIN TAIKHOAN tk ON cb.MaCanBo = tk.MaCanBo
        LEFT JOIN VAITRO vt ON tk.MaVaiTro = vt.MaVaiTro
        WHERE tp.MaCuocHop = ?
          AND bp.MaBoPhan IS NOT NULL
        ORDER BY bp.TenBoPhan, cb.HoTen
    """, ma_cuoc_hop)

    rows = cursor.fetchall()

    cursor.close()
    conn.close()

    # Gom cán bộ theo từng bộ phận để hiển thị đẹp trên giao diện
    bo_phan_dict = {}

    for row in rows:
        ma_bo_phan = str(row.MaBoPhan).strip()

        if ma_bo_phan not in bo_phan_dict:
            bo_phan_dict[ma_bo_phan] = {
                "TenBoPhan": row.TenBoPhan,
                "CanBoList": []
            }

        bo_phan_dict[ma_bo_phan]["CanBoList"].append({
            "HoTen": row.HoTen,
            "TenVaiTro": row.TenVaiTro
        })

    bo_phan_tham_du_list = list(bo_phan_dict.values())

    return render_template(
        "cuoc_hop_chi_tiet.html",
        cuoc_hop_item=cuoc_hop_item,
        bo_phan_tham_du_list=bo_phan_tham_du_list,
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )



@app.route("/cuoc-hop/xoa/<ma_cuoc_hop>", methods=["POST"])
def xoa_cuoc_hop(ma_cuoc_hop):
    if "username" not in session:
        return redirect(url_for("login"))

    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("DELETE FROM THANHPHANTHAMDU WHERE MaCuocHop = ?", ma_cuoc_hop)
        cursor.execute("DELETE FROM HOINGHICUOCHOP WHERE MaCuocHop = ?", ma_cuoc_hop)

        conn.commit()
        cursor.close()
        conn.close()

        flash("Xóa cuộc họp thành công!")

    except Exception as e:
        print("Lỗi xóa cuộc họp:", e)
        flash("Không thể xóa cuộc họp.")

    return redirect(url_for("cuoc_hop"))
# =========================
# QUẢN LÝ Ý KIẾN, KIẾN NGHỊ
# =========================

def tao_ma_kien_nghi():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT MaKienNghi
        FROM YKienKienNghi
        WHERE MaKienNghi LIKE 'KN%'
    """)

    rows = cursor.fetchall()

    max_num = 0
    for row in rows:
        ma = str(row.MaKienNghi).strip()
        so = ma.replace("KN", "")
        if so.isdigit():
            max_num = max(max_num, int(so))

    cursor.close()
    conn.close()

    return f"KN{max_num + 1:03d}"


def lay_du_lieu_form_kien_nghi():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT MaKhuPho, TenKhuPho
        FROM KhuPho
        ORDER BY TenKhuPho
    """)
    khu_pho_list = cursor.fetchall()

    cursor.execute("""
        SELECT MaLinhVuc, TenLinhVuc
        FROM LinhVuc
        ORDER BY TenLinhVuc
    """)
    linh_vuc_list = cursor.fetchall()

    # Cán bộ xử lý: chuyên viên hoặc văn thư
    cursor.execute("""
        SELECT cb.MaCanBo, cb.HoTen, vt.TenVaiTro
        FROM CanBo cb
        LEFT JOIN TaiKhoan tk ON cb.MaCanBo = tk.MaCanBo
        LEFT JOIN VaiTro vt ON tk.MaVaiTro = vt.MaVaiTro
        WHERE vt.TenVaiTro IN (N'Chuyên viên', N'Văn thư')
        ORDER BY cb.HoTen
    """)
    can_bo_list = cursor.fetchall()

    cursor.close()
    conn.close()

    return {
        "khu_pho_list": khu_pho_list,
        "linh_vuc_list": linh_vuc_list,
        "can_bo_list": can_bo_list
    }


@app.route("/kien-nghi")
def kien_nghi():
    if "username" not in session:
        return redirect(url_for("login"))

    keyword = request.args.get("keyword", "").strip()
    trang_thai = request.args.get("trang_thai", "").strip()

    conn = get_connection()
    cursor = conn.cursor()

    query = """
        SELECT
            yk.MaKienNghi,
            yk.NoiDungKienNghi,
            yk.NguoiKienNghi,
            kp.TenKhuPho,
            lv.TenLinhVuc,
            yk.NgayTiepNhan,
            yk.TrangThai,
            yk.GhiChu,
            STUFF((
                SELECT ', ' + cb2.HoTen
                FROM XuLyKienNghi xl2
                JOIN CanBo cb2 ON xl2.MaCanBo = cb2.MaCanBo
                WHERE xl2.MaKienNghi = yk.MaKienNghi
                FOR XML PATH(''), TYPE
            ).value('.', 'NVARCHAR(MAX)'), 1, 2, '') AS CanBoXuLy
        FROM YKienKienNghi yk
        LEFT JOIN KhuPho kp ON yk.MaKhuPho = kp.MaKhuPho
        LEFT JOIN LinhVuc lv ON yk.MaLinhVuc = lv.MaLinhVuc
        WHERE 1 = 1
    """

    params = []

    if keyword:
        query += """
            AND (
                yk.MaKienNghi LIKE ?
                OR yk.NoiDungKienNghi LIKE ?
                OR yk.NguoiKienNghi LIKE ?
                OR kp.TenKhuPho LIKE ?
                OR lv.TenLinhVuc LIKE ?
                OR yk.TrangThai LIKE ?
                OR yk.GhiChu LIKE ?
                OR EXISTS (
                    SELECT 1
                    FROM XuLyKienNghi xl3
                    JOIN CanBo cb3 ON xl3.MaCanBo = cb3.MaCanBo
                    WHERE xl3.MaKienNghi = yk.MaKienNghi
                      AND cb3.HoTen LIKE ?
                )
            )
        """
        kw = f"%{keyword}%"
        params.extend([kw, kw, kw, kw, kw, kw, kw, kw])

    if trang_thai:
        query += " AND LTRIM(RTRIM(yk.TrangThai)) = ?"
        params.append(trang_thai)

    query += " ORDER BY yk.NgayTiepNhan DESC, yk.MaKienNghi DESC"

    cursor.execute(query, *params)
    kien_nghi_list = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template(
        "kien_nghi.html",
        kien_nghi_list=kien_nghi_list,
        keyword=keyword,
        trang_thai=trang_thai,
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/kien-nghi/them", methods=["GET", "POST"])
def them_kien_nghi():
    if "username" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        noi_dung_kien_nghi = request.form.get("noi_dung_kien_nghi")
        nguoi_kien_nghi = request.form.get("nguoi_kien_nghi")
        ma_khu_pho = request.form.get("ma_khu_pho")
        ma_linh_vuc = request.form.get("ma_linh_vuc")
        ngay_tiep_nhan = parse_date_ddmmyyyy(request.form.get("ngay_tiep_nhan"))
        trang_thai = request.form.get("trang_thai")
        ghi_chu = request.form.get("ghi_chu")
        danh_sach_can_bo = request.form.getlist("ma_can_bo_list")

        try:
            ma_kien_nghi = tao_ma_kien_nghi()

            conn = get_connection()
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO YKienKienNghi
                (
                    MaKienNghi, NoiDungKienNghi, NguoiKienNghi,
                    MaKhuPho, MaLinhVuc, NgayTiepNhan,
                    TrangThai, GhiChu
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
                ma_kien_nghi, noi_dung_kien_nghi, nguoi_kien_nghi,
                ma_khu_pho, ma_linh_vuc, ngay_tiep_nhan,
                trang_thai, ghi_chu
            )

            for ma_can_bo in danh_sach_can_bo:
                cursor.execute("""
                    INSERT INTO XuLyKienNghi
                    (
                        MaKienNghi, MaCanBo, NgayXuLy,
                        NoiDungXuLy, KetQuaXuLy, TrangThai, GhiChu
                    )
                    VALUES (?, ?, GETDATE(), ?, ?, ?, ?)
                """,
                    ma_kien_nghi,
                    ma_can_bo,
                    "Được phân công xử lý kiến nghị",
                    "",
                    "Đang xử lý",
                    "Phân công cán bộ xử lý"
                )

            conn.commit()
            cursor.close()
            conn.close()

            flash("Tiếp nhận ý kiến, kiến nghị thành công!")
            return redirect(url_for("kien_nghi"))

        except Exception as e:
            print("Lỗi thêm kiến nghị:", e)
            flash("Lỗi khi tiếp nhận ý kiến, kiến nghị. Kiểm tra dữ liệu nhập.")

    data = lay_du_lieu_form_kien_nghi()

    return render_template(
        "kien_nghi_form.html",
        action="them",
        kien_nghi_item=None,
        bo_phan_da_chon=[],
        **data,
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/kien-nghi/sua/<ma_kien_nghi>", methods=["GET", "POST"])
def sua_kien_nghi(ma_kien_nghi):
    if "username" not in session:
        return redirect(url_for("login"))

    conn = get_connection()
    cursor = conn.cursor()

    if request.method == "POST":
        noi_dung_kien_nghi = request.form.get("noi_dung_kien_nghi")
        nguoi_kien_nghi = request.form.get("nguoi_kien_nghi")
        ma_khu_pho = request.form.get("ma_khu_pho")
        ma_linh_vuc = request.form.get("ma_linh_vuc")
        ngay_tiep_nhan = parse_date_ddmmyyyy(request.form.get("ngay_tiep_nhan"))
        trang_thai = request.form.get("trang_thai")
        ghi_chu = request.form.get("ghi_chu")
        danh_sach_can_bo = request.form.getlist("ma_can_bo_list")

        try:
            cursor.execute("""
                UPDATE YKienKienNghi
                SET
                    NoiDungKienNghi = ?,
                    NguoiKienNghi = ?,
                    MaKhuPho = ?,
                    MaLinhVuc = ?,
                    NgayTiepNhan = ?,
                    TrangThai = ?,
                    GhiChu = ?
                WHERE MaKienNghi = ?
            """,
                noi_dung_kien_nghi, nguoi_kien_nghi,
                ma_khu_pho, ma_linh_vuc, ngay_tiep_nhan,
                trang_thai, ghi_chu, ma_kien_nghi
            )

            cursor.execute("""
                DELETE FROM XuLyKienNghi
                WHERE MaKienNghi = ?
            """, ma_kien_nghi)

            for ma_can_bo in danh_sach_can_bo:
                cursor.execute("""
                    INSERT INTO XuLyKienNghi
                    (
                        MaKienNghi, MaCanBo, NgayXuLy,
                        NoiDungXuLy, KetQuaXuLy, TrangThai, GhiChu
                    )
                    VALUES (?, ?, GETDATE(), ?, ?, ?, ?)
                """,
                    ma_kien_nghi,
                    ma_can_bo,
                    "Cập nhật phân công xử lý kiến nghị",
                    "",
                    trang_thai,
                    "Cập nhật cán bộ xử lý"
                )

            conn.commit()
            cursor.close()
            conn.close()

            flash("Cập nhật ý kiến, kiến nghị thành công!")
            return redirect(url_for("kien_nghi"))

        except Exception as e:
            conn.rollback()
            print("Lỗi sửa kiến nghị:", e)
            flash("Lỗi khi cập nhật ý kiến, kiến nghị.")

    cursor.execute("""
        SELECT
            MaKienNghi, NoiDungKienNghi, NguoiKienNghi,
            MaKhuPho, MaLinhVuc, NgayTiepNhan,
            TrangThai, GhiChu
        FROM YKienKienNghi
        WHERE MaKienNghi = ?
    """, ma_kien_nghi)

    kien_nghi_item = cursor.fetchone()

    cursor.execute("""
        SELECT MaCanBo
        FROM XuLyKienNghi
        WHERE MaKienNghi = ?
    """, ma_kien_nghi)

    can_bo_da_chon = [str(row.MaCanBo).strip() for row in cursor.fetchall()]

    cursor.close()
    conn.close()

    if not kien_nghi_item:
        flash("Không tìm thấy ý kiến, kiến nghị cần sửa.")
        return redirect(url_for("kien_nghi"))

    data = lay_du_lieu_form_kien_nghi()

    return render_template(
        "kien_nghi_form.html",
        action="sua",
        kien_nghi_item=kien_nghi_item,
        can_bo_da_chon=can_bo_da_chon,
        **data,
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/kien-nghi/xem/<ma_kien_nghi>")
def xem_kien_nghi(ma_kien_nghi):
    if "username" not in session:
        return redirect(url_for("login"))

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT
            yk.MaKienNghi,
            yk.NoiDungKienNghi,
            yk.NguoiKienNghi,
            kp.TenKhuPho,
            lv.TenLinhVuc,
            yk.NgayTiepNhan,
            yk.TrangThai,
            yk.GhiChu
        FROM YKienKienNghi yk
        LEFT JOIN KhuPho kp ON yk.MaKhuPho = kp.MaKhuPho
        LEFT JOIN LinhVuc lv ON yk.MaLinhVuc = lv.MaLinhVuc
        WHERE yk.MaKienNghi = ?
    """, ma_kien_nghi)

    kien_nghi_item = cursor.fetchone()

    if not kien_nghi_item:
        cursor.close()
        conn.close()
        flash("Không tìm thấy ý kiến, kiến nghị.")
        return redirect(url_for("kien_nghi"))

    cursor.execute("""
        SELECT
            xl.MaKienNghi,
            xl.MaCanBo,
            cb.HoTen,
            xl.NgayXuLy,
            xl.NoiDungXuLy,
            xl.KetQuaXuLy,
            xl.TrangThai,
            xl.GhiChu
        FROM XuLyKienNghi xl
        LEFT JOIN CanBo cb ON xl.MaCanBo = cb.MaCanBo
        WHERE xl.MaKienNghi = ?
        ORDER BY xl.NgayXuLy DESC
    """, ma_kien_nghi)

    xu_ly_list = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template(
        "kien_nghi_chi_tiet.html",
        kien_nghi_item=kien_nghi_item,
        xu_ly_list=xu_ly_list,
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/kien-nghi/xu-ly/<ma_kien_nghi>", methods=["POST"])
def xu_ly_kien_nghi(ma_kien_nghi):
    if "username" not in session:
        return redirect(url_for("login"))

    noi_dung_xu_ly = request.form.get("noi_dung_xu_ly")
    ket_qua_xu_ly = request.form.get("ket_qua_xu_ly")
    trang_thai = request.form.get("trang_thai")
    ghi_chu = request.form.get("ghi_chu")
    ma_can_bo = session.get("ma_can_bo")

    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO XuLyKienNghi
            (
                MaKienNghi, MaCanBo, NgayXuLy,
                NoiDungXuLy, KetQuaXuLy, TrangThai, GhiChu
            )
            VALUES (?, ?, GETDATE(), ?, ?, ?, ?)
        """,
            ma_kien_nghi, ma_can_bo,
            noi_dung_xu_ly, ket_qua_xu_ly, trang_thai, ghi_chu
        )

        cursor.execute("""
            UPDATE YKienKienNghi
            SET TrangThai = ?
            WHERE MaKienNghi = ?
        """, trang_thai, ma_kien_nghi)

        conn.commit()
        cursor.close()
        conn.close()

        flash("Cập nhật xử lý kiến nghị thành công!")

    except Exception as e:
        print("Lỗi xử lý kiến nghị:", e)
        flash("Lỗi khi cập nhật xử lý kiến nghị.")

    return redirect(url_for("xem_kien_nghi", ma_kien_nghi=ma_kien_nghi))


@app.route("/kien-nghi/cap-nhat-trang-thai/<ma_kien_nghi>/<trang_thai>", methods=["POST"])
def cap_nhat_trang_thai_kien_nghi(ma_kien_nghi, trang_thai):
    if "username" not in session:
        return redirect(url_for("login"))

    trang_thai_map = {
        "da-tiep-nhan": "Đã tiếp nhận",
        "dang-xu-ly": "Đang xử lý",
        "hoan-thanh": "Hoàn thành",
        "qua-han": "Quá hạn"
    }

    trang_thai_moi = trang_thai_map.get(trang_thai, "Đã tiếp nhận")

    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE YKienKienNghi
            SET TrangThai = ?
            WHERE MaKienNghi = ?
        """, trang_thai_moi, ma_kien_nghi)

        cursor.execute("""
            UPDATE XuLyKienNghi
            SET TrangThai = ?
            WHERE MaKienNghi = ?
        """, trang_thai_moi, ma_kien_nghi)

        conn.commit()
        cursor.close()
        conn.close()

        flash("Cập nhật trạng thái kiến nghị thành công!")

    except Exception as e:
        print("Lỗi cập nhật trạng thái kiến nghị:", e)
        flash("Không thể cập nhật trạng thái kiến nghị.")

    return redirect(url_for("kien_nghi"))


@app.route("/kien-nghi/xoa/<ma_kien_nghi>", methods=["POST"])
def xoa_kien_nghi(ma_kien_nghi):
    if "username" not in session:
        return redirect(url_for("login"))

    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("DELETE FROM XuLyKienNghi WHERE MaKienNghi = ?", ma_kien_nghi)
        cursor.execute("DELETE FROM YKienKienNghi WHERE MaKienNghi = ?", ma_kien_nghi)

        conn.commit()
        cursor.close()
        conn.close()

        flash("Xóa ý kiến, kiến nghị thành công!")

    except Exception as e:
        print("Lỗi xóa kiến nghị:", e)
        flash("Không thể xóa ý kiến, kiến nghị.")

    return redirect(url_for("kien_nghi"))
# =========================
# QUẢN LÝ PHÂN CÔNG CÔNG VIỆC
# =========================

def tao_ma_nhiem_vu():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT MaNhiemVu
        FROM NhiemVu
        WHERE MaNhiemVu LIKE 'NV%'
    """)

    rows = cursor.fetchall()

    max_num = 0
    for row in rows:
        ma = str(row.MaNhiemVu).strip()
        so = ma.replace("NV", "")
        if so.isdigit():
            max_num = max(max_num, int(so))

    cursor.close()
    conn.close()

    return f"NV{max_num + 1:03d}"


def tao_ma_tien_do():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT MaTienDo
        FROM TienDoNhiemVu
        WHERE MaTienDo LIKE 'TD%'
    """)

    rows = cursor.fetchall()

    max_num = 0
    for row in rows:
        ma = str(row.MaTienDo).strip()
        so = ma.replace("TD", "")
        if so.isdigit():
            max_num = max(max_num, int(so))

    cursor.close()
    conn.close()

    return f"TD{max_num + 1:03d}"


def lay_du_lieu_form_nhiem_vu():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT MaLinhVuc, TenLinhVuc
        FROM LinhVuc
        ORDER BY TenLinhVuc
    """)
    linh_vuc_list = cursor.fetchall()

    cursor.execute("""
        SELECT MaVanBanDen, SoKyHieu, TrichYeu
        FROM VanBanDen
        ORDER BY NgayNhan DESC
    """)
    van_ban_den_list = cursor.fetchall()

    cursor.execute("""
        SELECT MaVanBanDi, SoKyHieu, TrichYeu
        FROM VanBanDi
        ORDER BY NgayBanHanh DESC
    """)
    van_ban_di_list = cursor.fetchall()

    # Cán bộ được phân công: chỉ Chuyên viên và Văn thư
    cursor.execute("""
        SELECT cb.MaCanBo, cb.HoTen, vt.TenVaiTro
        FROM CanBo cb
        LEFT JOIN TaiKhoan tk ON cb.MaCanBo = tk.MaCanBo
        LEFT JOIN VaiTro vt ON tk.MaVaiTro = vt.MaVaiTro
        WHERE vt.TenVaiTro IN (N'Chuyên viên', N'Văn thư')
        ORDER BY cb.HoTen
    """)
    can_bo_list = cursor.fetchall()

    cursor.close()
    conn.close()

    return {
        "linh_vuc_list": linh_vuc_list,
        "van_ban_den_list": van_ban_den_list,
        "van_ban_di_list": van_ban_di_list,
        "can_bo_list": can_bo_list
    }


@app.route("/phan-cong")
def phan_cong():
    if "username" not in session:
        return redirect(url_for("login"))

    keyword = request.args.get("keyword", "").strip()
    trang_thai = request.args.get("trang_thai", "").strip()
    muc_do = request.args.get("muc_do", "").strip()

    conn = get_connection()
    cursor = conn.cursor()

    base_from = """
        FROM NhiemVu nv
        LEFT JOIN LinhVuc lv ON nv.MaLinhVuc = lv.MaLinhVuc
        LEFT JOIN CanBo cb ON nv.MaNguoiGiao = cb.MaCanBo
        WHERE 1 = 1
    """

    conditions = []
    base_params = []

    if keyword:
        conditions.append("""
            AND (
                nv.MaNhiemVu LIKE ?
                OR nv.TenNhiemVu LIKE ?
                OR nv.NoiDung LIKE ?
                OR lv.TenLinhVuc LIKE ?
                OR cb.HoTen LIKE ?
                OR nv.MucDoUuTien LIKE ?
                OR nv.TrangThai LIKE ?
                OR nv.GhiChu LIKE ?
                OR nv.KetQua LIKE ?
                OR EXISTS (
                    SELECT 1
                    FROM PhanCongNhiemVu pc3
                    JOIN CanBo cb3 ON pc3.MaCanBo = cb3.MaCanBo
                    WHERE pc3.MaNhiemVu = nv.MaNhiemVu
                      AND cb3.HoTen LIKE ?
                )
            )
        """)
        kw = f"%{keyword}%"
        base_params.extend([kw, kw, kw, kw, kw, kw, kw, kw, kw, kw])

    if muc_do:
        conditions.append(" AND LTRIM(RTRIM(nv.MucDoUuTien)) = ?")
        base_params.append(muc_do)

    where_clause = "\n".join(conditions)

    query = """
        SELECT
            nv.MaNhiemVu,
            nv.TenNhiemVu,
            nv.NoiDung,
            lv.TenLinhVuc,
            cb.HoTen AS NguoiGiao,
            nv.NgayGiao,
            nv.ThoiHanHoanThanh,
            nv.MucDoUuTien,
            nv.TrangThai,
            nv.KetQua,
            nv.GhiChu,
            STUFF((
                SELECT ', ' + cb2.HoTen
                FROM PhanCongNhiemVu pc2
                JOIN CanBo cb2 ON pc2.MaCanBo = cb2.MaCanBo
                WHERE pc2.MaNhiemVu = nv.MaNhiemVu
                FOR XML PATH(''), TYPE
            ).value('.', 'NVARCHAR(MAX)'), 1, 2, '') AS NguoiDuocPhanCong
    """
    query += base_from
    query += where_clause

    params = list(base_params)

    if trang_thai:
        query += " AND LTRIM(RTRIM(nv.TrangThai)) = ?"
        params.append(trang_thai)

    query += " ORDER BY nv.NgayGiao DESC, nv.MaNhiemVu DESC"

    cursor.execute(query, *params)
    nhiem_vu_list = cursor.fetchall()

    stats_query = """
        SELECT
            COUNT(*) AS TotalTasks,
            SUM(CASE WHEN LTRIM(RTRIM(ISNULL(nv.TrangThai, N''))) = N'Chưa xử lý' THEN 1 ELSE 0 END) AS TodoTasks,
            SUM(CASE WHEN LTRIM(RTRIM(ISNULL(nv.TrangThai, N''))) = N'Đang xử lý' THEN 1 ELSE 0 END) AS DoingTasks,
            SUM(CASE WHEN LTRIM(RTRIM(ISNULL(nv.TrangThai, N''))) = N'Hoàn thành' THEN 1 ELSE 0 END) AS DoneTasks,
            SUM(CASE WHEN LTRIM(RTRIM(ISNULL(nv.TrangThai, N''))) = N'Quá hạn' THEN 1 ELSE 0 END) AS LateTasks,
            SUM(CASE
                WHEN LTRIM(RTRIM(ISNULL(nv.TrangThai, N''))) NOT IN (N'Chưa xử lý', N'Đang xử lý', N'Hoàn thành', N'Quá hạn')
                THEN 1 ELSE 0
            END) AS OtherTasks
    """
    stats_query += base_from
    stats_query += where_clause

    cursor.execute(stats_query, *base_params)
    stats_row = cursor.fetchone()

    task_stats = {
        "total": int(stats_row[0] or 0) if stats_row else 0,
        "todo": int(stats_row[1] or 0) if stats_row else 0,
        "doing": int(stats_row[2] or 0) if stats_row else 0,
        "done": int(stats_row[3] or 0) if stats_row else 0,
        "late": int(stats_row[4] or 0) if stats_row else 0,
        "other": int(stats_row[5] or 0) if stats_row else 0
    }

    if task_stats["total"] > 0:
        task_completion_percent = round(task_stats["done"] * 100 / task_stats["total"])
    else:
        task_completion_percent = 0

    cursor.close()
    conn.close()

    return render_template(
        "phan_cong.html",
        nhiem_vu_list=nhiem_vu_list,
        task_stats=task_stats,
        task_completion_percent=task_completion_percent,
        keyword=keyword,
        trang_thai=trang_thai,
        muc_do=muc_do,
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/phan-cong/them", methods=["GET", "POST"])
def them_nhiem_vu():
    if "username" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        ten_nhiem_vu = request.form.get("ten_nhiem_vu")
        noi_dung = request.form.get("noi_dung")
        ma_van_ban_den = request.form.get("ma_van_ban_den") or None
        ma_van_ban_di = request.form.get("ma_van_ban_di") or None
        ma_linh_vuc = request.form.get("ma_linh_vuc") or None
        ngay_giao = parse_date_ddmmyyyy(request.form.get("ngay_giao"))
        thoi_han_hoan_thanh = parse_date_ddmmyyyy(request.form.get("thoi_han_hoan_thanh"))
        muc_do_uu_tien = request.form.get("muc_do_uu_tien")
        ds_muc_do_hop_le = ["Bình thường", "Khẩn", "Rất khẩn"]

        if muc_do_uu_tien not in ds_muc_do_hop_le:
            flash("Mức độ ưu tiên không hợp lệ.")
            return redirect(url_for("them_nhiem_vu"))
        trang_thai = request.form.get("trang_thai") or "Chưa xử lý"
        ghi_chu = request.form.get("ghi_chu")
        danh_sach_can_bo = request.form.getlist("ma_can_bo_list")

        conn = None

        try:
            if not ten_nhiem_vu:
                flash("Vui lòng nhập tên nhiệm vụ.")
                return redirect(url_for("them_nhiem_vu"))

            if not ma_linh_vuc:
                flash("Vui lòng chọn lĩnh vực.")
                return redirect(url_for("them_nhiem_vu"))

            if not ngay_giao:
                flash("Vui lòng chọn ngày giao.")
                return redirect(url_for("them_nhiem_vu"))

            if not thoi_han_hoan_thanh:
                flash("Vui lòng chọn thời hạn hoàn thành.")
                return redirect(url_for("them_nhiem_vu"))

            if len(danh_sach_can_bo) == 0:
                flash("Vui lòng chọn ít nhất một cán bộ được phân công.")
                return redirect(url_for("them_nhiem_vu"))

            ma_nguoi_giao = session.get("ma_can_bo")

            if not ma_nguoi_giao:
                flash("Không xác định được người giao nhiệm vụ. Vui lòng đăng nhập lại.")
                return redirect(url_for("login"))

            ma_nhiem_vu = tao_ma_nhiem_vu()

            conn = get_connection()
            cursor = conn.cursor()

            print("===== DEBUG TẠO NHIỆM VỤ =====")
            print("Mã nhiệm vụ:", ma_nhiem_vu)
            print("Tên nhiệm vụ:", ten_nhiem_vu)
            print("Mã lĩnh vực:", ma_linh_vuc)
            print("Mã người giao:", ma_nguoi_giao)
            print("Ngày giao:", ngay_giao)
            print("Thời hạn:", thoi_han_hoan_thanh)
            print("Cán bộ được phân công:", danh_sach_can_bo)
            print("==============================")

            cursor.execute("""
                INSERT INTO NhiemVu
                (
                    MaNhiemVu, TenNhiemVu, NoiDung,
                    MaVanBanDen, MaVanBanDi, MaLinhVuc,
                    MaNguoiGiao, NgayGiao, ThoiHanHoanThanh,
                    MucDoUuTien, TrangThai, KetQua, GhiChu
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
                ma_nhiem_vu, ten_nhiem_vu, noi_dung,
                ma_van_ban_den, ma_van_ban_di, ma_linh_vuc,
                ma_nguoi_giao, ngay_giao, thoi_han_hoan_thanh,
                muc_do_uu_tien, trang_thai, "", ghi_chu
            )

            for ma_can_bo in danh_sach_can_bo:
                cursor.execute("""
                    INSERT INTO PhanCongNhiemVu
                    (
                        MaNhiemVu, MaCanBo, VaiTroXuLy,
                        NgayPhanCong, TrangThai, GhiChu
                    )
                    VALUES (?, ?, ?, GETDATE(), ?, ?)
                """,
                    ma_nhiem_vu,
                    ma_can_bo,
                    "Người thực hiện",
                    "Chưa xử lý",
                    "Được phân công xử lý nhiệm vụ"
                )

            conn.commit()
            cursor.close()
            conn.close()

            flash("Tạo và phân công nhiệm vụ thành công!")
            return redirect(url_for("phan_cong"))

        except Exception as e:
            if conn:
                conn.rollback()

            print("===== LỖI THÊM NHIỆM VỤ =====")
            print(e)
            print("=============================")

            flash(f"Lỗi khi tạo nhiệm vụ: {e}")

    data = lay_du_lieu_form_nhiem_vu()

    return render_template(
        "phan_cong_form.html",
        action="them",
        nhiem_vu=None,
        can_bo_da_chon=[],
        **data,
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/phan-cong/sua/<ma_nhiem_vu>", methods=["GET", "POST"])
def sua_nhiem_vu(ma_nhiem_vu):
    if "username" not in session:
        return redirect(url_for("login"))

    conn = get_connection()
    cursor = conn.cursor()

    if request.method == "POST":
        ten_nhiem_vu = request.form.get("ten_nhiem_vu")
        noi_dung = request.form.get("noi_dung")
        ma_van_ban_den = request.form.get("ma_van_ban_den") or None
        ma_van_ban_di = request.form.get("ma_van_ban_di") or None
        ma_linh_vuc = request.form.get("ma_linh_vuc")
        ngay_giao = parse_date_ddmmyyyy(request.form.get("ngay_giao"))
        thoi_han_hoan_thanh = parse_date_ddmmyyyy(request.form.get("thoi_han_hoan_thanh"))
        muc_do_uu_tien = request.form.get("muc_do_uu_tien")
        ds_muc_do_hop_le = ["Bình thường", "Khẩn", "Rất khẩn"]

        if muc_do_uu_tien not in ds_muc_do_hop_le:
            flash("Mức độ ưu tiên không hợp lệ.")
            return redirect(url_for("sua_nhiem_vu", ma_nhiem_vu=ma_nhiem_vu))
        trang_thai = request.form.get("trang_thai")
        ket_qua = request.form.get("ket_qua")
        ghi_chu = request.form.get("ghi_chu")
        danh_sach_can_bo = request.form.getlist("ma_can_bo_list")

        try:
            cursor.execute("""
                UPDATE NhiemVu
                SET
                    TenNhiemVu = ?,
                    NoiDung = ?,
                    MaVanBanDen = ?,
                    MaVanBanDi = ?,
                    MaLinhVuc = ?,
                    NgayGiao = ?,
                    ThoiHanHoanThanh = ?,
                    MucDoUuTien = ?,
                    TrangThai = ?,
                    KetQua = ?,
                    GhiChu = ?
                WHERE MaNhiemVu = ?
            """,
                ten_nhiem_vu, noi_dung,
                ma_van_ban_den, ma_van_ban_di, ma_linh_vuc,
                ngay_giao, thoi_han_hoan_thanh,
                muc_do_uu_tien, trang_thai, ket_qua, ghi_chu,
                ma_nhiem_vu
            )

            cursor.execute("""
                DELETE FROM PhanCongNhiemVu
                WHERE MaNhiemVu = ?
            """, ma_nhiem_vu)

            for ma_can_bo in danh_sach_can_bo:
                cursor.execute("""
                    INSERT INTO PhanCongNhiemVu
                    (MaNhiemVu, MaCanBo, VaiTroXuLy, NgayPhanCong, TrangThai, GhiChu)
                    VALUES (?, ?, ?, GETDATE(), ?, ?)
                """,
                    ma_nhiem_vu,
                    ma_can_bo,
                    "Người thực hiện",
                    trang_thai,
                    "Cập nhật phân công nhiệm vụ"
                )

            conn.commit()
            cursor.close()
            conn.close()

            flash("Cập nhật nhiệm vụ thành công!")
            return redirect(url_for("phan_cong"))

        except Exception as e:
            conn.rollback()
            print("Lỗi sửa nhiệm vụ:", e)
            flash("Lỗi khi cập nhật nhiệm vụ.")

    cursor.execute("""
        SELECT
            MaNhiemVu, TenNhiemVu, NoiDung,
            MaVanBanDen, MaVanBanDi, MaLinhVuc,
            MaNguoiGiao, NgayGiao, ThoiHanHoanThanh,
            MucDoUuTien, TrangThai, KetQua, GhiChu
        FROM NhiemVu
        WHERE MaNhiemVu = ?
    """, ma_nhiem_vu)

    nhiem_vu = cursor.fetchone()

    cursor.execute("""
        SELECT MaCanBo
        FROM PhanCongNhiemVu
        WHERE MaNhiemVu = ?
    """, ma_nhiem_vu)

    can_bo_da_chon = [str(row.MaCanBo).strip() for row in cursor.fetchall()]

    cursor.close()
    conn.close()

    if not nhiem_vu:
        flash("Không tìm thấy nhiệm vụ cần sửa.")
        return redirect(url_for("phan_cong"))

    data = lay_du_lieu_form_nhiem_vu()

    return render_template(
        "phan_cong_form.html",
        action="sua",
        nhiem_vu=nhiem_vu,
        can_bo_da_chon=can_bo_da_chon,
        **data,
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/phan-cong/xem/<ma_nhiem_vu>")
def xem_nhiem_vu(ma_nhiem_vu):
    if "username" not in session:
        return redirect(url_for("login"))

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT
            nv.MaNhiemVu,
            nv.TenNhiemVu,
            nv.NoiDung,
            nv.MaVanBanDen,
            nv.MaVanBanDi,
            vbd.SoKyHieu AS SoVanBanDen,
            vbd.TrichYeu AS TrichYeuVBDen,
            vbi.SoKyHieu AS SoVanBanDi,
            vbi.TrichYeu AS TrichYeuVBDi,
            lv.TenLinhVuc,
            cb.HoTen AS NguoiGiao,
            nv.NgayGiao,
            nv.ThoiHanHoanThanh,
            nv.MucDoUuTien,
            nv.TrangThai,
            nv.KetQua,
            nv.GhiChu
        FROM NhiemVu nv
        LEFT JOIN VanBanDen vbd ON nv.MaVanBanDen = vbd.MaVanBanDen
        LEFT JOIN VanBanDi vbi ON nv.MaVanBanDi = vbi.MaVanBanDi
        LEFT JOIN LinhVuc lv ON nv.MaLinhVuc = lv.MaLinhVuc
        LEFT JOIN CanBo cb ON nv.MaNguoiGiao = cb.MaCanBo
        WHERE nv.MaNhiemVu = ?
    """, ma_nhiem_vu)

    nhiem_vu = cursor.fetchone()

    if not nhiem_vu:
        cursor.close()
        conn.close()
        flash("Không tìm thấy nhiệm vụ.")
        return redirect(url_for("phan_cong"))

    cursor.execute("""
        SELECT
            pc.MaCanBo,
            cb.HoTen,
            pc.VaiTroXuLy,
            pc.NgayPhanCong,
            pc.TrangThai,
            pc.GhiChu
        FROM PhanCongNhiemVu pc
        LEFT JOIN CanBo cb ON pc.MaCanBo = cb.MaCanBo
        WHERE pc.MaNhiemVu = ?
        ORDER BY cb.HoTen
    """, ma_nhiem_vu)

    phan_cong_list = cursor.fetchall()

    cursor.execute("""
        SELECT
            td.MaTienDo,
            td.MaNhiemVu,
            td.MaCanBo,
            cb.HoTen,
            td.NgayCapNhat,
            td.NoiDungCapNhat,
            td.TiLeHoanThanh,
            td.TrangThai,
            td.GhiChu
        FROM TienDoNhiemVu td
        LEFT JOIN CanBo cb ON td.MaCanBo = cb.MaCanBo
        WHERE td.MaNhiemVu = ?
        ORDER BY td.NgayCapNhat DESC
    """, ma_nhiem_vu)

    tien_do_list = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template(
        "phan_cong_chi_tiet.html",
        nhiem_vu=nhiem_vu,
        phan_cong_list=phan_cong_list,
        tien_do_list=tien_do_list,
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/phan-cong/tien-do/<ma_nhiem_vu>", methods=["POST"])
def them_tien_do_nhiem_vu(ma_nhiem_vu):
    if "username" not in session:
        return redirect(url_for("login"))

    noi_dung_cap_nhat = request.form.get("noi_dung_cap_nhat")
    ti_le_hoan_thanh = request.form.get("ti_le_hoan_thanh")
    trang_thai = request.form.get("trang_thai")
    ghi_chu = request.form.get("ghi_chu")
    ma_can_bo = session.get("ma_can_bo")

    try:
        ma_tien_do = tao_ma_tien_do()

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO TienDoNhiemVu
            (
                MaTienDo, MaNhiemVu, MaCanBo,
                NgayCapNhat, NoiDungCapNhat,
                TiLeHoanThanh, TrangThai, GhiChu
            )
            VALUES (?, ?, ?, GETDATE(), ?, ?, ?, ?)
        """,
            ma_tien_do, ma_nhiem_vu, ma_can_bo,
            noi_dung_cap_nhat, ti_le_hoan_thanh,
            trang_thai, ghi_chu
        )

        cursor.execute("""
            UPDATE NhiemVu
            SET TrangThai = ?
            WHERE MaNhiemVu = ?
        """, trang_thai, ma_nhiem_vu)

        cursor.execute("""
            UPDATE PhanCongNhiemVu
            SET TrangThai = ?
            WHERE MaNhiemVu = ?
              AND MaCanBo = ?
        """, trang_thai, ma_nhiem_vu, ma_can_bo)

        conn.commit()
        cursor.close()
        conn.close()

        flash("Cập nhật tiến độ nhiệm vụ thành công!")

    except Exception as e:
        print("Lỗi cập nhật tiến độ:", e)
        flash("Lỗi khi cập nhật tiến độ nhiệm vụ.")

    return redirect(url_for("xem_nhiem_vu", ma_nhiem_vu=ma_nhiem_vu))


@app.route("/phan-cong/cap-nhat-trang-thai/<ma_nhiem_vu>/<trang_thai>", methods=["POST"])
def cap_nhat_trang_thai_nhiem_vu(ma_nhiem_vu, trang_thai):
    if "username" not in session:
        return redirect(url_for("login"))

    trang_thai_map = {
        "chua-xu-ly": "Chưa xử lý",
        "dang-xu-ly": "Đang xử lý",
        "hoan-thanh": "Hoàn thành",
        "qua-han": "Quá hạn"
    }

    trang_thai_moi = trang_thai_map.get(trang_thai, "Chưa xử lý")

    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE NhiemVu
            SET TrangThai = ?
            WHERE MaNhiemVu = ?
        """, trang_thai_moi, ma_nhiem_vu)

        cursor.execute("""
            UPDATE PhanCongNhiemVu
            SET TrangThai = ?
            WHERE MaNhiemVu = ?
        """, trang_thai_moi, ma_nhiem_vu)

        conn.commit()
        cursor.close()
        conn.close()

        flash("Cập nhật trạng thái nhiệm vụ thành công!")

    except Exception as e:
        print("Lỗi cập nhật trạng thái nhiệm vụ:", e)
        flash("Không thể cập nhật trạng thái nhiệm vụ.")

    return redirect(url_for("phan_cong"))


@app.route("/phan-cong/xoa/<ma_nhiem_vu>", methods=["POST"])
def xoa_nhiem_vu(ma_nhiem_vu):
    if "username" not in session:
        return redirect(url_for("login"))

    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("DELETE FROM TienDoNhiemVu WHERE MaNhiemVu = ?", ma_nhiem_vu)
        cursor.execute("DELETE FROM PhanCongNhiemVu WHERE MaNhiemVu = ?", ma_nhiem_vu)
        cursor.execute("DELETE FROM NhiemVu WHERE MaNhiemVu = ?", ma_nhiem_vu)

        conn.commit()
        cursor.close()
        conn.close()

        flash("Xóa nhiệm vụ thành công!")

    except Exception as e:
        print("Lỗi xóa nhiệm vụ:", e)
        flash("Không thể xóa nhiệm vụ. Có thể dữ liệu đang liên kết với bảng khác.")

    return redirect(url_for("phan_cong"))
# =========================
# BÁO CÁO - THỐNG KÊ
# Đúng theo SQL: BAOCAO, LINHVUC, CANBO
# Có dữ liệu chart không lỗi VS Code
# =========================

def tao_ma_bao_cao():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT MaBaoCao
        FROM BAOCAO
        WHERE MaBaoCao LIKE 'BC%'
    """)

    rows = cursor.fetchall()

    max_num = 0
    for row in rows:
        ma = str(row.MaBaoCao).strip()
        so = ma.replace("BC", "")
        if so.isdigit():
            max_num = max(max_num, int(so))

    cursor.close()
    conn.close()

    return f"BC{max_num + 1:03d}"


def cong_thang_bao_cao(value, months):
    year = value.year + ((value.month - 1 + months) // 12)
    month = ((value.month - 1 + months) % 12) + 1
    return date(year, month, 1)


def parse_ngay_thong_ke(value):
    if not value:
        return None

    value = str(value).strip()
    for fmt in ("%d/%m/%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(value, fmt).date()
        except ValueError:
            pass

    return None


def lay_bo_loc_thoi_gian():
    today = datetime.now().date()
    kieu = request.args.get("kieu_thoi_gian", "").strip()
    ngay_raw = request.args.get("ngay_thong_ke", "").strip()
    ngay_date = parse_ngay_thong_ke(ngay_raw) if ngay_raw else today
    ngay = (ngay_date or today).strftime("%d/%m/%Y")
    thang = request.args.get("thang_thong_ke", "").strip() or today.strftime("%Y-%m")
    quy = request.args.get("quy_thong_ke", "").strip() or str(((today.month - 1) // 3) + 1)
    nam = request.args.get("nam_thong_ke", "").strip() or str(today.year)

    if kieu not in ["ngay", "thang", "quy"]:
        kieu = ""

    start_date = None
    end_date = None
    nhan = "T\u1ea5t c\u1ea3 th\u1eddi gian"

    try:
        if kieu == "ngay":
            if not ngay_date:
                raise ValueError("Ngày không hợp lệ")
            start_date = ngay_date
            end_date = date.fromordinal(start_date.toordinal() + 1)
            nhan = f"Ng\u00e0y {start_date.strftime('%d/%m/%Y')}"
        elif kieu == "thang":
            start_date = datetime.strptime(thang + "-01", "%Y-%m-%d").date()
            end_date = cong_thang_bao_cao(start_date, 1)
            nhan = f"Th\u00e1ng {start_date.month:02d}/{start_date.year}"
        elif kieu == "quy":
            quy_int = int(quy)
            nam_int = int(nam)
            if quy_int < 1 or quy_int > 4:
                raise ValueError("Qu\u00fd kh\u00f4ng h\u1ee3p l\u1ec7")
            start_month = (quy_int - 1) * 3 + 1
            start_date = date(nam_int, start_month, 1)
            end_date = cong_thang_bao_cao(start_date, 3)
            nhan = f"Qu\u00fd {quy_int}/{nam_int}"
    except Exception:
        kieu = ""
        start_date = None
        end_date = None
        nhan = "T\u1ea5t c\u1ea3 th\u1eddi gian"

    return {
        "kieu": kieu,
        "ngay": ngay,
        "thang": thang,
        "quy": quy,
        "nam": nam,
        "start": start_date,
        "end": end_date,
        "nhan": nhan
    }


def tao_query_loc_thoi_gian(bo_loc):
    if not bo_loc.get("kieu"):
        return ""

    params = {"kieu_thoi_gian": bo_loc["kieu"]}

    if bo_loc["kieu"] == "ngay":
        params["ngay_thong_ke"] = bo_loc["ngay"]
    elif bo_loc["kieu"] == "thang":
        params["thang_thong_ke"] = bo_loc["thang"]
    elif bo_loc["kieu"] == "quy":
        params["quy_thong_ke"] = bo_loc["quy"]
        params["nam_thong_ke"] = bo_loc["nam"]

    return "?" + urlencode(params)


def dieu_kien_loc_ngay(alias, column_name, bo_loc, params):
    if not bo_loc.get("start") or not bo_loc.get("end"):
        return ""

    params.extend([bo_loc["start"], bo_loc["end"]])
    prefix = f"{alias}." if alias else ""
    return f" AND {prefix}{column_name} >= ? AND {prefix}{column_name} < ?"


def count_table(table_name, date_column=None, bo_loc=None):
    try:
        conn = get_connection()
        cursor = conn.cursor()

        params = []
        query = f"SELECT COUNT(*) FROM {table_name} WHERE 1 = 1"
        if date_column and bo_loc:
            query += dieu_kien_loc_ngay("", date_column, bo_loc, params)

        cursor.execute(query, *params)
        result = cursor.fetchone()[0]

        cursor.close()
        conn.close()

        return result
    except Exception as e:
        print("Lỗi count_table:", e)
        return 0


def thong_ke_trang_thai(table_name, status_column, date_column=None, bo_loc=None):
    try:
        conn = get_connection()
        cursor = conn.cursor()

        params = []
        query = f"""
            SELECT 
                ISNULL({status_column}, N'Chưa có trạng thái') AS TrangThai,
                COUNT(*) AS SoLuong
            FROM {table_name}
            WHERE 1 = 1
        """

        if date_column and bo_loc:
            query += dieu_kien_loc_ngay("", date_column, bo_loc, params)

        query += f"""
            GROUP BY {status_column}
            ORDER BY SoLuong DESC
        """

        cursor.execute(query, *params)

        rows = cursor.fetchall()

        cursor.close()
        conn.close()

        return rows
    except Exception as e:
        print("Lỗi thống kê trạng thái:", e)
        return []


def thong_ke_theo_linh_vuc(bo_loc=None):
    conn = get_connection()
    cursor = conn.cursor()

    params = []
    loc_van_ban_di = dieu_kien_loc_ngay("vbd", "NgayBanHanh", bo_loc, params) if bo_loc else ""
    loc_van_ban_den = dieu_kien_loc_ngay("vbn", "NgayNhan", bo_loc, params) if bo_loc else ""
    loc_nhiem_vu = dieu_kien_loc_ngay("nv", "NgayGiao", bo_loc, params) if bo_loc else ""
    loc_kien_nghi = dieu_kien_loc_ngay("yk", "NgayTiepNhan", bo_loc, params) if bo_loc else ""

    cursor.execute(f"""
        SELECT
            lv.MaLinhVuc,
            lv.TenLinhVuc,

            (SELECT COUNT(*) 
             FROM VANBANDI vbd 
             WHERE vbd.MaLinhVuc = lv.MaLinhVuc{loc_van_ban_di}) AS SoVanBanDi,

            (SELECT COUNT(*) 
             FROM VANBANDEN vbn 
             WHERE vbn.MaLinhVuc = lv.MaLinhVuc{loc_van_ban_den}) AS SoVanBanDen,

            (SELECT COUNT(*) 
             FROM NHIEMVU nv 
             WHERE nv.MaLinhVuc = lv.MaLinhVuc{loc_nhiem_vu}) AS SoNhiemVu,

            (SELECT COUNT(*) 
             FROM YKIENKIENNGHI yk 
             WHERE yk.MaLinhVuc = lv.MaLinhVuc{loc_kien_nghi}) AS SoKienNghi

        FROM LINHVUC lv
        ORDER BY lv.TenLinhVuc
    """, *params)

    rows = cursor.fetchall()

    cursor.close()
    conn.close()

    return rows


def chuyen_trang_thai_sang_chart(rows):
    data = []

    for row in rows:
        data.append({
            "label": str(row.TrangThai).strip() if row.TrangThai else "Chưa có trạng thái",
            "value": int(row.SoLuong or 0)
        })

    return data


def chuyen_linh_vuc_sang_chart(rows):
    data = []

    for row in rows:
        tong = int(row.SoVanBanDi or 0) + int(row.SoVanBanDen or 0) + int(row.SoNhiemVu or 0) + int(row.SoKienNghi or 0)

        data.append({
            "label": str(row.TenLinhVuc).strip(),
            "value": tong
        })

    return data


def lay_danh_sach_cong_van_bao_cao(loai_cong_van, bo_loc=None):
    conn = get_connection()
    cursor = conn.cursor()
    params = []

    if loai_cong_van == "cong_van_di":
        query = """
            SELECT
                vb.MaVanBanDi AS MaVanBan,
                vb.SoKyHieu,
                vb.TrichYeu,
                vb.NgayBanHanh AS NgayKy,
                cb.HoTen AS NguoiKyBanHanh
            FROM VanBanDi vb
            LEFT JOIN CanBo cb ON vb.MaNguoiKy = cb.MaCanBo
            WHERE 1 = 1
        """
        query += dieu_kien_loc_ngay("vb", "NgayBanHanh", bo_loc, params) if bo_loc else ""
        query += """
            ORDER BY vb.NgayBanHanh DESC, vb.MaVanBanDi DESC
        """
        cursor.execute(query, *params)
    elif loai_cong_van == "cong_van_den":
        query = """
            SELECT
                vb.MaVanBanDen AS MaVanBan,
                vb.SoKyHieu,
                vb.TrichYeu,
                vb.NgayBanHanh AS NgayKy,
                vb.CoQuanGui AS NguoiKyBanHanh
            FROM VanBanDen vb
            WHERE 1 = 1
        """
        query += dieu_kien_loc_ngay("vb", "NgayNhan", bo_loc, params) if bo_loc else ""
        query += """
            ORDER BY vb.NgayBanHanh DESC, vb.MaVanBanDen DESC
        """
        cursor.execute(query, *params)
    else:
        cursor.close()
        conn.close()
        return []

    rows = cursor.fetchall()

    cursor.close()
    conn.close()

    return rows


def dinh_dang_ngay_bao_cao(value, include_time=False):
    if not value:
        return ""

    try:
        return value.strftime("%d/%m/%Y %H:%M" if include_time else "%d/%m/%Y")
    except Exception:
        return str(value)


def lay_danh_sach_nhiem_vu_bao_cao(bo_loc=None):
    conn = get_connection()
    cursor = conn.cursor()
    params = []

    query = """
        SELECT
            nv.MaNhiemVu,
            nv.TenNhiemVu,
            nv.NoiDung,
            nv.NgayGiao,
            cb.HoTen AS NguoiGiao,
            nv.TrangThai
        FROM NhiemVu nv
        LEFT JOIN CanBo cb ON nv.MaNguoiGiao = cb.MaCanBo
        WHERE 1 = 1
    """
    query += dieu_kien_loc_ngay("nv", "NgayGiao", bo_loc, params) if bo_loc else ""
    query += """
        ORDER BY nv.NgayGiao DESC, nv.MaNhiemVu DESC
    """

    cursor.execute(query, *params)

    rows = []
    for row in cursor.fetchall():
        rows.append({
            "link": f"/phan-cong/xem/{row.MaNhiemVu}",
            "cells": [
                row.MaNhiemVu,
                row.TenNhiemVu or "",
                row.NoiDung or "",
                dinh_dang_ngay_bao_cao(row.NgayGiao),
                row.NguoiGiao or "",
                row.TrangThai or ""
            ]
        })

    cursor.close()
    conn.close()

    return rows


def lay_danh_sach_kien_nghi_bao_cao(bo_loc=None):
    conn = get_connection()
    cursor = conn.cursor()
    params = []

    query = """
        SELECT
            MaKienNghi,
            NoiDungKienNghi,
            NguoiKienNghi,
            NgayTiepNhan,
            TrangThai
        FROM YKienKienNghi
        WHERE 1 = 1
    """
    query += dieu_kien_loc_ngay("", "NgayTiepNhan", bo_loc, params) if bo_loc else ""
    query += """
        ORDER BY NgayTiepNhan DESC, MaKienNghi DESC
    """

    cursor.execute(query, *params)

    rows = []
    for row in cursor.fetchall():
        rows.append({
            "link": f"/kien-nghi/xem/{row.MaKienNghi}",
            "cells": [
                row.MaKienNghi,
                row.NoiDungKienNghi or "",
                row.NguoiKienNghi or "",
                dinh_dang_ngay_bao_cao(row.NgayTiepNhan),
                row.TrangThai or ""
            ]
        })

    cursor.close()
    conn.close()

    return rows


def lay_danh_sach_cuoc_hop_bao_cao(bo_loc=None):
    conn = get_connection()
    cursor = conn.cursor()
    params = []

    query = """
        SELECT
            ch.MaCuocHop,
            ch.TenCuocHop,
            ch.NoiDung,
            ch.ThoiGianBatDau,
            ch.DiaDiem,
            cb.HoTen AS NguoiChuTri
        FROM HOINGHICUOCHOP ch
        LEFT JOIN CanBo cb ON ch.MaNguoiChuTri = cb.MaCanBo
        WHERE 1 = 1
    """
    query += dieu_kien_loc_ngay("ch", "ThoiGianBatDau", bo_loc, params) if bo_loc else ""
    query += """
        ORDER BY ch.ThoiGianBatDau DESC, ch.MaCuocHop DESC
    """

    cursor.execute(query, *params)

    rows = []
    for row in cursor.fetchall():
        rows.append({
            "link": f"/cuoc-hop/xem/{row.MaCuocHop}",
            "cells": [
                row.MaCuocHop,
                row.TenCuocHop or "",
                row.NoiDung or "",
                dinh_dang_ngay_bao_cao(row.ThoiGianBatDau, include_time=True),
                row.NguoiChuTri or "",
                row.DiaDiem or ""
            ]
        })

    cursor.close()
    conn.close()

    return rows


def lay_du_lieu_form_bao_cao():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT MaLinhVuc, TenLinhVuc
        FROM LINHVUC
        ORDER BY TenLinhVuc
    """)
    linh_vuc_list = cursor.fetchall()

    cursor.close()
    conn.close()

    return {
        "linh_vuc_list": linh_vuc_list
    }


def luu_file_bao_cao(file):
    if not file or not file.filename:
        return None

    if not allowed_file(file.filename):
        return None

    folder = "static/uploads/bao_cao"
    os.makedirs(folder, exist_ok=True)

    ten_goc = secure_filename(file.filename)
    ten_luu = f"{uuid.uuid4().hex}_{ten_goc}"

    duong_dan_luu = os.path.join(folder, ten_luu)
    file.save(duong_dan_luu)

    return f"uploads/bao_cao/{ten_luu}"


@app.route("/bao-cao")
def bao_cao():
    if "username" not in session:
        return redirect(url_for("login"))

    keyword = request.args.get("keyword", "").strip()
    loai_bao_cao = request.args.get("loai_bao_cao", "").strip()
    bo_loc = lay_bo_loc_thoi_gian()
    filter_query = tao_query_loc_thoi_gian(bo_loc)

    conn = get_connection()
    cursor = conn.cursor()

    query = """
        SELECT
            bc.MaBaoCao,
            bc.TenBaoCao,
            bc.LoaiBaoCao,
            lv.TenLinhVuc,
            cb.HoTen AS NguoiLap,
            bc.NgayLap,
            bc.NoiDungBaoCao,
            bc.TepBaoCao,
            bc.GhiChu
        FROM BAOCAO bc
        LEFT JOIN LINHVUC lv ON bc.MaLinhVuc = lv.MaLinhVuc
        LEFT JOIN CANBO cb ON bc.MaNguoiLap = cb.MaCanBo
        WHERE 1 = 1
    """

    params = []

    if keyword:
        query += """
            AND (
                bc.MaBaoCao LIKE ?
                OR bc.TenBaoCao LIKE ?
                OR bc.LoaiBaoCao LIKE ?
                OR bc.NoiDungBaoCao LIKE ?
                OR cb.HoTen LIKE ?
                OR lv.TenLinhVuc LIKE ?
                OR bc.GhiChu LIKE ?
                OR bc.TepBaoCao LIKE ?
            )
        """
        kw = f"%{keyword}%"
        params.extend([kw, kw, kw, kw, kw, kw, kw, kw])

    if loai_bao_cao:
        query += " AND LTRIM(RTRIM(bc.LoaiBaoCao)) = ?"
        params.append(loai_bao_cao)

    query += " ORDER BY bc.NgayLap DESC, bc.MaBaoCao DESC"

    cursor.execute(query, *params)
    bao_cao_list = cursor.fetchall()

    cursor.close()
    conn.close()

    tk_van_ban_di = thong_ke_trang_thai("VANBANDI", "TrangThai", "NgayBanHanh", bo_loc)
    tk_van_ban_den = thong_ke_trang_thai("VANBANDEN", "TrangThaiXuLy", "NgayNhan", bo_loc)
    tk_nhiem_vu = thong_ke_trang_thai("NHIEMVU", "TrangThai", "NgayGiao", bo_loc)
    tk_kien_nghi = thong_ke_trang_thai("YKIENKIENNGHI", "TrangThai", "NgayTiepNhan", bo_loc)
    tk_linh_vuc = thong_ke_theo_linh_vuc(bo_loc)

    return render_template(
        "bao_cao.html",
        bao_cao_list=bao_cao_list,
        keyword=keyword,
        loai_bao_cao=loai_bao_cao,

        tong_van_ban_di=count_table("VANBANDI", "NgayBanHanh", bo_loc),
        tong_van_ban_den=count_table("VANBANDEN", "NgayNhan", bo_loc),
        tong_nhiem_vu=count_table("NHIEMVU", "NgayGiao", bo_loc),
        tong_kien_nghi=count_table("YKIENKIENNGHI", "NgayTiepNhan", bo_loc),
        tong_cuoc_hop=count_table("HOINGHICUOCHOP", "ThoiGianBatDau", bo_loc),
        tong_bao_cao=count_table("BAOCAO", "NgayLap", bo_loc),
        bo_loc_thoi_gian=bo_loc,
        filter_query=filter_query,

        thong_ke_van_ban_di=tk_van_ban_di,
        thong_ke_van_ban_den=tk_van_ban_den,
        thong_ke_nhiem_vu=tk_nhiem_vu,
        thong_ke_kien_nghi=tk_kien_nghi,
        thong_ke_linh_vuc=tk_linh_vuc,

        chart_van_ban_di=chuyen_trang_thai_sang_chart(tk_van_ban_di),
        chart_van_ban_den=chuyen_trang_thai_sang_chart(tk_van_ban_den),
        chart_nhiem_vu=chuyen_trang_thai_sang_chart(tk_nhiem_vu),
        chart_kien_nghi=chuyen_trang_thai_sang_chart(tk_kien_nghi),
        chart_linh_vuc=chuyen_linh_vuc_sang_chart(tk_linh_vuc),

        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/bao-cao/cong-van-di")
def bao_cao_cong_van_di():
    if "username" not in session:
        return redirect(url_for("login"))

    bo_loc = lay_bo_loc_thoi_gian()
    filter_query = tao_query_loc_thoi_gian(bo_loc)

    return render_template(
        "bao_cao_cong_van.html",
        tieu_de="Danh sách công văn đi",
        mo_ta="Tổng hợp số công văn đi, trích yếu, ngày ký và người ký ban hành.",
        loai_cong_van="cong_van_di",
        cong_van_list=lay_danh_sach_cong_van_bao_cao("cong_van_di", bo_loc),
        filter_query=filter_query,
        nhan_thoi_gian=bo_loc["nhan"],
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/bao-cao/cong-van-den")
def bao_cao_cong_van_den():
    if "username" not in session:
        return redirect(url_for("login"))

    bo_loc = lay_bo_loc_thoi_gian()
    filter_query = tao_query_loc_thoi_gian(bo_loc)

    return render_template(
        "bao_cao_cong_van.html",
        tieu_de="Danh sách công văn đến",
        mo_ta="Tổng hợp số công văn đến, trích yếu, ngày ký và cơ quan ban hành/gửi.",
        loai_cong_van="cong_van_den",
        cong_van_list=lay_danh_sach_cong_van_bao_cao("cong_van_den", bo_loc),
        filter_query=filter_query,
        nhan_thoi_gian=bo_loc["nhan"],
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/bao-cao/nhiem-vu")
def bao_cao_nhiem_vu():
    if "username" not in session:
        return redirect(url_for("login"))

    bo_loc = lay_bo_loc_thoi_gian()
    filter_query = tao_query_loc_thoi_gian(bo_loc)

    return render_template(
        "bao_cao_danh_sach.html",
        tieu_de="Danh sách nhiệm vụ",
        mo_ta="Tổng hợp nhiệm vụ, nội dung, ngày giao, người giao và trạng thái xử lý.",
        nhan_danh_sach="nhiệm vụ",
        cot_list=["Mã nhiệm vụ", "Tên nhiệm vụ", "Nội dung", "Ngày giao", "Người giao", "Trạng thái"],
        item_list=lay_danh_sach_nhiem_vu_bao_cao(bo_loc),
        filter_query=filter_query,
        nhan_thoi_gian=bo_loc["nhan"],
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/bao-cao/kien-nghi")
def bao_cao_kien_nghi():
    if "username" not in session:
        return redirect(url_for("login"))

    bo_loc = lay_bo_loc_thoi_gian()
    filter_query = tao_query_loc_thoi_gian(bo_loc)

    return render_template(
        "bao_cao_danh_sach.html",
        tieu_de="Danh sách kiến nghị",
        mo_ta="Tổng hợp nội dung kiến nghị, người kiến nghị, ngày tiếp nhận và trạng thái xử lý.",
        nhan_danh_sach="kiến nghị",
        cot_list=["Mã kiến nghị", "Nội dung kiến nghị", "Người kiến nghị", "Ngày tiếp nhận", "Trạng thái"],
        item_list=lay_danh_sach_kien_nghi_bao_cao(bo_loc),
        filter_query=filter_query,
        nhan_thoi_gian=bo_loc["nhan"],
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/bao-cao/cuoc-hop")
def bao_cao_cuoc_hop():
    if "username" not in session:
        return redirect(url_for("login"))

    bo_loc = lay_bo_loc_thoi_gian()
    filter_query = tao_query_loc_thoi_gian(bo_loc)

    return render_template(
        "bao_cao_danh_sach.html",
        tieu_de="Danh sách cuộc họp",
        mo_ta="Tổng hợp cuộc họp, nội dung, thời gian, người chủ trì và địa điểm.",
        nhan_danh_sach="cuộc họp",
        cot_list=["Mã cuộc họp", "Tên cuộc họp", "Nội dung", "Thời gian", "Người chủ trì", "Địa điểm"],
        item_list=lay_danh_sach_cuoc_hop_bao_cao(bo_loc),
        filter_query=filter_query,
        nhan_thoi_gian=bo_loc["nhan"],
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/bao-cao/them", methods=["GET", "POST"])
def them_bao_cao():
    if "username" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        ten_bao_cao = request.form.get("ten_bao_cao")
        loai_bao_cao = request.form.get("loai_bao_cao")
        ma_linh_vuc = request.form.get("ma_linh_vuc") or None
        ngay_lap = parse_date_ddmmyyyy(request.form.get("ngay_lap"))
        noi_dung_bao_cao = request.form.get("noi_dung_bao_cao")
        ghi_chu = request.form.get("ghi_chu")
        ma_nguoi_lap = session.get("ma_can_bo")

        file = request.files.get("tep_bao_cao")
        tep_bao_cao = luu_file_bao_cao(file)

        try:
            ma_bao_cao = tao_ma_bao_cao()

            conn = get_connection()
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO BAOCAO
                (
                    MaBaoCao, TenBaoCao, LoaiBaoCao,
                    MaLinhVuc, MaNguoiLap, NgayLap,
                    NoiDungBaoCao, TepBaoCao, GhiChu
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
                ma_bao_cao, ten_bao_cao, loai_bao_cao,
                ma_linh_vuc, ma_nguoi_lap, ngay_lap,
                noi_dung_bao_cao, tep_bao_cao, ghi_chu
            )

            conn.commit()
            cursor.close()
            conn.close()

            flash("Thêm báo cáo thành công!")
            return redirect(url_for("bao_cao"))

        except Exception as e:
            print("Lỗi thêm báo cáo:", e)
            flash("Lỗi khi thêm báo cáo. Kiểm tra dữ liệu nhập.")

    data = lay_du_lieu_form_bao_cao()

    return render_template(
        "bao_cao_form.html",
        action="them",
        bao_cao_item=None,
        ngay_hom_nay=datetime.now().strftime("%d/%m/%Y"),
        **data,
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/bao-cao/sua/<ma_bao_cao>", methods=["GET", "POST"])
def sua_bao_cao(ma_bao_cao):
    if "username" not in session:
        return redirect(url_for("login"))

    conn = get_connection()
    cursor = conn.cursor()

    if request.method == "POST":
        ten_bao_cao = request.form.get("ten_bao_cao")
        loai_bao_cao = request.form.get("loai_bao_cao")
        ma_linh_vuc = request.form.get("ma_linh_vuc") or None
        ngay_lap = parse_date_ddmmyyyy(request.form.get("ngay_lap"))
        noi_dung_bao_cao = request.form.get("noi_dung_bao_cao")
        ghi_chu = request.form.get("ghi_chu")

        try:
            cursor.execute("""
                SELECT TepBaoCao
                FROM BAOCAO
                WHERE MaBaoCao = ?
            """, ma_bao_cao)

            old_file = cursor.fetchone()
            tep_cu = old_file.TepBaoCao if old_file else None

            file = request.files.get("tep_bao_cao")
            tep_moi = luu_file_bao_cao(file)

            if tep_moi:
                tep_bao_cao = tep_moi
            else:
                tep_bao_cao = tep_cu

            cursor.execute("""
                UPDATE BAOCAO
                SET
                    TenBaoCao = ?,
                    LoaiBaoCao = ?,
                    MaLinhVuc = ?,
                    NgayLap = ?,
                    NoiDungBaoCao = ?,
                    TepBaoCao = ?,
                    GhiChu = ?
                WHERE MaBaoCao = ?
            """,
                ten_bao_cao, loai_bao_cao, ma_linh_vuc,
                ngay_lap, noi_dung_bao_cao, tep_bao_cao,
                ghi_chu, ma_bao_cao
            )

            conn.commit()
            cursor.close()
            conn.close()

            flash("Cập nhật báo cáo thành công!")
            return redirect(url_for("bao_cao"))

        except Exception as e:
            conn.rollback()
            print("Lỗi sửa báo cáo:", e)
            flash("Lỗi khi cập nhật báo cáo.")

    cursor.execute("""
        SELECT
            MaBaoCao, TenBaoCao, LoaiBaoCao,
            MaLinhVuc, MaNguoiLap, NgayLap,
            NoiDungBaoCao, TepBaoCao, GhiChu
        FROM BAOCAO
        WHERE MaBaoCao = ?
    """, ma_bao_cao)

    bao_cao_item = cursor.fetchone()

    cursor.close()
    conn.close()

    if not bao_cao_item:
        flash("Không tìm thấy báo cáo cần sửa.")
        return redirect(url_for("bao_cao"))

    data = lay_du_lieu_form_bao_cao()

    return render_template(
        "bao_cao_form.html",
        action="sua",
        bao_cao_item=bao_cao_item,
        ngay_hom_nay=datetime.now().strftime("%d/%m/%Y"),
        **data,
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/bao-cao/xem/<ma_bao_cao>")
def xem_bao_cao(ma_bao_cao):
    if "username" not in session:
        return redirect(url_for("login"))

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT
            bc.MaBaoCao,
            bc.TenBaoCao,
            bc.LoaiBaoCao,
            lv.TenLinhVuc,
            cb.HoTen AS NguoiLap,
            bc.NgayLap,
            bc.NoiDungBaoCao,
            bc.TepBaoCao,
            bc.GhiChu
        FROM BAOCAO bc
        LEFT JOIN LINHVUC lv ON bc.MaLinhVuc = lv.MaLinhVuc
        LEFT JOIN CANBO cb ON bc.MaNguoiLap = cb.MaCanBo
        WHERE bc.MaBaoCao = ?
    """, ma_bao_cao)

    bao_cao_item = cursor.fetchone()

    cursor.close()
    conn.close()

    if not bao_cao_item:
        flash("Không tìm thấy báo cáo.")
        return redirect(url_for("bao_cao"))

    return render_template(
        "bao_cao_chi_tiet.html",
        bao_cao_item=bao_cao_item,
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/bao-cao/xoa/<ma_bao_cao>", methods=["POST"])
def xoa_bao_cao(ma_bao_cao):
    if "username" not in session:
        return redirect(url_for("login"))

    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT TepBaoCao
            FROM BAOCAO
            WHERE MaBaoCao = ?
        """, ma_bao_cao)

        row = cursor.fetchone()

        if row and row.TepBaoCao:
            duong_dan_file = os.path.join("static", str(row.TepBaoCao).replace("/", os.sep))
            if os.path.exists(duong_dan_file):
                os.remove(duong_dan_file)

        cursor.execute("""
            DELETE FROM BAOCAO
            WHERE MaBaoCao = ?
        """, ma_bao_cao)

        conn.commit()
        cursor.close()
        conn.close()

        flash("Xóa báo cáo thành công!")

    except Exception as e:
        print("Lỗi xóa báo cáo:", e)
        flash("Không thể xóa báo cáo.")

    return redirect(url_for("bao_cao"))

# =========================
# TỰ SINH MÃ VĂN BẢN ĐI
# =========================
def tao_so_ky_hieu_cong_van_di():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT SoKyHieu
        FROM VanBanDi
        WHERE SoKyHieu LIKE '%/CV-MTTQ'
    """)

    rows = cursor.fetchall()

    max_num = 0

    for row in rows:
        so_ky_hieu = str(row.SoKyHieu).strip()

        try:
            # Lấy phần số trước dấu /
            phan_so = so_ky_hieu.split("/")[0]

            if phan_so.isdigit():
                max_num = max(max_num, int(phan_so))
        except:
            pass

    cursor.close()
    conn.close()

    so_moi = max_num + 1

    return f"{so_moi}/CV-MTTQ"


# =========================
# QUẢN LÝ CÔNG VĂN ĐI
# =========================
@app.route("/cong-van-di")
def cong_van_di():
    if "username" not in session:
        return redirect(url_for("login"))

    keyword = request.args.get("keyword", "").strip()
    trang_thai = request.args.get("trang_thai", "").strip()

    conn = get_connection()
    cursor = conn.cursor()

    query = """
        SELECT 
            vb.MaVanBanDi,
            vb.SoKyHieu,
            vb.NgayBanHanh,
            lvb.TenLoaiVanBan,
            lv.TenLinhVuc,
            vb.TrichYeu,
            vb.NoiNhan,
            cb1.HoTen AS NguoiSoan,
            cb2.HoTen AS NguoiKy,
            vb.TrangThai,
            vb.GhiChu
        FROM VanBanDi vb
        LEFT JOIN LoaiVanBan lvb ON vb.MaLoaiVanBan = lvb.MaLoaiVanBan
        LEFT JOIN LinhVuc lv ON vb.MaLinhVuc = lv.MaLinhVuc
        LEFT JOIN CanBo cb1 ON vb.MaNguoiSoan = cb1.MaCanBo
        LEFT JOIN CanBo cb2 ON vb.MaNguoiKy = cb2.MaCanBo
        WHERE 1 = 1
    """

    params = []

    if keyword:
        query += """
            AND (
                vb.MaVanBanDi LIKE ?
                OR CAST(vb.NgayBanHanh AS NVARCHAR(30)) LIKE ?
                OR vb.SoKyHieu LIKE ?
                OR vb.TrichYeu LIKE ?
                OR vb.NoiNhan LIKE ?
                OR lvb.TenLoaiVanBan LIKE ?
                OR lv.TenLinhVuc LIKE ?
                OR cb1.HoTen LIKE ?
                OR cb2.HoTen LIKE ?
                OR vb.TrangThai LIKE ?
                OR vb.GhiChu LIKE ?
            )
        """
        kw = f"%{keyword}%"
        params.extend([kw, kw, kw, kw, kw, kw, kw, kw, kw, kw, kw])

    if trang_thai:
        query += " AND LTRIM(RTRIM(vb.TrangThai)) = ?"
        params.append(trang_thai)

    query += " ORDER BY vb.NgayBanHanh DESC, vb.MaVanBanDi DESC"

    cursor.execute(query, *params)
    van_ban_di_list = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template(
        "cong_van_di.html",
        van_ban_di_list=van_ban_di_list,
        keyword=keyword,
        trang_thai=trang_thai,
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )

def tao_ma_van_ban_di():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT MaVanBanDi
        FROM VANBANDI
        WHERE MaVanBanDi IS NOT NULL
    """)

    rows = cursor.fetchall()

    max_so = 0

    for row in rows:
        ma = str(row.MaVanBanDi).strip().upper()

        # Chỉ lấy các mã dạng VBDI001, VBDI002,...
        if ma.startswith("VBDI"):
            phan_so = ma.replace("VBDI", "").strip()

            if phan_so.isdigit():
                so = int(phan_so)

                if so > max_so:
                    max_so = so

    cursor.close()
    conn.close()

    return f"VBDI{max_so + 1:03d}"


def luu_file_cong_van_di(files, ma_van_ban_di):
    luu_file_dinh_kem(
        files,
        ma_van_ban_di,
        "static/uploads/cong_van_di",
        "uploads/cong_van_di",
        "VanBanDi",
        "Tệp đính kèm công văn đi"
    )


def lay_file_cong_van_di(ma_van_ban_di):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT MaTep, TenTep, DuongDanTep, LoaiTep, NgayTaiLen
        FROM TepDinhKem
        WHERE DoiTuongLienKet = 'VanBanDi'
          AND MaDoiTuong = ?
        ORDER BY NgayTaiLen DESC
    """, ma_van_ban_di)

    tep_list = cursor.fetchall()

    cursor.close()
    conn.close()

    return tep_list


@app.route("/cong-van-di/them", methods=["GET", "POST"])
def them_cong_van_di():
    if "username" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        so_ky_hieu = request.form.get("so_ky_hieu")
        ngay_ban_hanh = parse_date_ddmmyyyy(request.form.get("ngay_ban_hanh"))
        ma_loai_van_ban = request.form.get("ma_loai_van_ban")
        ma_linh_vuc = request.form.get("ma_linh_vuc")
        trich_yeu = request.form.get("trich_yeu")
        noi_nhan = request.form.get("noi_nhan")
        ma_nguoi_soan = request.form.get("ma_nguoi_soan")
        ma_nguoi_ky = request.form.get("ma_nguoi_ky")
        trang_thai = request.form.get("trang_thai")
        ghi_chu = request.form.get("ghi_chu")

        try:
            ma_van_ban_di = tao_ma_van_ban_di()

            conn = get_connection()
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO VanBanDi
                (
                    MaVanBanDi, SoKyHieu, NgayBanHanh, MaLoaiVanBan, MaLinhVuc,
                    TrichYeu, NoiNhan, MaNguoiSoan, MaNguoiKy, TrangThai, GhiChu
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
                ma_van_ban_di, so_ky_hieu, ngay_ban_hanh, ma_loai_van_ban, ma_linh_vuc,
                trich_yeu, noi_nhan, ma_nguoi_soan, ma_nguoi_ky, trang_thai, ghi_chu
            )

            conn.commit()

            files = request.files.getlist("tep_dinh_kem")
            luu_file_cong_van_di(files, ma_van_ban_di)

            cursor.close()
            conn.close()

            flash("Thêm công văn đi thành công!")
            return redirect(url_for("cong_van_di"))

        except Exception as e:
            print("Lỗi thêm công văn đi:", e)
            flash("Lỗi khi thêm công văn đi. Kiểm tra số ký hiệu hoặc dữ liệu nhập.")

    data = lay_du_lieu_form_cong_van_di()
    so_ky_hieu_tu_dong = tao_so_ky_hieu_cong_van_di()

    return render_template(
    "cong_van_di_form.html",
    action="them",
    van_ban=None,
    tep_list=[],
    so_ky_hieu_tu_dong=tao_so_ky_hieu_cong_van_di(),
    ngay_hom_nay=datetime.now().strftime("%d/%m/%Y"),
    **data,
    ho_ten=session.get("ho_ten", "Người dùng"),
    vai_tro=session.get("vai_tro", "Người dùng")
    )

    


@app.route("/cong-van-di/sua/<ma_van_ban_di>", methods=["GET", "POST"])
def sua_cong_van_di(ma_van_ban_di):
    if "username" not in session:
        return redirect(url_for("login"))

    conn = get_connection()
    cursor = conn.cursor()

    if request.method == "POST":
        so_ky_hieu = request.form.get("so_ky_hieu")
        ngay_ban_hanh = parse_date_ddmmyyyy(request.form.get("ngay_ban_hanh"))
        ma_loai_van_ban = request.form.get("ma_loai_van_ban")
        ma_linh_vuc = request.form.get("ma_linh_vuc")
        trich_yeu = request.form.get("trich_yeu")
        noi_nhan = request.form.get("noi_nhan")
        ma_nguoi_soan = request.form.get("ma_nguoi_soan")
        ma_nguoi_ky = request.form.get("ma_nguoi_ky")
        trang_thai = request.form.get("trang_thai")
        ghi_chu = request.form.get("ghi_chu")

        try:
            cursor.execute("""
                UPDATE VanBanDi
                SET 
                    SoKyHieu = ?,
                    NgayBanHanh = ?,
                    MaLoaiVanBan = ?,
                    MaLinhVuc = ?,
                    TrichYeu = ?,
                    NoiNhan = ?,
                    MaNguoiSoan = ?,
                    MaNguoiKy = ?,
                    TrangThai = ?,
                    GhiChu = ?
                WHERE MaVanBanDi = ?
            """,
                so_ky_hieu, ngay_ban_hanh, ma_loai_van_ban, ma_linh_vuc,
                trich_yeu, noi_nhan, ma_nguoi_soan, ma_nguoi_ky,
                trang_thai, ghi_chu, ma_van_ban_di
            )

            conn.commit()

            files = request.files.getlist("tep_dinh_kem")
            luu_file_cong_van_di(files, ma_van_ban_di)

            cursor.close()
            conn.close()

            flash("Cập nhật công văn đi thành công!")
            return redirect(url_for("cong_van_di"))

        except Exception as e:
            conn.rollback()
            print("Lỗi sửa công văn đi:", e)
            flash("Lỗi khi cập nhật công văn đi.")

    cursor.execute("""
        SELECT 
            MaVanBanDi, SoKyHieu, NgayBanHanh, MaLoaiVanBan, MaLinhVuc,
            TrichYeu, NoiNhan, MaNguoiSoan, MaNguoiKy, TrangThai, GhiChu
        FROM VanBanDi
        WHERE MaVanBanDi = ?
    """, ma_van_ban_di)

    van_ban = cursor.fetchone()

    cursor.close()
    conn.close()

    if not van_ban:
        flash("Không tìm thấy công văn đi cần sửa.")
        return redirect(url_for("cong_van_di"))

    data = lay_du_lieu_form_cong_van_di()
    tep_list = lay_file_cong_van_di(ma_van_ban_di)

    return render_template(
        "cong_van_di_form.html",
        action="sua",
        van_ban=van_ban,
        tep_list=tep_list,
        **data,
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/cong-van-di/xem/<ma_van_ban_di>")
def xem_cong_van_di(ma_van_ban_di):
    if "username" not in session:
        return redirect(url_for("login"))

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT 
            vb.MaVanBanDi,
            vb.SoKyHieu,
            vb.NgayBanHanh,
            lvb.TenLoaiVanBan,
            lv.TenLinhVuc,
            vb.TrichYeu,
            vb.NoiNhan,
            cb1.HoTen AS NguoiSoan,
            cb2.HoTen AS NguoiKy,
            vb.TrangThai,
            vb.GhiChu
        FROM VanBanDi vb
        LEFT JOIN LoaiVanBan lvb ON vb.MaLoaiVanBan = lvb.MaLoaiVanBan
        LEFT JOIN LinhVuc lv ON vb.MaLinhVuc = lv.MaLinhVuc
        LEFT JOIN CanBo cb1 ON vb.MaNguoiSoan = cb1.MaCanBo
        LEFT JOIN CanBo cb2 ON vb.MaNguoiKy = cb2.MaCanBo
        WHERE vb.MaVanBanDi = ?
    """, ma_van_ban_di)

    van_ban = cursor.fetchone()

    cursor.close()
    conn.close()

    if not van_ban:
        flash("Không tìm thấy công văn đi.")
        return redirect(url_for("cong_van_di"))

    tep_list = lay_file_cong_van_di(ma_van_ban_di)

    return render_template(
        "cong_van_di_chi_tiet.html",
        van_ban=van_ban,
        tep_list=tep_list,
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/cong-van-di/duyet/<ma_van_ban_di>", methods=["POST"])
def duyet_cong_van_di(ma_van_ban_di):
    return cap_nhat_trang_thai_cong_van_di(ma_van_ban_di, "Đã duyệt", "Duyệt công văn thành công!")


@app.route("/cong-van-di/phat-hanh/<ma_van_ban_di>", methods=["POST"])
def phat_hanh_cong_van_di(ma_van_ban_di):
    return cap_nhat_trang_thai_cong_van_di(ma_van_ban_di, "Đã phát hành", "Phát hành công văn thành công!")


@app.route("/cong-van-di/yeu-cau-sua/<ma_van_ban_di>", methods=["POST"])
def yeu_cau_sua_cong_van_di(ma_van_ban_di):
    return cap_nhat_trang_thai_cong_van_di(ma_van_ban_di, "Yêu cầu chỉnh sửa", "Đã chuyển trạng thái yêu cầu chỉnh sửa!")


@app.route("/cong-van-di/xoa-tep/<ma_tep>/<ma_van_ban_di>", methods=["POST"])
def xoa_tep_cong_van_di(ma_tep, ma_van_ban_di):
    if "username" not in session:
        return redirect(url_for("login"))

    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT DuongDanTep
            FROM TepDinhKem
            WHERE MaTep = ?
        """, ma_tep)

        tep = cursor.fetchone()

        if tep:
            duong_dan_file = os.path.join("static", str(tep.DuongDanTep).replace("/", os.sep))

            if os.path.exists(duong_dan_file):
                os.remove(duong_dan_file)

            cursor.execute("""
                DELETE FROM TepDinhKem
                WHERE MaTep = ?
            """, ma_tep)

            conn.commit()
            flash("Xóa tệp đính kèm thành công!")

        cursor.close()
        conn.close()

    except Exception as e:
        print("Lỗi xóa tệp công văn đi:", e)
        flash("Không thể xóa tệp đính kèm.")

    return redirect(url_for("sua_cong_van_di", ma_van_ban_di=ma_van_ban_di))


@app.route("/cong-van-di/xoa/<ma_van_ban_di>", methods=["POST"])
def xoa_cong_van_di(ma_van_ban_di):
    if "username" not in session:
        return redirect(url_for("login"))

    try:
        tep_list = lay_file_cong_van_di(ma_van_ban_di)

        for tep in tep_list:
            duong_dan_file = os.path.join("static", str(tep.DuongDanTep).replace("/", os.sep))
            if os.path.exists(duong_dan_file):
                os.remove(duong_dan_file)

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            DELETE FROM TepDinhKem
            WHERE DoiTuongLienKet = 'VanBanDi'
              AND MaDoiTuong = ?
        """, ma_van_ban_di)

        cursor.execute("DELETE FROM VanBanDi WHERE MaVanBanDi = ?", ma_van_ban_di)

        conn.commit()
        cursor.close()
        conn.close()

        flash("Xóa công văn đi thành công!")

    except Exception as e:
        print("Lỗi xóa công văn đi:", e)
        flash("Không thể xóa công văn này. Có thể dữ liệu đang được liên kết với bảng khác.")

    return redirect(url_for("cong_van_di"))


def cap_nhat_trang_thai_cong_van_di(ma_van_ban_di, trang_thai_moi, thong_bao):
    if "username" not in session:
        return redirect(url_for("login"))

    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE VanBanDi
            SET TrangThai = ?
            WHERE MaVanBanDi = ?
        """, trang_thai_moi, ma_van_ban_di)

        conn.commit()
        cursor.close()
        conn.close()

        flash(thong_bao)

    except Exception as e:
        print("Lỗi cập nhật trạng thái công văn đi:", e)
        flash("Lỗi khi cập nhật trạng thái công văn.")

    return redirect(url_for("cong_van_di"))

def lay_du_lieu_form_cong_van_di():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT MaLoaiVanBan, TenLoaiVanBan 
        FROM LoaiVanBan 
        ORDER BY TenLoaiVanBan
    """)
    loai_van_ban_list = cursor.fetchall()

    cursor.execute("""
        SELECT MaLinhVuc, TenLinhVuc 
        FROM LinhVuc 
        ORDER BY TenLinhVuc
    """)
    linh_vuc_list = cursor.fetchall()

    # Người soạn: chỉ lấy Chuyên viên hoặc Văn thư
    cursor.execute("""
        SELECT cb.MaCanBo, cb.HoTen
        FROM CanBo cb
        LEFT JOIN TaiKhoan tk ON cb.MaCanBo = tk.MaCanBo
        LEFT JOIN VaiTro vt ON tk.MaVaiTro = vt.MaVaiTro
        WHERE 
            vt.TenVaiTro IN (N'Chuyên viên', N'Văn thư')
            AND (
                cb.TrangThai IN (N'Hoạt động', '1')
                OR cb.TrangThai IS NULL
            )
        ORDER BY cb.HoTen
    """)
    nguoi_soan_list = cursor.fetchall()

    # Người ký: chỉ lấy Lãnh đạo
    cursor.execute("""
        SELECT cb.MaCanBo, cb.HoTen
        FROM CanBo cb
        LEFT JOIN TaiKhoan tk ON cb.MaCanBo = tk.MaCanBo
        LEFT JOIN VaiTro vt ON tk.MaVaiTro = vt.MaVaiTro
        WHERE 
            vt.TenVaiTro IN (N'Lãnh đạo', N'Quản trị viên')
            AND (
                cb.TrangThai IN (N'Hoạt động', '1')
                OR cb.TrangThai IS NULL
            )
        ORDER BY cb.HoTen
    """)
    nguoi_ky_list = cursor.fetchall()

    cursor.close()
    conn.close()

    return {
        "loai_van_ban_list": loai_van_ban_list,
        "linh_vuc_list": linh_vuc_list,
        "nguoi_soan_list": nguoi_soan_list,
        "nguoi_ky_list": nguoi_ky_list
    }

# =========================
# TÀI KHOẢN CỦA TÔI
# =========================

def dam_bao_bang_ho_tro_nguoi_dung(cursor):
    cursor.execute("""
        IF OBJECT_ID(N'dbo.HOTRONGUOIDUNG', N'U') IS NULL
        BEGIN
            CREATE TABLE dbo.HOTRONGUOIDUNG (
                MaHoTro NVARCHAR(20) NOT NULL PRIMARY KEY,
                MaTaiKhoan NVARCHAR(50) NULL,
                TenDangNhap NVARCHAR(100) NULL,
                HoTen NVARCHAR(255) NULL,
                VaiTro NVARCHAR(100) NULL,
                LoaiYeuCau NVARCHAR(100) NOT NULL,
                MucDo NVARCHAR(50) NOT NULL,
                TieuDe NVARCHAR(255) NOT NULL,
                NoiDung NVARCHAR(MAX) NOT NULL,
                TrangThai NVARCHAR(50) NOT NULL
                    CONSTRAINT DF_HOTRONGUOIDUNG_TrangThai DEFAULT (N'Mới gửi'),
                NgayGui DATETIME2 NOT NULL
                    CONSTRAINT DF_HOTRONGUOIDUNG_NgayGui DEFAULT (SYSDATETIME())
            )
        END
    """)


def tao_ma_ho_tro(cursor):
    cursor.execute("""
        SELECT MaHoTro
        FROM HOTRONGUOIDUNG
        WHERE MaHoTro LIKE 'HT%'
    """)

    max_num = 0
    for row in cursor.fetchall():
        ma = str(row.MaHoTro or "").strip()
        so = ma.replace("HT", "")
        if so.isdigit():
            max_num = max(max_num, int(so))

    return f"HT{max_num + 1:03d}"


@app.route("/ho-tro-nguoi-dung", methods=["GET", "POST"])
def ho_tro_nguoi_dung():
    if "username" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        loai_yeu_cau = request.form.get("loai_yeu_cau", "").strip()
        muc_do = request.form.get("muc_do", "").strip()
        tieu_de = request.form.get("tieu_de", "").strip()
        noi_dung = request.form.get("noi_dung", "").strip()

        if not loai_yeu_cau or not muc_do or not tieu_de or not noi_dung:
            flash("Vui lòng nhập đầy đủ nội dung yêu cầu hỗ trợ.")
            return redirect(url_for("ho_tro_nguoi_dung"))

        conn = None
        cursor = None
        try:
            conn = get_connection()
            cursor = conn.cursor()
            dam_bao_bang_ho_tro_nguoi_dung(cursor)
            ma_ho_tro = tao_ma_ho_tro(cursor)

            cursor.execute("""
                INSERT INTO HOTRONGUOIDUNG (
                    MaHoTro, MaTaiKhoan, TenDangNhap, HoTen, VaiTro,
                    LoaiYeuCau, MucDo, TieuDe, NoiDung, TrangThai, NgayGui
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, N'Mới gửi', SYSDATETIME())
            """,
                ma_ho_tro,
                session.get("ma_tai_khoan"),
                session.get("username"),
                session.get("ho_ten"),
                session.get("vai_tro"),
                loai_yeu_cau,
                muc_do,
                tieu_de,
                noi_dung
            )

            conn.commit()
            flash(f"Đã gửi yêu cầu hỗ trợ {ma_ho_tro}. Bộ phận phụ trách sẽ kiểm tra và phản hồi.")
            return redirect(url_for("ho_tro_nguoi_dung"))
        except Exception as e:
            if conn:
                try:
                    conn.rollback()
                except Exception:
                    pass
            log_error_safe("Loi gui yeu cau ho tro:", e)
            flash("Không thể gửi yêu cầu hỗ trợ. Vui lòng thử lại hoặc liên hệ quản trị viên.")
        finally:
            if cursor:
                cursor.close()
            if conn:
                conn.close()

    return render_template(
        "ho_tro_nguoi_dung.html",
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng"),
        username=session.get("username", "")
    )


@app.route("/thong-tin-tai-khoan")
def thong_tin_tai_khoan():
    if "username" not in session:
        return redirect(url_for("login"))

    ma_tai_khoan = session.get("ma_tai_khoan")

    if not ma_tai_khoan:
        flash("Phiên đăng nhập không hợp lệ. Vui lòng đăng nhập lại.")
        return redirect(url_for("login"))

    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                tk.MaTaiKhoan,
                tk.TenDangNhap,
                tk.TrangThai AS TrangThaiTaiKhoan,
                vt.TenVaiTro,
                cb.MaCanBo,
                cb.HoTen,
                cb.NgaySinh,
                cb.GioiTinh,
                cb.SoDienThoai,
                cb.Email,
                cb.DiaChi,
                cb.TrangThai AS TrangThaiCanBo,
                bp.TenBoPhan,
                cv.TenChucVu
            FROM TAIKHOAN tk
            LEFT JOIN CANBO cb ON tk.MaCanBo = cb.MaCanBo
            LEFT JOIN VAITRO vt ON tk.MaVaiTro = vt.MaVaiTro
            LEFT JOIN BOPHAN bp ON cb.MaBoPhan = bp.MaBoPhan
            LEFT JOIN CHUCVU cv ON cb.MaChucVu = cv.MaChucVu
            WHERE tk.MaTaiKhoan = ?
        """, ma_tai_khoan)

        tai_khoan = cursor.fetchone()

        cursor.close()
        conn.close()

        if not tai_khoan:
            flash("Không tìm thấy thông tin tài khoản.")
            return redirect(url_for("dashboard"))

        return render_template(
            "thong_tin_tai_khoan.html",
            tai_khoan=tai_khoan,
            ho_ten=session.get("ho_ten", tai_khoan.HoTen or "Người dùng"),
            vai_tro=session.get("vai_tro", tai_khoan.TenVaiTro or "Người dùng")
        )

    except Exception as e:
        print("Lỗi xem thông tin tài khoản:", e)
        flash("Có lỗi xảy ra khi tải thông tin tài khoản.")
        return redirect(url_for("dashboard"))


# =========================
# ĐỔI MẬT KHẨU
# =========================

@app.route("/doi-mat-khau", methods=["GET", "POST"])
def doi_mat_khau():
    if "username" not in session:
        return redirect(url_for("login"))

    ma_tai_khoan = session.get("ma_tai_khoan")

    if not ma_tai_khoan:
        flash("Phiên đăng nhập không hợp lệ. Vui lòng đăng nhập lại.")
        return redirect(url_for("login"))

    dang_bi_bat_buoc_doi_mat_khau = bool(session.get("bat_buoc_doi_mat_khau"))

    if request.method == "POST":
        mat_khau_cu = request.form.get("mat_khau_cu", "").strip()
        mat_khau_moi = request.form.get("mat_khau_moi", "").strip()
        nhap_lai_mat_khau = request.form.get("nhap_lai_mat_khau", "").strip()

        if not mat_khau_cu or not mat_khau_moi or not nhap_lai_mat_khau:
            flash("Vui lòng nhập đầy đủ thông tin.")
            return redirect(url_for("doi_mat_khau"))

        if not mat_khau_dat_yeu_cau(mat_khau_moi):
            flash(PASSWORD_POLICY_MESSAGE)
            return redirect(url_for("doi_mat_khau"))

        if mat_khau_moi != nhap_lai_mat_khau:
            flash("Mật khẩu mới và nhập lại mật khẩu không khớp.")
            return redirect(url_for("doi_mat_khau"))

        try:
            conn = get_connection()
            cursor = conn.cursor()

            cursor.execute("""
                SELECT MaTaiKhoan, TenDangNhap, MatKhau, TrangThai
                FROM TAIKHOAN
                WHERE MaTaiKhoan = ?
                AND LTRIM(RTRIM(CONVERT(NVARCHAR(50), TrangThai))) IN (N'Hoạt động', N'Hoat dong', N'1')
            """, ma_tai_khoan)

            user = cursor.fetchone()

            if not user:
                cursor.close()
                conn.close()
                flash("Không tìm thấy tài khoản.")
                return redirect(url_for("doi_mat_khau"))

            if str(user.MatKhau).strip() != mat_khau_cu:
                cursor.close()
                conn.close()
                flash("Mật khẩu hiện tại không đúng.")
                return redirect(url_for("doi_mat_khau"))

            if mat_khau_moi == mat_khau_cu:
                cursor.close()
                conn.close()
                flash("Mật khẩu mới không được trùng với mật khẩu hiện tại.")
                return redirect(url_for("doi_mat_khau"))

            co_cot_doi_mat_khau_lan_dau = dam_bao_cot_doi_mat_khau_lan_dau()
            if co_cot_doi_mat_khau_lan_dau:
                cursor.execute(f"""
                    UPDATE TAIKHOAN
                    SET MatKhau = ?,
                        {PASSWORD_FIRST_LOGIN_COLUMN} = 0
                    WHERE MaTaiKhoan = ?
                """, mat_khau_moi, ma_tai_khoan)
            else:
                cursor.execute("""
                    UPDATE TAIKHOAN
                    SET MatKhau = ?
                    WHERE MaTaiKhoan = ?
                """, mat_khau_moi, ma_tai_khoan)

            conn.commit()
            cursor.close()
            conn.close()

            session["bat_buoc_doi_mat_khau"] = False
            flash("Đổi mật khẩu thành công!")
            if dang_bi_bat_buoc_doi_mat_khau:
                return redirect(url_for("dashboard"))
            return redirect(url_for("doi_mat_khau"))

        except Exception as e:
            print("===== LỖI ĐỔI MẬT KHẨU =====")
            print(e)
            print("============================")
            flash(f"Có lỗi xảy ra khi đổi mật khẩu: {e}")

    return render_template(
        "doi_mat_khau.html",
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng"),
        bat_buoc_doi_mat_khau=dang_bi_bat_buoc_doi_mat_khau
    )

# =========================
# QUÊN MẬT KHẨU
# =========================

@app.route("/quen-mat-khau", methods=["GET", "POST"])
def quen_mat_khau():
    if request.method == "POST":
        ten_dang_nhap = request.form.get("ten_dang_nhap", "").strip()
        email = request.form.get("email", "").strip().lower()
        so_dien_thoai = request.form.get("so_dien_thoai", "").strip()
        mat_khau_moi = request.form.get("mat_khau_moi", "").strip()
        nhap_lai_mat_khau = request.form.get("nhap_lai_mat_khau", "").strip()

        so_dien_thoai_chuan = (
            so_dien_thoai
            .replace(" ", "")
            .replace(".", "")
            .replace("-", "")
        )

        if not ten_dang_nhap or not email or not so_dien_thoai or not mat_khau_moi or not nhap_lai_mat_khau:
            flash("Vui lòng nhập đầy đủ thông tin.")
            return redirect(url_for("quen_mat_khau"))

        if not mat_khau_dat_yeu_cau(mat_khau_moi):
            flash(PASSWORD_POLICY_MESSAGE)
            return redirect(url_for("quen_mat_khau"))

        if mat_khau_moi != nhap_lai_mat_khau:
            flash("Mật khẩu mới và nhập lại mật khẩu không khớp.")
            return redirect(url_for("quen_mat_khau"))

        try:
            conn = get_connection()
            cursor = conn.cursor()

            cursor.execute("""
                SELECT
                    tk.MaTaiKhoan,
                    tk.TenDangNhap,
                    cb.HoTen,
                    cb.Email,
                    cb.SoDienThoai
                FROM TAIKHOAN tk
                JOIN CANBO cb ON tk.MaCanBo = cb.MaCanBo
                WHERE LTRIM(RTRIM(tk.TenDangNhap)) = ?
                  AND LOWER(LTRIM(RTRIM(ISNULL(cb.Email, '')))) = ?
                  AND REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(cb.SoDienThoai, ''))), ' ', ''), '.', ''), '-', '') = ?
                  AND (tk.TrangThai IN (N'Hoạt động', '1') OR tk.TrangThai IS NULL)
                  AND (cb.TrangThai IN (N'Hoạt động', '1') OR cb.TrangThai IS NULL)
            """, ten_dang_nhap, email, so_dien_thoai_chuan)

            user = cursor.fetchone()

            if not user:
                cursor.close()
                conn.close()
                flash("Thông tin xác minh không đúng. Vui lòng kiểm tra lại tên đăng nhập, email hoặc số điện thoại.")
                return redirect(url_for("quen_mat_khau"))

            co_cot_doi_mat_khau_lan_dau = dam_bao_cot_doi_mat_khau_lan_dau()
            if co_cot_doi_mat_khau_lan_dau:
                cursor.execute(f"""
                    UPDATE TAIKHOAN
                    SET MatKhau = ?,
                        {PASSWORD_FIRST_LOGIN_COLUMN} = 0
                    WHERE MaTaiKhoan = ?
                """, mat_khau_moi, user.MaTaiKhoan)
            else:
                cursor.execute("""
                    UPDATE TAIKHOAN
                    SET MatKhau = ?
                    WHERE MaTaiKhoan = ?
                """, mat_khau_moi, user.MaTaiKhoan)

            conn.commit()
            cursor.close()
            conn.close()

            flash("Đặt lại mật khẩu thành công. Vui lòng đăng nhập bằng mật khẩu mới.")
            return redirect(url_for("login"))

        except Exception as e:
            print("Lỗi quên mật khẩu:", e)
            flash("Có lỗi xảy ra khi đặt lại mật khẩu.")

    return render_template("quen_mat_khau.html")

# =========================
# THÊM / SỬA NGƯỜI DÙNG KÈM CÁN BỘ
# =========================

def tao_ma_tu_dong(table_name, column_name, prefix, width=3):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(f"""
        SELECT {column_name}
        FROM {table_name}
        WHERE {column_name} LIKE ?
    """, f"{prefix}%")

    rows = cursor.fetchall()

    max_num = 0
    for row in rows:
        ma = str(row[0]).strip()
        so = ma.replace(prefix, "")
        if so.isdigit():
            max_num = max(max_num, int(so))

    cursor.close()
    conn.close()

    return f"{prefix}{max_num + 1:0{width}d}"


def lay_du_lieu_form_nguoi_dung():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT MaVaiTro, TenVaiTro
        FROM VAITRO
        ORDER BY TenVaiTro
    """)
    vai_tro_list = cursor.fetchall()

    cursor.execute("""
        SELECT MaBoPhan, TenBoPhan
        FROM BOPHAN
        ORDER BY TenBoPhan
    """)
    bo_phan_list = cursor.fetchall()

    cursor.execute("""
        SELECT MaChucVu, TenChucVu
        FROM CHUCVU
        ORDER BY TenChucVu
    """)
    chuc_vu_list = cursor.fetchall()

    cursor.close()
    conn.close()

    return vai_tro_list, bo_phan_list, chuc_vu_list


def kiem_tra_ten_dang_nhap_ton_tai(ten_dang_nhap, ma_tai_khoan=None):
    conn = get_connection()
    cursor = conn.cursor()

    if ma_tai_khoan:
        cursor.execute("""
            SELECT COUNT(*)
            FROM TAIKHOAN
            WHERE LTRIM(RTRIM(TenDangNhap)) = ?
              AND MaTaiKhoan <> ?
        """, ten_dang_nhap, ma_tai_khoan)
    else:
        cursor.execute("""
            SELECT COUNT(*)
            FROM TAIKHOAN
            WHERE LTRIM(RTRIM(TenDangNhap)) = ?
        """, ten_dang_nhap)

    count = cursor.fetchone()[0]

    cursor.close()
    conn.close()

    return count > 0


@app.route("/nguoi-dung/them", methods=["GET", "POST"])
def them_nguoi_dung():
    if "username" not in session:
        return redirect(url_for("login"))

    vai_tro_list, bo_phan_list, chuc_vu_list = lay_du_lieu_form_nguoi_dung()

    if request.method == "POST":
        ho_ten = request.form.get("ho_ten", "").strip()
        ngay_sinh = parse_date_ddmmyyyy(request.form.get("ngay_sinh")) if request.form.get("ngay_sinh") else None
        gioi_tinh = request.form.get("gioi_tinh") or None
        so_dien_thoai = request.form.get("so_dien_thoai", "").strip()
        email = request.form.get("email", "").strip()
        dia_chi = request.form.get("dia_chi", "").strip()
        ma_bo_phan = request.form.get("ma_bo_phan") or None
        ma_chuc_vu = request.form.get("ma_chuc_vu") or None

        ten_dang_nhap = request.form.get("ten_dang_nhap", "").strip()
        mat_khau = request.form.get("mat_khau", "").strip()
        ma_vai_tro = request.form.get("ma_vai_tro") or None

        trang_thai_can_bo = request.form.get("trang_thai_can_bo", "1")
        trang_thai_tai_khoan = request.form.get("trang_thai_tai_khoan", "1")

        if not ho_ten or not ten_dang_nhap or not mat_khau or not ma_vai_tro:
            flash("Vui lòng nhập đầy đủ họ tên, tên đăng nhập, mật khẩu và vai trò.")
            return redirect(url_for("them_nguoi_dung"))

        if kiem_tra_ten_dang_nhap_ton_tai(ten_dang_nhap):
            flash("Tên đăng nhập đã tồn tại. Vui lòng chọn tên khác.")
            return redirect(url_for("them_nguoi_dung"))

        conn = None

        try:
            ma_can_bo = tao_ma_tu_dong("CANBO", "MaCanBo", "CB")
            ma_tai_khoan = tao_ma_tu_dong("TAIKHOAN", "MaTaiKhoan", "TK")
            co_cot_doi_mat_khau_lan_dau = dam_bao_cot_doi_mat_khau_lan_dau()

            conn = get_connection()
            cursor = conn.cursor()

            # 1. Thêm cán bộ trước
            cursor.execute("""
                INSERT INTO CANBO
                (
                    MaCanBo, HoTen, NgaySinh, GioiTinh,
                    SoDienThoai, Email, DiaChi,
                    MaBoPhan, MaChucVu, TrangThai
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
                ma_can_bo,
                ho_ten,
                ngay_sinh,
                gioi_tinh,
                so_dien_thoai,
                email,
                dia_chi,
                ma_bo_phan,
                ma_chuc_vu,
                trang_thai_can_bo
            )

            # 2. Thêm tài khoản gắn với cán bộ vừa tạo
            if co_cot_doi_mat_khau_lan_dau:
                cursor.execute(f"""
                    INSERT INTO TAIKHOAN
                    (
                        MaTaiKhoan, TenDangNhap, MatKhau,
                        MaCanBo, MaVaiTro, TrangThai, {PASSWORD_FIRST_LOGIN_COLUMN}
                    )
                    VALUES (?, ?, ?, ?, ?, ?, 1)
                """,
                    ma_tai_khoan,
                    ten_dang_nhap,
                    mat_khau,
                    ma_can_bo,
                    ma_vai_tro,
                    trang_thai_tai_khoan
                )
            else:
                cursor.execute("""
                    INSERT INTO TAIKHOAN
                    (
                        MaTaiKhoan, TenDangNhap, MatKhau,
                        MaCanBo, MaVaiTro, TrangThai
                    )
                    VALUES (?, ?, ?, ?, ?, ?)
                """,
                    ma_tai_khoan,
                    ten_dang_nhap,
                    mat_khau,
                    ma_can_bo,
                    ma_vai_tro,
                    trang_thai_tai_khoan
                )

            conn.commit()
            cursor.close()
            conn.close()

            flash("Thêm cán bộ và tài khoản thành công.")
            return redirect(url_for("nguoi_dung"))

        except Exception as e:
            if conn:
                conn.rollback()
                conn.close()

            print("Lỗi thêm cán bộ + tài khoản:", e)
            flash("Có lỗi xảy ra khi thêm cán bộ và tài khoản.")
            return redirect(url_for("them_nguoi_dung"))

    return render_template(
        "nguoi_dung_form.html",
        action="them",
        user=None,
        ma_can_bo_tu_dong=tao_ma_tu_dong("CANBO", "MaCanBo", "CB"),
        ma_tai_khoan_tu_dong=tao_ma_tu_dong("TAIKHOAN", "MaTaiKhoan", "TK"),
        vai_tro_list=vai_tro_list,
        bo_phan_list=bo_phan_list,
        chuc_vu_list=chuc_vu_list,
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )


@app.route("/nguoi-dung/sua/<ma_tai_khoan>", methods=["GET", "POST"])
def sua_nguoi_dung(ma_tai_khoan):
    if "username" not in session:
        return redirect(url_for("login"))

    vai_tro_list, bo_phan_list, chuc_vu_list = lay_du_lieu_form_nguoi_dung()

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT
            tk.MaTaiKhoan,
            tk.TenDangNhap,
            tk.MatKhau,
            tk.MaVaiTro,
            tk.TrangThai AS TrangThaiTaiKhoan,

            cb.MaCanBo,
            cb.HoTen,
            cb.NgaySinh,
            cb.GioiTinh,
            cb.SoDienThoai,
            cb.Email,
            cb.DiaChi,
            cb.MaBoPhan,
            cb.MaChucVu,
            cb.TrangThai AS TrangThaiCanBo
        FROM TAIKHOAN tk
        JOIN CANBO cb ON tk.MaCanBo = cb.MaCanBo
        WHERE tk.MaTaiKhoan = ?
    """, ma_tai_khoan)

    user = cursor.fetchone()

    if not user:
        cursor.close()
        conn.close()
        flash("Không tìm thấy tài khoản.")
        return redirect(url_for("nguoi_dung"))

    if request.method == "POST":
        ho_ten = request.form.get("ho_ten", "").strip()
        ngay_sinh = parse_date_ddmmyyyy(request.form.get("ngay_sinh")) if request.form.get("ngay_sinh") else None
        gioi_tinh = request.form.get("gioi_tinh") or None
        so_dien_thoai = request.form.get("so_dien_thoai", "").strip()
        email = request.form.get("email", "").strip()
        dia_chi = request.form.get("dia_chi", "").strip()
        ma_bo_phan = request.form.get("ma_bo_phan") or None
        ma_chuc_vu = request.form.get("ma_chuc_vu") or None

        ten_dang_nhap = request.form.get("ten_dang_nhap", "").strip()
        mat_khau = request.form.get("mat_khau", "").strip()
        ma_vai_tro = request.form.get("ma_vai_tro") or None

        trang_thai_can_bo = request.form.get("trang_thai_can_bo", "1")
        trang_thai_tai_khoan = request.form.get("trang_thai_tai_khoan", "1")

        if not ho_ten or not ten_dang_nhap or not ma_vai_tro:
            flash("Vui lòng nhập đầy đủ họ tên, tên đăng nhập và vai trò.")
            return redirect(url_for("sua_nguoi_dung", ma_tai_khoan=ma_tai_khoan))

        if kiem_tra_ten_dang_nhap_ton_tai(ten_dang_nhap, ma_tai_khoan):
            flash("Tên đăng nhập đã tồn tại. Vui lòng chọn tên khác.")
            return redirect(url_for("sua_nguoi_dung", ma_tai_khoan=ma_tai_khoan))

        try:
            # 1. Cập nhật cán bộ
            cursor.execute("""
                UPDATE CANBO
                SET
                    HoTen = ?,
                    NgaySinh = ?,
                    GioiTinh = ?,
                    SoDienThoai = ?,
                    Email = ?,
                    DiaChi = ?,
                    MaBoPhan = ?,
                    MaChucVu = ?,
                    TrangThai = ?
                WHERE MaCanBo = ?
            """,
                ho_ten,
                ngay_sinh,
                gioi_tinh,
                so_dien_thoai,
                email,
                dia_chi,
                ma_bo_phan,
                ma_chuc_vu,
                trang_thai_can_bo,
                user.MaCanBo
            )

            # 2. Cập nhật tài khoản
            if mat_khau:
                co_cot_doi_mat_khau_lan_dau = dam_bao_cot_doi_mat_khau_lan_dau()
                if co_cot_doi_mat_khau_lan_dau:
                    cursor.execute(f"""
                        UPDATE TAIKHOAN
                        SET
                            TenDangNhap = ?,
                            MatKhau = ?,
                            MaVaiTro = ?,
                            TrangThai = ?,
                            {PASSWORD_FIRST_LOGIN_COLUMN} = 1
                        WHERE MaTaiKhoan = ?
                    """,
                        ten_dang_nhap,
                        mat_khau,
                        ma_vai_tro,
                        trang_thai_tai_khoan,
                        ma_tai_khoan
                    )
                else:
                    cursor.execute("""
                        UPDATE TAIKHOAN
                        SET
                            TenDangNhap = ?,
                            MatKhau = ?,
                            MaVaiTro = ?,
                            TrangThai = ?
                        WHERE MaTaiKhoan = ?
                    """,
                        ten_dang_nhap,
                        mat_khau,
                        ma_vai_tro,
                        trang_thai_tai_khoan,
                        ma_tai_khoan
                    )
            else:
                cursor.execute("""
                    UPDATE TAIKHOAN
                    SET
                        TenDangNhap = ?,
                        MaVaiTro = ?,
                        TrangThai = ?
                    WHERE MaTaiKhoan = ?
                """,
                    ten_dang_nhap,
                    ma_vai_tro,
                    trang_thai_tai_khoan,
                    ma_tai_khoan
                )

            conn.commit()
            cursor.close()
            conn.close()

            flash("Cập nhật cán bộ và tài khoản thành công.")
            return redirect(url_for("nguoi_dung"))

        except Exception as e:
            conn.rollback()
            cursor.close()
            conn.close()

            print("Lỗi sửa cán bộ + tài khoản:", e)
            flash("Có lỗi xảy ra khi cập nhật cán bộ và tài khoản.")
            return redirect(url_for("sua_nguoi_dung", ma_tai_khoan=ma_tai_khoan))

    cursor.close()
    conn.close()

    return render_template(
        "nguoi_dung_form.html",
        action="sua",
        user=user,
        ma_can_bo_tu_dong=None,
        ma_tai_khoan_tu_dong=None,
        vai_tro_list=vai_tro_list,
        bo_phan_list=bo_phan_list,
        chuc_vu_list=chuc_vu_list,
        ho_ten=session.get("ho_ten", "Người dùng"),
        vai_tro=session.get("vai_tro", "Người dùng")
    )

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
